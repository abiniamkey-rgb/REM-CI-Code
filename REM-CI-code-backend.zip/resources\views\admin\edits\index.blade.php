@extends('admin.layout')
@section('title', 'Modifications')
@section('content')
  <h1>Modifications d'annonces</h1>
  <div class="sub">Ce que les propriétaires changent sur leurs résidences déjà publiées (description et commodités). Le filtre automatique refuse les insultes et les coordonnées ; ce qu'il signale ⚠ est à relire en priorité.</div>

  <div class="tabs">
    <a class="{{ $filter === 'review' ? 'on' : '' }}" href="{{ route('admin.edits.index') }}">À relire<small>{{ $counts['review'] }}</small></a>
    <a class="{{ $filter === 'flagged' ? 'on' : '' }}" href="{{ route('admin.edits.index', ['filtre' => 'flagged']) }}">Signalées ⚠<small>{{ $counts['flagged'] }}</small></a>
    <a class="{{ $filter === 'reverted' ? 'on' : '' }}" href="{{ route('admin.edits.index', ['filtre' => 'reverted']) }}">Annulées<small>{{ $counts['reverted'] }}</small></a>
    <a class="{{ $filter === 'all' ? 'on' : '' }}" href="{{ route('admin.edits.index', ['filtre' => 'all']) }}">Toutes<small>{{ $counts['all'] }}</small></a>
  </div>

  @forelse($edits as $e)
    <div class="card" style="margin-bottom:12px;{{ $e->flagged && ! $e->reviewed_at ? 'border-color:#F0B4AE;' : '' }}">
      <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div>
          <a href="{{ route('admin.properties.show', $e->property_id) }}"><strong>{{ $e->property?->title }}</strong></a>
          <span class="badge b-pending" style="margin-left:6px">{{ $e->fieldLabel() }}</span>
          @if($e->flagged)<span class="badge b-rejected" style="margin-left:4px">⚠ Signalée</span>@endif
          @if($e->reverted_at)<span class="badge b-cancelled" style="margin-left:4px">Annulée</span>
          @elseif($e->reviewed_at)<span class="badge b-verified" style="margin-left:4px">Vérifiée</span>@endif
          <div class="sub">{{ $e->property?->city?->name }} · par {{ $e->user?->name }} ({{ $e->user?->phone }}) · {{ $e->created_at?->format('d/m/Y H:i') }}</div>
        </div>
      </div>

      @if($e->flag_reason)
        <div class="flash err" style="margin:10px 0 0">Signalé par le filtre : {{ $e->flag_reason }}.</div>
      @endif

      <div class="grid two" style="margin-top:12px">
        <div>
          <div class="sub" style="font-weight:700;margin-bottom:4px">Avant</div>
          <div style="background:#F6F3EA;border-radius:12px;padding:10px 12px;white-space:pre-wrap">{{ $e->old_value ?: '—' }}</div>
        </div>
        <div>
          <div class="sub" style="font-weight:700;margin-bottom:4px">Après</div>
          <div style="background:#E8F5EC;border-radius:12px;padding:10px 12px;white-space:pre-wrap">{{ $e->new_value ?: '—' }}</div>
        </div>
      </div>

      @if(! $e->reviewed_at)
        <div class="actions" style="margin-top:12px">
          <form method="POST" action="{{ route('admin.edits.review', $e) }}">@csrf<button class="btn" type="submit">✓ C'est bon</button></form>
          @if($e->field === 'description')
            <form method="POST" action="{{ route('admin.edits.revert', $e) }}" onsubmit="return confirm('Rétablir l\'ancienne description et prévenir le propriétaire ?')">@csrf<button class="btn red" type="submit">Annuler la modification</button></form>
          @endif
        </div>
      @endif
    </div>
  @empty
    <div class="card empty">Rien à relire pour le moment 🎉</div>
  @endforelse

  @include('admin._pager', ['items' => $edits])
@endsection
