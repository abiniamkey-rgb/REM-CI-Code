<?php

namespace App\Console\Commands;

use App\Models\Ad;
use App\Models\PropertyPhoto;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;

/**
 * Remet la base « propre » avant une phase de test : supprime comptes locataires/propriétaires,
 * résidences, photos, réservations, favoris, notifications et publicités de démonstration.
 * Conserve : villes, équipements et comptes administrateurs.
 */
class ResetTestData extends Command
{
    protected $signature = 'remci:reset-test-data {--keep-ads : Garder les publicités} {--force : Ne pas demander de confirmation} {--allow-production : Autoriser sur un serveur de production (dangereux)}';

    protected $description = 'Efface les données de test (comptes, résidences, réservations…) en gardant villes, équipements et administrateurs';

    public function handle(): int
    {
        // Protection : cette commande vide la base. Interdite sur le serveur de production
        // sauf option explicite --allow-production.
        if (app()->isProduction() && ! $this->option('allow-production')) {
            $this->error('Refusé : APP_ENV=production. Cette commande est réservée aux serveurs de test.');

            return self::FAILURE;
        }

        $count = fn (string $table) => Schema::hasTable($table) ? DB::table($table)->count() : 0;

        $this->info('Données qui seront supprimées :');
        $this->table(['Élément', 'Nombre'], [
            ['Comptes (hors administrateurs)', User::where('role', '!=', 'admin')->count()],
            ['Résidences', $count('properties')],
            ['Photos de résidences', $count('property_photos')],
            ['Réservations', $count('bookings')],
            ['Favoris', $count('favorites')],
            ['Notifications', $count('user_notifications')],
            ['Publicités', $this->option('keep-ads') ? '(conservées)' : $count('ads')],
        ]);
        $this->line('Conservés : villes, équipements, comptes administrateurs.');

        if (! $this->option('force')) {
            $answer = $this->ask('Tape RESET pour confirmer la suppression définitive');
            if (strtoupper(trim((string) $answer)) !== 'RESET') {
                $this->warn('Annulé : rien n\'a été supprimé.');

                return self::FAILURE;
            }
        }

        $this->backupSqlite();

        // 1) Fichiers : pièces d'identité, avatars, photos de résidences, images de publicités
        $files = 0;
        User::where('role', '!=', 'admin')->each(function (User $u) use (&$files) {
            foreach ([$u->id_document_url, $u->id_document_verso_url] as $path) {
                if ($path) {
                    foreach (['local', 'public'] as $disk) {
                        $files += Storage::disk($disk)->delete($path) ? 1 : 0;
                    }
                }
            }
            if ($u->avatar && ! str_starts_with($u->avatar, 'http')) {
                $files += Storage::disk('public')->delete($u->avatar) ? 1 : 0;
            }
        });
        PropertyPhoto::query()->each(function (PropertyPhoto $p) use (&$files) {
            if ($p->url && ! str_starts_with($p->url, 'http')) {
                $files += Storage::disk('public')->delete($p->url) ? 1 : 0;
            }
        });
        if (! $this->option('keep-ads')) {
            Ad::query()->each(function (Ad $a) use (&$files) {
                if ($a->image_path) {
                    $files += Storage::disk('public')->delete($a->image_path) ? 1 : 0;
                }
            });
        }

        // 2) Base de données (ordre : tables dépendantes d'abord)
        $adminIds = User::where('role', 'admin')->pluck('id');
        $tables = ['payments', 'bookings', 'favorites', 'property_edits', 'property_photos', 'amenity_property', 'properties', 'user_notifications', 'password_reset_codes'];
        if (! $this->option('keep-ads')) {
            array_unshift($tables, 'ads');
        }

        DB::transaction(function () use ($tables, $adminIds) {
            foreach ($tables as $table) {
                if (Schema::hasTable($table)) {
                    DB::table($table)->delete();
                }
            }
            if (Schema::hasTable('personal_access_tokens')) {
                DB::table('personal_access_tokens')->where('tokenable_type', User::class)->whereNotIn('tokenable_id', $adminIds)->delete();
            }
            DB::table('users')->whereNotIn('id', $adminIds)->delete();
        });

        // Numérotation repartie de 1 (SQLite)
        if (DB::getDriverName() === 'sqlite' && Schema::hasTable('sqlite_sequence')) {
            DB::table('sqlite_sequence')->whereIn('name', array_merge($tables, ['ads']))->delete();
        }

        $this->info("Terminé : données de test supprimées ({$files} fichier(s) effacé(s)). Villes, équipements et administrateurs conservés.");
        $this->line('Astuce : ne lance pas `php artisan db:seed`, il recréerait les comptes et résidences de démonstration.');

        return self::SUCCESS;
    }

    /** Copie de sécurité du fichier SQLite avant suppression. */
    private function backupSqlite(): void
    {
        if (DB::getDriverName() !== 'sqlite') {
            $this->warn('Base non SQLite : fais une sauvegarde toi-même avant de continuer.');

            return;
        }

        $path = DB::connection()->getDatabaseName();
        if ($path && $path !== ':memory:' && is_file($path)) {
            $dir = storage_path('app/backups');
            File::ensureDirectoryExists($dir);
            $target = $dir.'/database-'.now()->format('Ymd-His').'.sqlite';
            File::copy($path, $target);
            $this->info("Sauvegarde créée : {$target}");
        }
    }
}
