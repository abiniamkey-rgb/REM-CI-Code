<?php

namespace Database\Seeders;

use App\Models\Amenity;
use Illuminate\Database\Seeder;

class AmenitySeeder extends Seeder
{
    public function run(): void
    {
        // Tout ce qu'une résidence meublée ivoirienne peut proposer — le propriétaire
        // coche ce qui s'applique dans le formulaire "Ajouter une résidence".
        $amenities = [
            // Confort
            ['name' => 'Wi-Fi', 'icon' => 'wifi'],
            ['name' => 'Climatisation', 'icon' => 'ac_unit'],
            ['name' => 'Ventilateur', 'icon' => 'air'],
            ['name' => 'TV', 'icon' => 'tv'],
            ['name' => 'TV satellite (Canal+)', 'icon' => 'tv'],
            ['name' => 'Eau chaude', 'icon' => 'hot_tub'],
            ['name' => 'Draps et serviettes', 'icon' => 'bed'],
            ['name' => 'Sèche-cheveux', 'icon' => 'air'],
            ['name' => 'Fer à repasser', 'icon' => 'iron'],
            ['name' => 'Penderie / armoire', 'icon' => 'checkroom'],
            ['name' => 'Espace de travail', 'icon' => 'desk'],
            // Cuisine
            ['name' => 'Cuisine équipée', 'icon' => 'restaurant'],
            ['name' => 'Réfrigérateur', 'icon' => 'kitchen'],
            ['name' => 'Congélateur', 'icon' => 'kitchen'],
            ['name' => 'Plaques de cuisson', 'icon' => 'restaurant'],
            ['name' => 'Micro-ondes', 'icon' => 'microwave'],
            ['name' => 'Bouilloire / cafetière', 'icon' => 'coffee'],
            ['name' => 'Lave-linge', 'icon' => 'washing'],
            // Énergie et eau
            ['name' => 'Groupe électrogène', 'icon' => 'bolt'],
            ['name' => 'Onduleur / panneaux solaires', 'icon' => 'solar'],
            ['name' => 'Eau courante 24h/24', 'icon' => 'water'],
            ['name' => 'Château d\'eau / forage', 'icon' => 'water'],
            // Sécurité
            ['name' => 'Sécurité 24h', 'icon' => 'security'],
            ['name' => 'Gardien', 'icon' => 'security'],
            ['name' => 'Caméras de surveillance', 'icon' => 'videocam'],
            ['name' => 'Portail électrique', 'icon' => 'gate'],
            ['name' => 'Coffre-fort', 'icon' => 'lock'],
            // Extérieur et services
            ['name' => 'Parking', 'icon' => 'car'],
            ['name' => 'Piscine', 'icon' => 'pool'],
            ['name' => 'Jardin', 'icon' => 'park'],
            ['name' => 'Terrasse / balcon', 'icon' => 'deck'],
            ['name' => 'Barbecue', 'icon' => 'grill'],
            ['name' => 'Salle de sport', 'icon' => 'fitness'],
            ['name' => 'Ascenseur', 'icon' => 'elevator'],
            ['name' => 'Accueil / check-in autonome', 'icon' => 'key'],
            ['name' => 'Ménage inclus', 'icon' => 'cleaning'],
            ['name' => 'Animaux acceptés', 'icon' => 'pets'],
        ];

        foreach ($amenities as $a) {
            Amenity::updateOrCreate(['name' => $a['name']], $a);
        }
    }
}
