@extends('legal.layout')
@section('title', 'Résidences meublées en Côte d\'Ivoire')
@section('content')
  <h1>Trouvez votre résidence meublée en Côte d'Ivoire</h1>
  <p class="upd">Une application {{ config('remci.company') }}</p>
  <div class="box">
    <p><strong>REM-CI</strong> met en relation des locataires et des propriétaires de résidences meublées. Parcourez les annonces, vérifiez la disponibilité, envoyez une demande de réservation, puis échangez directement avec le propriétaire par appel ou WhatsApp.</p>
    <ul>
      <li><strong>Aucun paiement dans l'application</strong> : le séjour se règle directement avec le propriétaire.</li>
      <li><strong>Propriétaires certifiés</strong> : chaque propriétaire soumet une pièce d'identité contrôlée par l'équipe REM-CI.</li>
      <li><strong>Reçu de réservation avec code QR</strong>, vérifiable en ligne.</li>
    </ul>
  </div>
  <p>Questions, aide ou signalement : <a href="mailto:{{ config('remci.contact_email') }}">{{ config('remci.contact_email') }}</a> ou {{ implode(' / ', config('remci.admin_phones')) }}.</p>
@endsection
