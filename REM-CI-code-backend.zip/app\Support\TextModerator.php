<?php

namespace App\Support;

/**
 * Filtre automatique des textes d'annonce (titre, description, adresse).
 *
 * - REFUSE (le texte n'est pas enregistré) : insultes / propos obscènes ou sexuels, et coordonnées
 *   glissées dans le texte (numéro de téléphone, e-mail, lien, réseau social) : les locataires
 *   contactent déjà le propriétaire via REM-CI, pas besoin de contourner l'application.
 * - SIGNALE (le texte est enregistré mais mis en avant pour l'administrateur) : mots typiques des
 *   arnaques (Western Union, acompte avant visite…) et texte écrit en MAJUSCULES.
 *
 * Ce n'est qu'un premier filtre automatique : il attrape l'évident, l'administrateur relit le reste
 * dans « Modifications » du panneau d'administration.
 */
class TextModerator
{
    /** Mots refusés tels quels (comparés sans accents, sans lettres répétées). */
    private const OBSCENE_WORDS = [
        'merde', 'merdique', 'putain', 'pute', 'putes', 'connard', 'connards', 'connasse', 'con', 'salope', 'salopes',
        'encule', 'enculer', 'enculee', 'batard', 'batarde', 'nique', 'niquer', 'foutre', 'couille', 'couilles',
        'bite', 'chatte', 'zob', 'sexe', 'sexy', 'sexuel', 'sexuelle', 'bordel', 'viol', 'violer', 'nichons', 'nudes',
    ];

    /** Débuts de mots refusés (prostitu…, porno…, escort…). */
    private const OBSCENE_STEMS = ['prostitu', 'pornograph', 'porno', 'erotiq', 'escort', 'pedophil', 'fdp', 'ntm', 'tg'];

    /** Mots qui rendent l'annonce suspecte sans la refuser. */
    private const SCAM_PATTERN = '/western\s*union|money\s*gram|ria\s*money|envoy\w*\s+(?:de\s+l.?argent|un\s+acompte|l.?acompte)'
        .'|(?:paiement|payer|paye|payez|verse|versez|virement)\s+(?:d.?avance|avant|a\s+l.?avance)'
        .'|frais\s+de\s+(?:dossier|reservation|visite)|acompte\s+(?:obligatoire|avant)/u';

    /**
     * @return array{blocked: bool, message: ?string, reason: ?string, flags: string[]}
     */
    public static function check(?string $text): array
    {
        $result = ['blocked' => false, 'message' => null, 'reason' => null, 'flags' => []];
        $text = trim((string) $text);
        if ($text === '') {
            return $result;
        }

        $plain = self::plain($text);

        // 1) Coordonnées glissées dans le texte
        if (preg_match('/(?:\+|00)?\d(?:[\s.\-()]*\d){7,}/', $plain)) {
            return self::block($result, 'numéro de téléphone', 'Ne mets pas de numéro de téléphone dans le texte : les locataires te contactent déjà via REM-CI.');
        }
        if (preg_match('/[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}/', $plain)) {
            return self::block($result, 'adresse e-mail', "Ne mets pas d'adresse e-mail dans le texte : les locataires te contactent déjà via REM-CI.");
        }
        if (preg_match('~(?:https?://|www\.)\S+|\b[a-z0-9\-]+\.(?:com|net|org|ci|fr|app|io|info|me|co)\b~', $plain)) {
            return self::block($result, 'lien internet', 'Ne mets pas de lien internet dans le texte.');
        }
        if (preg_match('/\b(?:whats\s*app|whatsapp|watsap|telegram|facebook|insta(?:gram)?|snap(?:chat)?|tiktok|messenger)\b/', $plain)) {
            return self::block($result, 'réseau social', 'Ne cite pas de réseau social dans le texte : les locataires te contactent déjà via REM-CI.');
        }

        // 2) Propos inappropriés (comparaison sans accents, sans répétition de lettres, avec « leet » : m3rde, p*te…)
        $leet = self::collapse(strtr($plain, ['@' => 'a', '0' => 'o', '$' => 's', '!' => 'i', '1' => 'i', '3' => 'e', '4' => 'a', '5' => 's', '7' => 't', '*' => '', '.' => '']));
        $words = array_merge(
            preg_split('/[^a-z]+/', self::collapse($plain), -1, PREG_SPLIT_NO_EMPTY) ?: [],
            preg_split('/[^a-z]+/', $leet, -1, PREG_SPLIT_NO_EMPTY) ?: []
        );
        $exact = array_map([self::class, 'collapse'], self::OBSCENE_WORDS);
        $stems = array_map([self::class, 'collapse'], self::OBSCENE_STEMS);
        foreach (array_unique($words) as $word) {
            if (in_array($word, $exact, true)) {
                return self::block($result, 'propos inappropriés', 'Ton texte contient des termes inappropriés. Reformule-le de façon respectueuse et professionnelle.');
            }
            foreach ($stems as $stem) {
                if (strlen($stem) >= 5 && str_starts_with($word, $stem)) {
                    return self::block($result, 'propos inappropriés', 'Ton texte contient des termes inappropriés. Reformule-le de façon respectueuse et professionnelle.');
                }
                if (strlen($stem) < 5 && $word === $stem) {
                    return self::block($result, 'propos inappropriés', 'Ton texte contient des termes inappropriés. Reformule-le de façon respectueuse et professionnelle.');
                }
            }
        }

        // 3) Signaux d'alerte : texte accepté mais signalé à l'administrateur
        if (preg_match(self::SCAM_PATTERN, $plain)) {
            $result['flags'][] = "mots typiques d'une arnaque (paiement ou acompte à l'avance…)";
        }
        $letters = preg_replace('/[^\p{L}]/u', '', $text) ?? '';
        if (mb_strlen($letters) >= 30) {
            $upper = preg_replace('/[^\p{Lu}]/u', '', $text) ?? '';
            if (mb_strlen($upper) / mb_strlen($letters) > 0.6) {
                $result['flags'][] = 'texte écrit en majuscules';
            }
        }

        return $result;
    }

    private static function block(array $result, string $reason, string $message): array
    {
        $result['blocked'] = true;
        $result['reason'] = $reason;
        $result['message'] = $message;

        return $result;
    }

    /** Minuscules, sans accents. */
    private static function plain(string $text): string
    {
        $text = mb_strtolower($text, 'UTF-8');

        return strtr($text, [
            'à' => 'a', 'â' => 'a', 'ä' => 'a', 'á' => 'a', 'ã' => 'a', 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
            'î' => 'i', 'ï' => 'i', 'í' => 'i', 'ô' => 'o', 'ö' => 'o', 'ó' => 'o', 'õ' => 'o', 'ù' => 'u', 'û' => 'u',
            'ü' => 'u', 'ú' => 'u', 'ç' => 'c', 'ÿ' => 'y', 'œ' => 'oe', 'æ' => 'ae', 'ñ' => 'n', '’' => "'",
        ]);
    }

    /** « meeerde » → « merde » : une seule lettre pour chaque suite de lettres identiques. */
    private static function collapse(string $word): string
    {
        return preg_replace('/([a-z])\1+/', '$1', $word) ?? $word;
    }
}
