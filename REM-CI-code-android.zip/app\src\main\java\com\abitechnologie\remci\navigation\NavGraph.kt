package com.abitechnologie.remci.navigation

import android.widget.Toast
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.abitechnologie.remci.data.Property
import com.abitechnologie.remci.data.network.SessionEvents
import com.abitechnologie.remci.data.network.TokenManager
import com.abitechnologie.remci.data.AppConfig
import com.abitechnologie.remci.data.network.UserDto
import com.abitechnologie.remci.data.network.toUiModel
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.AuthRepository
import com.abitechnologie.remci.data.repository.SESSION_EXPIRED
import com.abitechnologie.remci.data.repository.PropertyRepository
import com.abitechnologie.remci.ui.screens.*
import kotlinx.coroutines.launch

private object Routes {
    const val SPLASH = "splash"
    const val CHOICE = "choice"
    const val LOGIN = "login"
    const val FORGOT = "forgot_password"
    const val MAIN = "main"
    const val DETAIL = "detail"
    const val BOOKING = "booking"
    const val SUCCESS = "success"
    const val MY_PROPERTIES = "my_properties"
    const val ADD_PROPERTY = "add_property"
    const val OWNER_VERIFICATION = "owner_verification"
    const val RESIDENCE_PENDING = "residence_pending"
    const val TENANT_PROFILE = "tenant_profile"
}

@Composable
fun RemCiNavGraph() {
    val navController: NavHostController = rememberNavController()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val propertyRepository = remember { PropertyRepository() }
    val authRepository = remember { AuthRepository() }

    var role by remember { mutableStateOf(TokenManager.getRole()) }
    var chosenRole by remember { mutableStateOf("locataire") }
    var favorites by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var selectedProperty by remember { mutableStateOf<Property?>(null) }
    // Utilisateur connecté — utilisé pour savoir si un propriétaire doit être redirigé
    // vers la vérification d'identité, et pour pré-remplir ce formulaire.
    var currentUser by remember { mutableStateOf<UserDto?>(null) }
    // Numéro de la dernière demande de réservation envoyée (affiché sur l'écran de succès)
    var lastBookingId by remember { mutableStateOf<Int?>(null) }
    var lastBookingRef by remember { mutableStateOf<String?>(null) }
    // Un invité qui clique sur « S'inscrire » / « J'ai déjà un compte » arrive sur l'écran de
    // connexion ; le bouton retour le ramène alors à la liste des résidences.
    var loginFromGuest by remember { mutableStateOf(false) }
    var loginStartsInRegister by remember { mutableStateOf(false) }
    // Le locataire arrive sur « Mon dossier » en voulant réserver : après l'enregistrement,
    // on le renvoie directement vers la réservation.
    var profileForBooking by remember { mutableStateOf(false) }

    // Garde une copie du profil : l'application peut se rouvrir SANS réseau en restant connectée.
    LaunchedEffect(currentUser) { currentUser?.let { TokenManager.saveUser(it) } }

    // Session expirée (jeton refusé par le serveur) : retour à la connexion avec un message clair.
    LaunchedEffect(Unit) {
        SessionEvents.expired.collect {
            if (TokenManager.isLoggedIn()) {
                TokenManager.clear()
                currentUser = null
                favorites = emptySet()
                Toast.makeText(context, "Ta session a expiré, reconnecte-toi.", Toast.LENGTH_LONG).show()
                navController.navigate(Routes.LOGIN) { popUpTo(navController.graph.id) { inclusive = true } }
            }
        }
    }

    // Charge les vrais favoris du locataire connecté (plus de favoris fictifs au départ)
    LaunchedEffect(currentUser?.id) {
        if (currentUser != null && currentUser?.role == "locataire") {
            val result = propertyRepository.getFavorites()
            if (result is ApiResult.Success) favorites = result.data.map { it.id }.toSet()
        } else if (currentUser == null) {
            favorites = emptySet()
        }
    }

    fun toggleFavorite(id: Int) {
        favorites = if (favorites.contains(id)) favorites - id else favorites + id
        // Appel API en tâche de fond ; si le backend est injoignable, l'état local reste quand même à jour
        if (TokenManager.isLoggedIn()) {
            scope.launch {
                val result = propertyRepository.toggleFavorite(id)
                if (result is ApiResult.Error) {
                    // échec silencieux : on garde l'état local pour ne pas casser l'UX
                }
            }
        }
    }

    /** Propriétaire pas encore certifié -> écran de vérification ; sinon -> accueil normal. */
    fun destinationAfterAuth(user: UserDto?): String =
        if (user != null && user.role == "proprietaire" && user.needsOwnerVerification) {
            Routes.OWNER_VERIFICATION
        } else {
            Routes.MAIN
        }

    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(onFinished = {
                if (TokenManager.isLoggedIn()) {
                    scope.launch {
                        when (val result = authRepository.me()) {
                            is ApiResult.Success -> {
                                currentUser = result.data
                                role = result.data.role
                                navController.navigate(destinationAfterAuth(result.data)) {
                                    popUpTo(Routes.SPLASH) { inclusive = true }
                                }
                            }
                            is ApiResult.Error -> {
                                val cached = TokenManager.getCachedUser()
                                if (result.code == SESSION_EXPIRED || cached == null) {
                                    // Session invalide/expirée (ou jamais mise en cache) — repart proprement
                                    if (result.code == SESSION_EXPIRED) TokenManager.clear()
                                    navController.navigate(Routes.CHOICE) { popUpTo(Routes.SPLASH) { inclusive = true } }
                                } else {
                                    // Pas de réseau : on reste connecté avec le profil enregistré
                                    // (les écrans affichent leur message « Réessayer » si besoin).
                                    currentUser = cached
                                    role = cached.role
                                    Toast.makeText(context, "Mode hors connexion : certaines informations peuvent être anciennes.", Toast.LENGTH_LONG).show()
                                    navController.navigate(destinationAfterAuth(cached)) {
                                        popUpTo(Routes.SPLASH) { inclusive = true }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    navController.navigate(Routes.CHOICE) { popUpTo(Routes.SPLASH) { inclusive = true } }
                }
            })
        }

        composable(Routes.CHOICE) {
            ProfileChoiceScreen(onChoose = { r ->
                chosenRole = r
                loginFromGuest = false
                loginStartsInRegister = false
                navController.navigate(Routes.LOGIN)
            })
        }

        composable(Routes.LOGIN) {
            LoginScreen(
                initialRole = chosenRole,
                startInRegister = loginStartsInRegister,
                onLogin = { user ->
                    role = user.role
                    currentUser = user
                    loginFromGuest = false
                    // On vide toute la pile (accueil invité compris) avant d'ouvrir l'espace connecté.
                    navController.navigate(destinationAfterAuth(user)) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                },
                onGuest = {
                    if (loginFromGuest) {
                        loginFromGuest = false
                        navController.popBackStack()
                    } else {
                        role = "locataire"
                        currentUser = null
                        navController.navigate(Routes.MAIN) { popUpTo(Routes.SPLASH) { inclusive = true } }
                    }
                },
                onBack = {
                    if (loginFromGuest) {
                        loginFromGuest = false
                        navController.popBackStack()
                    } else {
                        navController.navigate(Routes.CHOICE) { popUpTo(Routes.LOGIN) { inclusive = true } }
                    }
                },
                onForgotPassword = { navController.navigate(Routes.FORGOT) }
            )
        }

        composable(Routes.FORGOT) {
            ForgotPasswordScreen(
                onBack = { navController.popBackStack() },
                onDone = { navController.popBackStack() }
            )
        }

        composable(Routes.MAIN) {
            val logout = {
                scope.launch { authRepository.logout() }
                chosenRole = if (role == "proprietaire") "proprietaire" else "locataire"
                currentUser = null
                loginFromGuest = false
                loginStartsInRegister = false
                navController.navigate(Routes.LOGIN) { popUpTo(Routes.MAIN) { inclusive = true } }
            }
            if (role == "proprietaire") {
                // Un propriétaire a son propre tableau de bord (résidences, réservations
                // reçues) — distinct de l'espace locataire.
                OwnerMainScreen(
                    user = currentUser,
                    onAddProperty = {
                        val needsVerification = currentUser?.needsOwnerVerification == true
                        navController.navigate(if (needsVerification) Routes.OWNER_VERIFICATION else Routes.ADD_PROPERTY)
                    },
                    onLogout = logout,
                    onUserUpdated = { currentUser = it },
                    onOpenVerification = { navController.navigate(Routes.OWNER_VERIFICATION) }
                )
            } else {
                MainScreen(
                    role = role,
                    favorites = favorites,
                    onToggleFavorite = ::toggleFavorite,
                    onOpenProperty = { p ->
                        selectedProperty = p
                        navController.navigate(Routes.DETAIL)
                    },
                    onLogout = logout,
                    onMyProperties = { navController.navigate(Routes.MY_PROPERTIES) },
                    user = currentUser,
                    onUserUpdated = { currentUser = it },
                    onOpenTenantProfile = {
                        profileForBooking = false
                        scope.launch {
                            (authRepository.me() as? ApiResult.Success)?.let { currentUser = it.data }
                            navController.navigate(Routes.TENANT_PROFILE)
                        }
                    },
                    onRequestRegister = {
                        chosenRole = "locataire"
                        loginFromGuest = true
                        loginStartsInRegister = true
                        navController.navigate(Routes.LOGIN)
                    },
                    onRequestLogin = {
                        chosenRole = "locataire"
                        loginFromGuest = true
                        loginStartsInRegister = false
                        navController.navigate(Routes.LOGIN)
                    }
                )
            }
        }

        composable(Routes.DETAIL) {
            selectedProperty?.let { p ->
                // La liste ne contient pas toutes les infos (hébergeur, commodités, description) :
                // on charge la fiche complète dès l'ouverture, sans bloquer l'affichage.
                LaunchedEffect(p.id) {
                    val full = propertyRepository.getProperty(p.id)
                    if (full is ApiResult.Success) selectedProperty = full.data.toUiModel()
                }
                DetailScreen(
                    property = p,
                    isFavorite = favorites.contains(p.id),
                    onBack = { navController.popBackStack() },
                    onToggleFavorite = ::toggleFavorite,
                    onBook = {
                        // Sécurité : une réservation exige un compte (un invité n'arrive normalement pas ici).
                        if (TokenManager.isLoggedIn()) {
                            // On relit toujours le profil sur le serveur avant de décider : le dossier a
                            // pu être enregistré ou validé depuis l'écran précédent ou par l'administrateur.
                            scope.launch {
                                val fresh = authRepository.me()
                                if (fresh is ApiResult.Success) currentUser = fresh.data
                                else if (fresh is ApiResult.Error && fresh.code != SESSION_EXPIRED) {
                                    Toast.makeText(context, fresh.message, Toast.LENGTH_LONG).show()
                                }
                                if (currentUser?.tenantProfileComplete == true) {
                                    navController.navigate(Routes.BOOKING)
                                } else {
                                    // Dossier locataire (identité, âge, adresse, pièce) à compléter d'abord
                                    profileForBooking = true
                                    navController.navigate(Routes.TENANT_PROFILE)
                                }
                            }
                        } else {
                            chosenRole = "locataire"
                            loginFromGuest = true
                            loginStartsInRegister = true
                            navController.navigate(Routes.LOGIN)
                        }
                    }
                )
            }
        }

        composable(Routes.BOOKING) {
            // Compteur « x / 3 demandes aujourd'hui » toujours à jour (et nouveau jour = compteur remis à zéro)
            LaunchedEffect(Unit) {
                (authRepository.me() as? ApiResult.Success)?.let { currentUser = it.data }
            }
            selectedProperty?.let { p ->
                BookingScreen(
                    property = p,
                    bookingsToday = currentUser?.bookingsToday ?: 0,
                    dailyLimit = currentUser?.dailyBookingLimit ?: 3,
                    onBack = { navController.popBackStack() },
                    onNeedProfile = {
                        scope.launch {
                            (authRepository.me() as? ApiResult.Success)?.let { currentUser = it.data }
                            profileForBooking = true
                            navController.navigate(Routes.TENANT_PROFILE) { popUpTo(Routes.BOOKING) { inclusive = true } }
                        }
                    },
                    onConfirm = { bookingId, reference ->
                        lastBookingId = bookingId
                        lastBookingRef = reference
                        currentUser = currentUser?.let { it.copy(bookingsToday = it.bookingsToday + 1) }
                        navController.navigate(Routes.SUCCESS)
                    }
                )
            }
        }

        composable(Routes.TENANT_PROFILE) {
            TenantProfileScreen(
                user = currentUser,
                forBooking = profileForBooking,
                onBack = { profileForBooking = false; navController.popBackStack() },
                onSaved = { updated ->
                    currentUser = updated
                    Toast.makeText(context, "Dossier enregistré ✓", Toast.LENGTH_SHORT).show()
                    if (profileForBooking) {
                        profileForBooking = false
                        navController.navigate(Routes.BOOKING) { popUpTo(Routes.TENANT_PROFILE) { inclusive = true } }
                    } else {
                        navController.popBackStack()
                    }
                }
            )
        }

        composable(Routes.SUCCESS) {
            SuccessScreen(
                onHome = { navController.navigate(Routes.MAIN) { popUpTo(Routes.MAIN) { inclusive = true } } },
                title = "Demande envoyée !",
                message = "Le propriétaire a été prévenu. Finalise les derniers détails directement avec lui " +
                    "(WhatsApp ou appel). Retrouve ta demande dans l'onglet Réservations.",
                reference = lastBookingRef ?: lastBookingId?.let { "REMCI-%04d".format(it) },
                homeLabel = "Retour à l'accueil"
            )
        }

        composable(Routes.MY_PROPERTIES) {
            OwnerPropertiesScreen(
                onBack = { navController.popBackStack() },
                onAddProperty = {
                    // Un propriétaire qui n'a pas encore soumis son dossier d'identité
                    // passe d'abord par la vérification, même s'il est arrivé ici directement.
                    val needsVerification = currentUser?.needsOwnerVerification == true
                    navController.navigate(if (needsVerification) Routes.OWNER_VERIFICATION else Routes.ADD_PROPERTY)
                }
            )
        }

        composable(Routes.ADD_PROPERTY) {
            AddPropertyScreen(
                onBack = { navController.popBackStack() },
                onCreated = { navController.navigate(Routes.RESIDENCE_PENDING) { popUpTo(Routes.MAIN) } }
            )
        }

        composable(Routes.OWNER_VERIFICATION) {
            OwnerVerificationScreen(
                initialName = currentUser?.name ?: "",
                initialPhone = currentUser?.phone ?: "",
                onSubmitted = {
                    // Dossier refusé puis renvoyé depuis le profil : on revient simplement au profil.
                    val resubmission = currentUser?.ownerVerificationStatus == "rejected"
                    currentUser = currentUser?.copy(needsOwnerVerification = false, ownerVerificationStatus = "pending")
                    if (resubmission) {
                        navController.popBackStack()
                    } else {
                        // Le dossier est envoyé (en attente de certification manuelle par
                        // l'administrateur) ; le propriétaire passe directement au formulaire
                        // de sa résidence.
                        navController.navigate(Routes.ADD_PROPERTY) { popUpTo(Routes.OWNER_VERIFICATION) { inclusive = true } }
                    }
                }
            )
        }

        composable(Routes.RESIDENCE_PENDING) {
            SuccessScreen(
                onHome = { navController.navigate(Routes.MAIN) { popUpTo(Routes.MAIN) { inclusive = true } } },
                title = "Résidence enregistrée !",
                message = "Ta demande est en attente de validation. Contacte l'administrateur REM-CI au " +
                    "${AppConfig.ADMIN_PHONES_TEXT} pour la faire valider : tu seras prévenu dès qu'elle sera publiée " +
                    "et visible par les locataires.",
                homeLabel = "Retour à l'accueil"
            )
        }
    }
}
