package com.abitechnologie.remci.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.AuthRepository
import com.abitechnologie.remci.ui.components.clickableNoRipple
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Mot de passe oublié — sans passer par l'administrateur :
 *  1) on saisit son numéro (ou e-mail) → un code à 6 chiffres est envoyé par e-mail ;
 *  2) on saisit le code + un nouveau mot de passe ;
 *  3) confirmation, retour à la connexion.
 */
@Composable
fun ForgotPasswordScreen(
    initialIdentifier: String = "",
    onBack: () -> Unit,
    onDone: () -> Unit
) {
    var step by remember { mutableStateOf(1) }
    var identifier by remember { mutableStateOf(initialIdentifier) }
    var code by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var showPwd by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var emailHint by remember { mutableStateOf<String?>(null) }
    var cooldown by remember { mutableStateOf(0) }
    var resendTick by remember { mutableStateOf(0) }

    val scope = rememberCoroutineScope()
    val repository = remember { AuthRepository() }
    val focusManager = LocalFocusManager.current

    // Compte à rebours avant de pouvoir redemander un code
    LaunchedEffect(step, resendTick) {
        if (step == 2) {
            cooldown = 60
            while (cooldown > 0) {
                delay(1000)
                cooldown--
            }
        }
    }

    fun sendCode(isResend: Boolean) {
        if (identifier.isBlank()) {
            error = "Indique ton numéro de téléphone ou ton adresse e-mail."
            return
        }
        error = null
        focusManager.clearFocus()
        loading = true
        scope.launch {
            when (val result = repository.forgotPassword(identifier.trim())) {
                is ApiResult.Success -> {
                    emailHint = result.data.emailHint
                    if (isResend) resendTick++ else step = 2
                }
                is ApiResult.Error -> error = result.message
            }
            loading = false
        }
    }

    fun resetPassword() {
        error = when {
            code.length != 6 -> "Saisis le code à 6 chiffres reçu par e-mail."
            password.length < 6 -> "Le mot de passe doit contenir au moins 6 caractères."
            password != confirm -> "Les deux mots de passe ne sont pas identiques."
            else -> null
        }
        if (error != null) return
        focusManager.clearFocus()
        loading = true
        scope.launch {
            when (val result = repository.resetPassword(identifier.trim(), code, password, confirm)) {
                is ApiResult.Success -> step = 3
                is ApiResult.Error -> error = result.message
            }
            loading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .imePadding()
            .verticalScroll(rememberScrollState())
    ) {
        // ---------- En-tête ----------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        0f to Color(0xFFFFA43D),
                        0.30f to Orange,
                        0.62f to Color(0xFF2E8354),
                        1f to GreenDeep
                    ),
                    RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp)
                    .padding(top = 10.dp, bottom = 56.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    if (step != 3) {
                        IconButton(
                            onClick = { if (step == 2) { step = 1; error = null; code = "" } else onBack() },
                            modifier = Modifier.size(38.dp).background(Color.White.copy(alpha = 0.2f), CircleShape)
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Retour", tint = Color.White, modifier = Modifier.size(19.dp))
                        }
                    } else {
                        Spacer(Modifier.size(38.dp))
                    }
                }
                Box(
                    modifier = Modifier.size(64.dp).background(Color.White.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        when (step) { 1 -> Icons.Default.Lock; 2 -> Icons.Default.MarkEmailRead; else -> Icons.Default.CheckCircle },
                        contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    when (step) { 1 -> "Mot de passe oublié ?"; 2 -> "Vérifie tes e-mails"; else -> "C'est fait !" },
                    fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White
                )
                Text(
                    when (step) {
                        1 -> "Pas de panique, on t'envoie un code par e-mail."
                        2 -> "Un code à 6 chiffres a été envoyé" + (emailHint?.let { " à $it" } ?: "") + "."
                        else -> "Ton mot de passe a été modifié."
                    },
                    fontSize = 12.sp, color = Color.White.copy(alpha = 0.92f), textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, start = 10.dp, end = 10.dp)
                )
            }
        }

        // ---------- Carte ----------
        Surface(
            color = CardBg,
            shape = RoundedCornerShape(24.dp),
            shadowElevation = 8.dp,
            modifier = Modifier
                .padding(horizontal = 18.dp)
                .offset(y = (-32).dp)
                .fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                when (step) {
                    1 -> {
                        RemField(
                            label = "Numéro de téléphone ou e-mail du compte",
                            value = identifier, onChange = { identifier = it },
                            leading = Icons.Default.Person, placeholder = "07 00 00 00 00 ou toi@gmail.com",
                            keyboardType = KeyboardType.Email, imeAction = ImeAction.Done,
                            onDone = { sendCode(false) }
                        )
                        Text(
                            "Le code est envoyé à l'adresse e-mail enregistrée sur ton compte.",
                            fontSize = 11.sp, color = Sub, lineHeight = 15.sp, modifier = Modifier.padding(top = 8.dp, start = 2.dp)
                        )
                    }

                    2 -> {
                        Text("Code reçu par e-mail", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = code,
                            onValueChange = { v -> code = v.filter { it.isDigit() }.take(6) },
                            placeholder = {
                                Text(
                                    "••••••", color = Color(0xFFC9CCC6), fontSize = 24.sp, letterSpacing = 8.sp,
                                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                                )
                            },
                            textStyle = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 8.sp, textAlign = TextAlign.Center, color = Ink),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Green,
                                unfocusedBorderColor = Color(0xFFE2DCCB),
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color(0xFFFBF9F4),
                                cursorColor = Green
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(Modifier.height(16.dp))
                        RemField(
                            label = "Nouveau mot de passe", value = password, onChange = { password = it },
                            leading = Icons.Default.Lock, placeholder = "6 caractères minimum",
                            keyboardType = KeyboardType.Password, imeAction = ImeAction.Next,
                            onNext = { focusManager.moveFocus(FocusDirection.Down) },
                            visualTransformation = if (showPwd) VisualTransformation.None else PasswordVisualTransformation(),
                            trailing = {
                                IconButton(onClick = { showPwd = !showPwd }) {
                                    Icon(
                                        if (showPwd) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (showPwd) "Masquer" else "Afficher",
                                        tint = Sub, modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        )
                        Spacer(Modifier.height(14.dp))
                        RemField(
                            label = "Confirmer le mot de passe", value = confirm, onChange = { confirm = it },
                            leading = Icons.Default.Lock, placeholder = "••••••••",
                            keyboardType = KeyboardType.Password, imeAction = ImeAction.Done,
                            onDone = { resetPassword() },
                            visualTransformation = if (showPwd) VisualTransformation.None else PasswordVisualTransformation()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            if (cooldown > 0) {
                                Text("Renvoyer le code dans ${cooldown}s", fontSize = 12.sp, color = Sub)
                            } else {
                                Text(
                                    "Renvoyer le code", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Blue,
                                    modifier = Modifier.clickableNoRipple { if (!loading) sendCode(true) }
                                )
                            }
                        }
                        Text(
                            "Pense à regarder dans les courriers indésirables (spam).",
                            fontSize = 10.5.sp, color = Sub, textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                        )
                    }

                    else -> {
                        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier.size(70.dp).background(Green.copy(alpha = 0.10f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Green, modifier = Modifier.size(38.dp)) }
                            Spacer(Modifier.height(14.dp))
                            Text(
                                "Tu peux maintenant te connecter avec ton nouveau mot de passe. Pour ta sécurité, les anciennes sessions ont été fermées.",
                                fontSize = 12.5.sp, lineHeight = 18.sp, color = Ink, textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                AnimatedVisibility(
                    visible = error != null,
                    enter = fadeIn(tween(200)) + expandVertically(tween(200)),
                    exit = fadeOut(tween(120)) + shrinkVertically(tween(120))
                ) {
                    Row(
                        modifier = Modifier
                            .padding(top = 14.dp)
                            .fillMaxWidth()
                            .background(Color(0xFFFDECE4), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = OrangeDeep, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(error ?: "", color = OrangeDeep, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, lineHeight = 15.sp)
                    }
                }

                Spacer(Modifier.height(18.dp))
                Button(
                    onClick = {
                        when (step) {
                            1 -> sendCode(false)
                            2 -> resetPassword()
                            else -> onDone()
                        }
                    },
                    enabled = !loading,
                    colors = ButtonDefaults.buttonColors(containerColor = Orange, disabledContainerColor = Orange.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) {
                    if (loading) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
                    } else {
                        Text(
                            when (step) { 1 -> "Recevoir le code"; 2 -> "Modifier mon mot de passe"; else -> "Se connecter" },
                            fontWeight = FontWeight.ExtraBold, fontSize = 15.sp
                        )
                    }
                }
            }
        }

        Spacer(Modifier.navigationBarsPadding().height(8.dp))
    }
}
