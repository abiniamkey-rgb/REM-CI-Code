package com.abitechnologie.remci.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import kotlinx.coroutines.launch
import com.abitechnologie.remci.data.AppConfig
import com.abitechnologie.remci.data.network.PropertyDto
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.PropertyRepository
import com.abitechnologie.remci.ui.components.AvailabilityPill
import com.abitechnologie.remci.ui.components.CircleIconButton
import com.abitechnologie.remci.ui.components.formatFcfa
import com.abitechnologie.remci.ui.theme.*

/**
 * "Mes résidences" — le propriétaire voit toutes ses annonces, y compris celles en
 * attente d'activation manuelle par l'administrateur REM-CI (plus de paiement de
 * publication : l'activation se fait désormais côté administration, après vérification
 * d'identité du propriétaire).
 */
@Composable
fun OwnerPropertiesScreen(
    onBack: (() -> Unit)? = null,
    onAddProperty: () -> Unit,
    /** Ouvre l'écran de modification d'une résidence (absent = pas de bouton Modifier). */
    onEditProperty: ((PropertyDto) -> Unit)? = null,
    /** Change après une modification enregistrée pour recharger la liste. */
    refreshKey: Int = 0
) {
    val repository = remember { PropertyRepository() }
    var properties by remember { mutableStateOf<List<PropertyDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    // Résidence dont la disponibilité est en cours de modification (évite les doubles appuis)
    var busyId by remember { mutableStateOf<Int?>(null) }

    fun setAvailable(p: PropertyDto, value: Boolean) {
        if (busyId != null) return
        busyId = p.id
        scope.launch {
            when (val r = repository.setAvailability(p.id, value)) {
                is ApiResult.Success -> {
                    properties = properties.map { if (it.id == p.id) it.copy(isAvailable = value) else it }
                    Toast.makeText(
                        context,
                        if (value) "Résidence disponible : les locataires la voient en bleu."
                        else "Résidence occupée : les locataires la voient en rouge.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                is ApiResult.Error -> Toast.makeText(context, r.message, Toast.LENGTH_LONG).show()
            }
            busyId = null
        }
    }

    LaunchedEffect(reload, refreshKey) {
        loading = true
        when (val result = repository.getMyProperties()) {
            is ApiResult.Success -> { properties = result.data; error = null }
            is ApiResult.Error -> error = result.message
        }
        loading = false
    }

    // Limite : 5 résidences (en attente + publiées) par compte
    val usedSlots = properties.count { it.status == "pending" || it.status == "active" }
    val limitReached = usedSlots >= AppConfig.MAX_PROPERTIES_PER_OWNER
    val limitMessage = "Tu as atteint la limite de ${AppConfig.MAX_PROPERTIES_PER_OWNER} résidences par compte. " +
        "Pour en ajouter une autre, contacte l'administrateur REM-CI au ${AppConfig.ADMIN_PHONES_TEXT}."

    Column(modifier = Modifier.fillMaxSize().background(Bg).then(if (onBack != null) Modifier.statusBarsPadding() else Modifier)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) {
                    CircleIconButton(Icons.Default.ArrowBack, onBack)
                    Spacer(Modifier.width(10.dp))
                }
                Column {
                    Text("Mes résidences", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
                    if (!loading) {
                        Text(
                            "$usedSlots/${AppConfig.MAX_PROPERTIES_PER_OWNER} résidences",
                            fontSize = 11.sp, color = if (limitReached) OrangeDeep else Sub
                        )
                    }
                }
            }
            Button(
                onClick = {
                    if (limitReached) Toast.makeText(context, limitMessage, Toast.LENGTH_LONG).show()
                    else onAddProperty()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Orange),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(4.dp))
                Text("Ajouter", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
            }
        }

        when {
            loading -> Box(Modifier.fillMaxWidth().padding(50.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Orange, modifier = Modifier.size(28.dp))
            }
            error != null -> Column(
                modifier = Modifier.fillMaxWidth().padding(36.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.CloudOff, contentDescription = null, tint = Sub, modifier = Modifier.size(32.dp))
                Spacer(Modifier.height(10.dp))
                Text(error ?: "", fontSize = 12.5.sp, color = Sub, textAlign = TextAlign.Center)
                TextButton(onClick = { reload++ }) { Text("Réessayer", color = Orange, fontWeight = FontWeight.Bold) }
            }
            properties.isEmpty() -> Column(
                modifier = Modifier.fillMaxWidth().padding(40.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.Apartment, contentDescription = null, tint = Sub, modifier = Modifier.size(32.dp))
                Spacer(Modifier.height(10.dp))
                Text(
                    "Aucune résidence pour l'instant. Ajoute ta première résidence pour commencer à recevoir des réservations.",
                    fontSize = 12.5.sp, color = Sub, textAlign = TextAlign.Center
                )
            }
            else -> Column(
                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                properties.forEach { p -> OwnerPropertyRow(p, busy = busyId == p.id, onAvailabilityChange = { setAvailable(p, it) }, onEdit = onEditProperty?.let { edit -> { edit(p) } }) }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun OwnerPropertyRow(p: PropertyDto, busy: Boolean, onAvailabilityChange: (Boolean) -> Unit, onEdit: (() -> Unit)?) {
    val (label, color) = when (p.status) {
        "active" -> "Publiée ✓" to Green
        "inactive" -> "Retirée" to Sub
        else -> "En attente de validation" to OrangeDeep
    }
    val photoCount = p.photos?.size ?: 0

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(16.dp))
            .border(1.dp, Divider, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(Green, GreenDeep)))
            ) {
                p.photos?.firstOrNull()?.let {
                    AsyncImage(model = com.abitechnologie.remci.data.network.secureUrl(it), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(p.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "${p.city?.name ?: ""} · ${formatFcfa(p.pricePerNight)} FCFA/nuit",
                    fontSize = 11.sp, color = Sub, modifier = Modifier.padding(top = 2.dp)
                )
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 5.dp)) {
                    Text(
                        label,
                        fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White,
                        modifier = Modifier
                            .background(color, RoundedCornerShape(20.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = Sub, modifier = Modifier.size(12.dp))
                    Text(" $photoCount", fontSize = 10.5.sp, color = Sub)
                }
            }
        }
        // Corriger l'annonce à tout moment (faute de frappe, nouvelle commodité, nouveau prix…)
        if (onEdit != null) {
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = onEdit,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text("Modifier l'annonce", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        // Disponibilité : seul le propriétaire sait si la résidence est libre (le paiement se fait hors application)
        if (p.status == "active") {
            val available = p.isAvailable != false
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Divider))
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    AvailabilityPill(available, modifier = Modifier.border(1.dp, Divider, RoundedCornerShape(20.dp)))
                    Text(
                        if (available) "Les locataires peuvent envoyer des demandes."
                        else "Les demandes sont bloquées tant qu'elle est occupée.",
                        fontSize = 10.5.sp, color = Sub, lineHeight = 14.sp, modifier = Modifier.padding(top = 5.dp)
                    )
                }
                Spacer(Modifier.width(10.dp))
                Switch(
                    checked = available,
                    onCheckedChange = onAvailabilityChange,
                    enabled = !busy,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White, checkedTrackColor = Blue,
                        uncheckedThumbColor = Color.White, uncheckedTrackColor = Danger,
                        uncheckedBorderColor = Danger
                    )
                )
            }
        }
        if (p.status == "pending") {
            Text(
                "Pour la faire valider, contacte l'administrateur REM-CI au ${AppConfig.ADMIN_PHONES_TEXT}.",
                fontSize = 10.5.sp, color = Sub, lineHeight = 15.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
