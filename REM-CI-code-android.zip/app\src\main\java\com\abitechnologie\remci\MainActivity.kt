package com.abitechnologie.remci

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.abitechnologie.remci.data.network.TokenManager
import com.abitechnologie.remci.navigation.RemCiNavGraph
import com.abitechnologie.remci.ui.theme.Bg
import com.abitechnologie.remci.ui.theme.RemCiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TokenManager.init(this)
        cleanOldCaptures()
        enableEdgeToEdge()
        setContent {
            RemCiTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    RemCiNavGraph()
                }
            }
        }
    }

    /**
     * Sécurité / vie privée : les photos prises (pièces d'identité, résidences) et les reçus PDF
     * restent dans le cache de l'app après l'envoi. On efface ceux de plus de 2 heures à chaque
     * démarrage (une capture en cours, plus récente, n'est pas touchée).
     */
    private fun cleanOldCaptures() {
        val limit = System.currentTimeMillis() - 2 * 60 * 60 * 1000L
        Thread {
            listOf("camera", "receipts").forEach { name ->
                java.io.File(cacheDir, name).listFiles()?.forEach { f ->
                    if (f.isFile && f.lastModified() < limit) f.delete()
                }
            }
        }.start()
    }
}
