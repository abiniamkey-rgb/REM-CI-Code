package com.abitechnologie.remci.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.abitechnologie.remci.ui.theme.*

/**
 * Messages affichés aux visiteurs sans compte (mode invité) selon l'action tentée.
 * Un invité peut parcourir la liste des résidences ; tout le reste demande un compte.
 */
object GuestMessages {
    const val PROPERTY = "Inscris-toi gratuitement pour voir toutes les informations de cette résidence, " +
        "contacter le propriétaire et faire une réservation."
    const val FAVORITE = "Inscris-toi gratuitement pour enregistrer tes résidences préférées et les retrouver à tout moment."
    const val NOTIFICATIONS = "Inscris-toi gratuitement pour recevoir tes notifications (réponses des propriétaires, confirmations…)."
    const val BOOKING = "Inscris-toi gratuitement pour réserver une résidence meublée et suivre tes demandes."
}

/**
 * Fenêtre « Crée ton compte » : affichée quand un invité clique sur une résidence,
 * un favori, la cloche… Elle l'invite à s'inscrire (ou à se connecter s'il a déjà un compte).
 */
@Composable
fun GuestGateDialog(
    message: String,
    onRegister: () -> Unit,
    onLogin: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = CardBg) {
            GuestGateContent(
                title = "Inscris-toi pour mieux profiter de l'application",
                message = message,
                onRegister = onRegister,
                onLogin = onLogin,
                onLater = onDismiss,
                modifier = Modifier.padding(22.dp)
            )
        }
    }
}

/** Page pleine hauteur pour les onglets réservés aux inscrits (Réservations, Favoris, Profil). */
@Composable
fun GuestGateScreen(
    icon: ImageVector,
    title: String,
    message: String,
    onRegister: () -> Unit,
    onLogin: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize().background(Bg).statusBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        GuestGateContent(
            icon = icon,
            title = title,
            message = message,
            onRegister = onRegister,
            onLogin = onLogin,
            onLater = null,
            modifier = Modifier.padding(28.dp)
        )
    }
}

@Composable
private fun GuestGateContent(
    title: String,
    message: String,
    onRegister: () -> Unit,
    onLogin: () -> Unit,
    onLater: (() -> Unit)?,
    modifier: Modifier = Modifier,
    icon: ImageVector = Icons.Default.Lock
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(64.dp).background(Orange.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Orange, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text(
            title, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = Ink,
            textAlign = TextAlign.Center
        )
        Text(
            message, fontSize = 13.sp, lineHeight = 19.sp, color = Sub, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = onRegister,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = androidx.compose.ui.graphics.Color.White),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text("Créer mon compte", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = onLogin,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text("J'ai déjà un compte", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = Ink)
        }
        if (onLater != null) {
            TextButton(onClick = onLater, modifier = Modifier.padding(top = 2.dp)) {
                Text("Plus tard", color = Sub, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
        }
    }
}
