package com.abitechnologie.remci.data.repository

import com.abitechnologie.remci.data.ImageCompressor
import com.abitechnologie.remci.data.network.ChangePasswordRequest
import com.abitechnologie.remci.data.network.DeleteAccountRequest
import com.abitechnologie.remci.data.network.TokenManager
import com.abitechnologie.remci.data.network.NotificationsResponse
import com.abitechnologie.remci.data.network.RetrofitClient
import com.abitechnologie.remci.data.network.UserDto
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

/** Profil de l'utilisateur connecté (infos, photo, mot de passe) et ses notifications. */
class ProfileRepository {
    private val api = RetrofitClient.api

    suspend fun updateProfile(name: String, phone: String, email: String): ApiResult<UserDto> = try {
        val response = api.updateProfile(mapOf("name" to name, "phone" to phone, "email" to email))
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible d'enregistrer les modifications"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /** Envoie la photo de profil (réduite à 800 px avant l'envoi). */
    suspend fun uploadAvatar(photo: File): ApiResult<UserDto> = try {
        val file = ImageCompressor.compressForUpload(photo, maxSide = 800, quality = 85)
        val part = MultipartBody.Part.createFormData(
            "avatar", file.name, file.asRequestBody("image/jpeg".toMediaTypeOrNull())
        )
        val response = api.uploadAvatar(part)
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible d'envoyer la photo"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    suspend fun changePassword(current: String, new: String, confirmation: String): ApiResult<String> = try {
        val response = api.changePassword(ChangePasswordRequest(current, new, confirmation))
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.message)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible de modifier le mot de passe"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /**
     * Supprime définitivement le compte. En cas de succès la session locale est effacée
     * (le jeton n'existe plus côté serveur) ; l'appelant renvoie ensuite vers la connexion.
     */
    suspend fun deleteAccount(password: String, confirmation: String): ApiResult<String> = try {
        val response = api.deleteAccount(DeleteAccountRequest(confirmation, password.ifBlank { null }))
        if (response.isSuccessful) {
            TokenManager.clear()
            ApiResult.Success(response.body()?.message ?: "Compte supprimé")
        } else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible de supprimer le compte"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    suspend fun notifications(): ApiResult<NotificationsResponse> = try {
        val response = api.getNotifications()
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!)
        else ApiResult.Error("Impossible de charger les notifications")
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    suspend fun markAllNotificationsRead() {
        try { api.readAllNotifications() } catch (_: Exception) { }
    }
}
