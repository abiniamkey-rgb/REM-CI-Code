@extends('legal.layout')
@section('title', 'Politique de confidentialité')
@section('description', "Comment REM-CI collecte, utilise et protège vos données personnelles.")
@section('content')
  <h1>Politique de confidentialité</h1>
  <p class="upd">Dernière mise à jour : {{ config('remci.legal_updated_at') }}</p>

  <p>Cette politique explique quelles données l'application mobile et le site <strong>REM-CI</strong> (édités par <strong>{{ config('remci.company') }}</strong>, Côte d'Ivoire) collectent, pourquoi, avec qui elles sont partagées et comment vous pouvez les contrôler. Elle est rédigée conformément à la loi ivoirienne n° 2013-450 du 19 juin 2013 relative à la protection des données à caractère personnel.</p>

  <h2>1. Responsable du traitement</h2>
  <p>{{ config('remci.company') }} — contact : <a href="mailto:{{ config('remci.contact_email') }}">{{ config('remci.contact_email') }}</a>, téléphone {{ implode(' / ', config('remci.admin_phones')) }}.</p>

  <h2>2. Données que nous collectons</h2>
  <table>
    <tr><th>Catégorie</th><th>Détail</th><th>Pourquoi</th></tr>
    <tr><td>Compte</td><td>Nom, numéro de téléphone, adresse e-mail (facultative selon le mode d'inscription), mot de passe (stocké chiffré, jamais lisible), rôle (locataire ou propriétaire), photo de profil facultative.</td><td>Créer et sécuriser votre compte, vous identifier auprès de l'autre partie d'une réservation.</td></tr>
    <tr><td>Connexion avec Google</td><td>Nom, adresse e-mail et identifiant Google, si vous choisissez cette option.</td><td>Vous connecter sans mot de passe. Nous ne recevons jamais votre mot de passe Google.</td></tr>
    <tr><td>Dossier locataire</td><td>Date de naissance, adresse, type et numéro de pièce d'identité, photos recto/verso de la pièce.</td><td>Vérifier que le locataire est majeur et identifiable avant d'autoriser des réservations. Limiter la fraude.</td></tr>
    <tr><td>Dossier propriétaire</td><td>Photos recto/verso de la pièce d'identité, nom et numéro de la pièce lus automatiquement sur votre téléphone.</td><td>Certifier l'identité du propriétaire avant la publication de ses annonces.</td></tr>
    <tr><td>Annonces</td><td>Titre, description, adresse, prix, équipements, photos, position GPS relevée au moment des photos (si vous l'autorisez).</td><td>Publier et modérer les résidences, éviter les annonces fictives.</td></tr>
    <tr><td>Réservations</td><td>Dates, nombre de voyageurs, résidence, statut, numéro de reçu.</td><td>Gérer les demandes, émettre le reçu avec code QR et le vérifier.</td></tr>
    <tr><td>Usage</td><td>Favoris, notifications reçues, journaux techniques du serveur (adresse IP, date, type d'appareil).</td><td>Faire fonctionner l'application, la sécuriser et corriger les erreurs.</td></tr>
  </table>
  <p>REM-CI <strong>ne collecte aucune donnée de paiement</strong> : il n'y a aucun paiement dans l'application.</p>

  <h2>3. Autorisations demandées sur votre téléphone</h2>
  <ul>
    <li><strong>Localisation</strong> (facultative) : uniquement quand un propriétaire ajoute une résidence, pour enregistrer l'emplacement de la photo. Vous pouvez refuser, l'ajout reste possible.</li>
    <li><strong>Appareil photo</strong> : les photos sont prises avec l'application appareil photo de votre téléphone ou le scanner de document Google, uniquement pour votre pièce d'identité, votre photo de profil et les photos de résidence.</li>
    <li><strong>Internet</strong> : indispensable pour communiquer avec nos serveurs.</li>
  </ul>

  <h2>4. Avec qui sont partagées vos données</h2>
  <ul>
    <li><strong>L'autre partie d'une réservation</strong> : lorsqu'une demande est envoyée, le propriétaire voit le nom et le téléphone du locataire, et le locataire voit le nom et le téléphone du propriétaire, afin de pouvoir se contacter. Le reçu public affiche seulement le nom du locataire abrégé (ex. « Kouassi A. »).</li>
    <li><strong>Les visiteurs</strong> : les annonces publiées (photos, description, ville, prix, nom et contact du propriétaire) sont visibles par les utilisateurs de l'application.</li>
    <li><strong>L'équipe d'administration REM-CI</strong> : seule elle peut consulter les pièces d'identité, uniquement pour les vérifier. Elles ne sont jamais affichées aux autres utilisateurs.</li>
    <li><strong>Prestataires techniques</strong> : hébergement des serveurs, Google (connexion avec Google, services Google Play : localisation et scanner de document). Ils n'agissent que pour faire fonctionner le service.</li>
  </ul>
  <p>Nous <strong>ne vendons pas</strong> vos données et ne les utilisons pas pour de la publicité ciblée.</p>

  <h2>5. Sécurité</h2>
  <p>Les échanges avec nos serveurs sont chiffrés (HTTPS). Les mots de passe sont chiffrés de façon irréversible. Les pièces d'identité sont stockées dans un espace privé, non accessible par un lien public. Les annonces et les textes sont contrôlés pour limiter les contenus inappropriés. Aucun système n'étant infaillible, nous vous invitons à garder votre mot de passe confidentiel.</p>

  <h2>6. Durée de conservation</h2>
  <ul>
    <li>Les données du compte et les pièces d'identité sont conservées tant que le compte est actif.</li>
    <li>À la suppression du compte, votre profil, vos pièces d'identité, votre photo, vos favoris, vos notifications et, pour un propriétaire, ses annonces et leurs photos sont effacés.</li>
    <li>Les journaux techniques sont conservés pour une durée limitée à des fins de sécurité.</li>
  </ul>

  <h2>7. Vos droits</h2>
  <p>Vous pouvez à tout moment accéder à vos données, les corriger, vous opposer à leur traitement ou demander leur suppression :</p>
  <ul>
    <li>dans l'application : <em>Profil &gt; Paramètres</em> (modifier vos informations, supprimer votre compte) ;</li>
    <li>ou par e-mail à <a href="mailto:{{ config('remci.contact_email') }}">{{ config('remci.contact_email') }}</a>. Voir aussi la page <a href="{{ route('legal.deletion') }}">Supprimer mon compte</a>.</li>
  </ul>
  <p>Vous pouvez également saisir l'Autorité de régulation des télécommunications/TIC de Côte d'Ivoire (ARTCI), chargée de la protection des données personnelles.</p>

  <h2>8. Mineurs</h2>
  <p>REM-CI est réservé aux personnes de 18 ans et plus. Nous ne collectons pas sciemment de données de mineurs ; un dossier locataire n'est accepté que pour une personne majeure.</p>

  <h2>9. Modifications</h2>
  <p>Cette politique peut évoluer. La date de dernière mise à jour figure en haut de la page ; en cas de changement important, les utilisateurs en seront informés dans l'application.</p>

  <h2>10. Contact</h2>
  <p>Pour toute question : <a href="mailto:{{ config('remci.contact_email') }}">{{ config('remci.contact_email') }}</a>.</p>
@endsection
