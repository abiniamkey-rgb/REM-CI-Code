<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ad;
use App\Models\Property;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/** Espace publicitaire : visuels (4 maximum affichés) pour promouvoir des résidences ou des promotions. */
class AdController extends Controller
{
    private const WIDTH = 1200;
    private const HEIGHT = 600;

    public function index()
    {
        return view('admin.ads.index', [
            'ads' => Ad::with('property')->orderByDesc('active')->orderBy('position')->orderBy('id')->get(),
            'liveCount' => Ad::liveCount(),
            'max' => Ad::MAX_LIVE,
            'properties' => Property::where('status', 'active')->orderBy('title')->get(['id', 'title']),
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request, true);
        $wantsActive = $request->boolean('active');

        if ($wantsActive && Ad::liveCount() >= Ad::MAX_LIVE) {
            return back()->withInput()->with('erreur', 'Il y a déjà '.Ad::MAX_LIVE.' publicités affichées. Désactive ou supprime-en une avant d\'en ajouter une nouvelle.');
        }

        $path = $this->storeImage($request->file('image'));
        if (! $path) {
            return back()->withInput()->with('erreur', "Impossible de traiter cette image. Essaie un fichier JPG, PNG ou WebP.");
        }

        Ad::create($data + [
            'image_path' => $path,
            'color_a' => '#0A6C3B',
            'color_b' => '#063D22',
            'active' => $wantsActive,
            'position' => (int) Ad::max('position') + 1,
        ]);

        return back()->with('ok', $wantsActive ? 'Publicité ajoutée et affichée dans l\'application.' : 'Publicité enregistrée (non affichée pour le moment).');
    }

    public function update(Request $request, Ad $ad)
    {
        $data = $this->validated($request, false);

        if ($request->hasFile('image')) {
            $path = $this->storeImage($request->file('image'));
            if (! $path) {
                return back()->with('erreur', "Impossible de traiter cette image. Essaie un fichier JPG, PNG ou WebP.");
            }
            $ad->deleteImage();
            $data['image_path'] = $path;
        }

        $data['position'] = (int) $request->input('position', $ad->position);
        $ad->update($data);

        return back()->with('ok', 'Publicité mise à jour.');
    }

    public function toggle(Ad $ad)
    {
        if (! $ad->active) {
            if ($ad->isExpired()) {
                return back()->with('erreur', 'La date de fin est dépassée : modifie-la avant de réactiver cette publicité.');
            }
            if (Ad::liveCount($ad->id) >= Ad::MAX_LIVE) {
                return back()->with('erreur', 'Il y a déjà '.Ad::MAX_LIVE.' publicités affichées. Désactive-en une autre d\'abord.');
            }
        }

        $ad->update(['active' => ! $ad->active]);

        return back()->with('ok', $ad->active ? 'Publicité affichée dans l\'application.' : 'Publicité masquée.');
    }

    public function destroy(Ad $ad)
    {
        $ad->deleteImage();
        $ad->delete();

        return back()->with('ok', 'Publicité supprimée.');
    }

    private function validated(Request $request, bool $imageRequired): array
    {
        $data = $request->validate([
            'image' => [$imageRequired ? 'required' : 'nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:8192', 'dimensions:min_width=800,min_height=400'],
            'title' => ['nullable', 'string', 'max:60'],
            'subtitle' => ['nullable', 'string', 'max:90'],
            'badge' => ['nullable', 'string', 'max:20'],
            'property_id' => ['nullable', 'integer', 'exists:properties,id'],
            'ends_at' => ['nullable', 'date', 'after_or_equal:today'],
        ], [
            'image.required' => 'Choisis une image.',
            'image.image' => 'Le fichier doit être une image.',
            'image.mimes' => 'Formats acceptés : JPG, PNG ou WebP.',
            'image.max' => 'Image trop lourde (8 Mo maximum).',
            'image.dimensions' => 'Image trop petite : 800 × 400 px minimum (idéal 1200 × 600).',
            'ends_at.after_or_equal' => 'La date de fin ne peut pas être dans le passé.',
        ]);

        unset($data['image']);

        return [
            'title' => $data['title'] ?? null,
            'subtitle' => $data['subtitle'] ?? null,
            'badge' => $data['badge'] ?? null,
            'property_id' => $data['property_id'] ?? null,
            'ends_at' => $data['ends_at'] ?? null,
        ];
    }

    /** Recadre l'image au format 2:1 (1200 × 600) et l'enregistre en JPEG pour un rendu homogène et léger. */
    private function storeImage(UploadedFile $file): ?string
    {
        // Extension GD absente (PHP minimal) : on garde l'image telle quelle ; l'app et l'admin la
        // recadrent à l'affichage. Sur le serveur de production, php-gd est installé (recadrage auto).
        if (! function_exists('imagecreatefromstring') || ! function_exists('imagejpeg')) {
            $ext = strtolower($file->guessExtension() ?: 'jpg');
            $ext = in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true) ? $ext : 'jpg';
            $path = 'ads/'.Str::uuid().'.'.$ext;
            Storage::disk('public')->putFileAs('ads', $file, basename($path));

            return $path;
        }

        $src = @imagecreatefromstring((string) file_get_contents($file->getRealPath()));
        if (! $src) {
            return null;
        }

        $w = imagesx($src);
        $h = imagesy($src);
        $targetRatio = self::WIDTH / self::HEIGHT;

        if ($w / $h > $targetRatio) {
            $cropH = $h;
            $cropW = (int) round($h * $targetRatio);
        } else {
            $cropW = $w;
            $cropH = (int) round($w / $targetRatio);
        }
        $cropX = (int) floor(($w - $cropW) / 2);
        $cropY = (int) floor(($h - $cropH) / 2);

        $dst = imagecreatetruecolor(self::WIDTH, self::HEIGHT);
        imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255)); // fond blanc pour les PNG transparents
        imagecopyresampled($dst, $src, 0, 0, $cropX, $cropY, self::WIDTH, self::HEIGHT, $cropW, $cropH);

        ob_start();
        imagejpeg($dst, null, 86);
        $jpeg = ob_get_clean();

        $path = 'ads/'.Str::uuid().'.jpg';
        Storage::disk('public')->put($path, $jpeg);

        return $path;
    }
}
