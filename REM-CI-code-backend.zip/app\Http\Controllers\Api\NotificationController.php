<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\UserNotification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    /** GET /api/notifications — les 60 dernières + nombre de non lues */
    public function index(Request $request)
    {
        $user = $request->user();

        $items = UserNotification::where('user_id', $user->id)
            ->latest('id')
            ->limit(60)
            ->get()
            ->map(fn (UserNotification $n) => [
                'id' => $n->id,
                'type' => $n->type,
                'title' => $n->title,
                'body' => $n->body,
                'data' => $n->data,
                'read' => $n->read_at !== null,
                'created_at' => $n->created_at?->toIso8601String(),
            ]);

        return response()->json([
            'data' => $items,
            'unread_count' => UserNotification::where('user_id', $user->id)->whereNull('read_at')->count(),
        ]);
    }

    /** POST /api/notifications/read-all */
    public function readAll(Request $request)
    {
        UserNotification::where('user_id', $request->user()->id)
            ->whereNull('read_at')
            ->update(['read_at' => now()]);

        return response()->json(['message' => 'Notifications marquées comme lues']);
    }

    /** POST /api/notifications/{id}/read */
    public function read(Request $request, int $id)
    {
        UserNotification::where('user_id', $request->user()->id)
            ->where('id', $id)
            ->whereNull('read_at')
            ->update(['read_at' => now()]);

        return response()->json(['message' => 'OK']);
    }
}
