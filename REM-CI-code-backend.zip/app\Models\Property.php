<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Property extends Model
{
    use HasFactory;

    /** Nombre maximum de résidences (en attente + publiées) par propriétaire. */
    public const MAX_PER_OWNER = 5;

    protected $fillable = [
        'owner_id', 'city_id', 'title', 'slug', 'description', 'price_per_night',
        'beds', 'bathrooms', 'capacity', 'address', 'latitude', 'longitude',
        'status', 'is_available', 'availability_updated_at', 'tag', 'is_featured', 'rating', 'reviews_count',
        'listing_fee_status', 'listing_fee_amount', 'listing_payment_method',
        'listing_transaction_ref', 'listing_paid_at', 'review_flags',
    ];

    protected $casts = [
        'is_featured' => 'boolean',
        'is_available' => 'boolean',
        'availability_updated_at' => 'datetime',
        'latitude' => 'float',
        'longitude' => 'float',
        'rating' => 'float',
        'listing_paid_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::created(function (Property $property) {
            UserNotification::notify(
                $property->owner, 'property', 'Résidence enregistrée',
                "« {$property->title} » est en attente de validation. Contacte l'administrateur REM-CI au ".UserNotification::adminContacts().' pour la faire valider et publier.',
                ['property_id' => $property->id]
            );
        });

        static::updated(function (Property $property) {
            if (! $property->wasChanged('status')) {
                return;
            }

            if ($property->status === 'active') {
                UserNotification::notify(
                    $property->owner, 'property', 'Résidence publiée 🎉',
                    "« {$property->title} » est maintenant visible par les locataires.",
                    ['property_id' => $property->id]
                );
            } elseif ($property->getOriginal('status') === 'active') {
                UserNotification::notify(
                    $property->owner, 'property', 'Résidence retirée de la publication',
                    "« {$property->title} » n'est plus visible par les locataires. Contacte l'administrateur REM-CI au ".UserNotification::adminContacts().' pour plus d\'informations.',
                    ['property_id' => $property->id]
                );
            }
        });
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function photos()
    {
        return $this->hasMany(PropertyPhoto::class)->orderBy('position');
    }

    public function amenities()
    {
        return $this->belongsToMany(Amenity::class, 'amenity_property');
    }

    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }

    public function favoritedBy()
    {
        return $this->belongsToMany(User::class, 'favorites')->withTimestamps();
    }

    /**
     * Visible aux locataires. L'ancien verrou de paiement des frais de publication
     * est supprimé : l'activation est maintenant 100% manuelle par l'administrateur
     * (phpMyAdmin), après vérification d'identité du propriétaire. Voir les
     * instructions d'activation manuelle fournies séparément.
     */
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function isPublished(): bool
    {
        return $this->status === 'active';
    }

    public function scopeInCity($query, ?string $citySlug)
    {
        return $citySlug ? $query->whereHas('city', fn ($q) => $q->where('slug', $citySlug)) : $query;
    }

    public function scopeSearch($query, ?string $term)
    {
        return $term
            ? $query->where(fn ($q) => $q->where('title', 'like', "%{$term}%")
                ->orWhere('address', 'like', "%{$term}%")
                ->orWhereHas('city', fn ($c) => $c->where('name', 'like', "%{$term}%")))
            : $query;
    }

    /** Résidences qui occupent une place dans la limite du propriétaire (en attente ou publiées). */
    public static function slotsUsedBy(int $ownerId, ?int $exceptId = null): int
    {
        return static::where('owner_id', $ownerId)
            ->whereIn('status', ['pending', 'active'])
            ->when($exceptId, fn ($q) => $q->where('id', '!=', $exceptId))
            ->count();
    }
}
