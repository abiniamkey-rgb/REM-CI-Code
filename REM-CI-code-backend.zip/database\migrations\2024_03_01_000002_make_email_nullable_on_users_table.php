<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // L'e-mail est optionnel à l'inscription (seul le téléphone est obligatoire) —
        // la colonne doit donc accepter NULL, sinon chaque inscription sans e-mail
        // échoue avec "NOT NULL constraint failed: users.email".
        Schema::table('users', function (Blueprint $table) {
            $table->string('email')->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('email')->nullable(false)->change();
        });
    }
};
