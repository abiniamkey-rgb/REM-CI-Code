package com.abitechnologie.remci.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.data.network.AmenityDto
import com.abitechnologie.remci.data.network.PropertyDto
import com.abitechnologie.remci.data.network.UpdatePropertyRequest
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.PropertyRepository
import com.abitechnologie.remci.ui.components.CircleIconButton
import com.abitechnologie.remci.ui.components.clickableNoRipple
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.launch

/**
 * Modification d'une résidence, publiée ou non : faute de frappe dans la description, commodité
 * ajoutée ou retirée (ex. WiFi installé depuis), changement de prix ou de capacité.
 * Les changements sont visibles tout de suite par les locataires.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditPropertyScreen(
    property: PropertyDto,
    onBack: () -> Unit,
    onSaved: (PropertyDto) -> Unit
) {
    val repository = remember { PropertyRepository() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var allAmenities by remember { mutableStateOf<List<AmenityDto>>(emptyList()) }
    var selectedIds by remember { mutableStateOf(property.amenities?.map { it.id }?.toSet() ?: emptySet()) }

    var title by remember { mutableStateOf(com.abitechnologie.remci.ui.components.ListingTitle.nameOf(property.title)) }
    var price by remember { mutableStateOf(property.pricePerNight.toString()) }
    var rooms by remember { mutableStateOf(property.beds.toString()) }
    var capacity by remember { mutableStateOf(property.capacity.toString()) }
    var bathrooms by remember { mutableStateOf(property.bathrooms.toString()) }
    var address by remember { mutableStateOf(property.address ?: "") }
    var description by remember { mutableStateOf(property.description ?: "") }

    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    // Résidence publiée : titre, prix, capacité et adresse sont verrouillés (seuls description et commodités changent)
    val locked = property.status == "active"

    LaunchedEffect(Unit) {
        (repository.getAmenities() as? ApiResult.Success)?.let { allAmenities = it.data }
    }

    fun save() {
        val priceValue = price.toIntOrNull()
        if (!locked && (title.isBlank() || priceValue == null || priceValue < 1000)) {
            error = "Le nom de la résidence est obligatoire et le prix doit être d'au moins 1 000 FCFA."
            return
        }
        error = null
        saving = true
        scope.launch {
            val request = if (locked) {
                // Publiée : on n'envoie que ce qui est modifiable
                UpdatePropertyRequest(
                    description = description.trim(),
                    amenityIds = selectedIds.toList()
                )
            } else {
                UpdatePropertyRequest(
                    title = com.abitechnologie.remci.ui.components.ListingTitle.compose(title),
                    description = description.trim(),
                    pricePerNight = priceValue,
                    beds = (rooms.toIntOrNull() ?: 1).coerceAtLeast(1),
                    bathrooms = (bathrooms.toIntOrNull() ?: 1).coerceAtLeast(1),
                    capacity = (capacity.toIntOrNull() ?: 1).coerceAtLeast(1),
                    address = address.trim(),
                    amenityIds = selectedIds.toList()
                )
            }
            val result = repository.updateProperty(property.id, request)
            saving = false
            when (result) {
                is ApiResult.Success -> {
                    Toast.makeText(context, "Modifications enregistrées ✓", Toast.LENGTH_SHORT).show()
                    onSaved(result.data)
                }
                is ApiResult.Error -> error = result.message
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Bg)) {
        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIconButton(Icons.Default.ArrowBack, onBack)
            Spacer(Modifier.width(10.dp))
            Text("Modifier la résidence", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
        }

        Column(
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            if (property.status == "active") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Blue.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = Blue, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Ta résidence est publiée : tu peux corriger la description et mettre à jour les commodités, " +
                            "visibles tout de suite par les locataires. Le titre, le prix, la capacité et l'adresse sont verrouillés : " +
                            "pour les changer, contacte l'administrateur REM-CI au ${com.abitechnologie.remci.data.AppConfig.ADMIN_PHONES_TEXT}. " +
                            "Chaque modification est relue par l'équipe REM-CI.",
                        fontSize = 11.5.sp, color = Ink, lineHeight = 16.sp
                    )
                }
            }

            EditCard("Informations générales") {
                EditLabel("Nom de la résidence")
                OutlinedTextField(
                    value = title, onValueChange = { title = it }, enabled = !locked,
                    visualTransformation = com.abitechnologie.remci.ui.components.TitlePrefixTransformation(Green),
                    singleLine = true, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                EditLabel("Prix par nuit (FCFA)")
                OutlinedTextField(
                    value = price, onValueChange = { price = it.filter { ch -> ch.isDigit() } }, enabled = !locked,
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
                Text(
                    if (locked) "🔒 Verrouillé après publication." else "Les demandes déjà envoyées gardent le prix d'origine.",
                    fontSize = 10.5.sp, color = Sub, modifier = Modifier.padding(top = 4.dp)
                )
            }

            EditCard(if (locked) "Capacité de la résidence (verrouillée)" else "Capacité de la résidence") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        EditLabel("Nombre de pièces")
                        OutlinedTextField(
                            value = rooms, onValueChange = { rooms = it.filter { ch -> ch.isDigit() } }, enabled = !locked,
                            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        EditLabel("Voyageurs")
                        OutlinedTextField(
                            value = capacity, onValueChange = { capacity = it.filter { ch -> ch.isDigit() } }, enabled = !locked,
                            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        EditLabel("Salle de bain")
                        OutlinedTextField(
                            value = bathrooms, onValueChange = { bathrooms = it.filter { ch -> ch.isDigit() } }, enabled = !locked,
                            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            EditCard("Commodités disponibles") {
                Text(
                    "Coche ce que ta résidence propose aujourd'hui, décoche ce qu'elle n'a plus.",
                    fontSize = 11.5.sp, color = Sub, modifier = Modifier.padding(bottom = 10.dp)
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    allAmenities.forEach { amenity ->
                        val selected = selectedIds.contains(amenity.id)
                        EditAmenityChip(amenity.name, selected) {
                            selectedIds = if (selected) selectedIds - amenity.id else selectedIds + amenity.id
                        }
                    }
                    if (allAmenities.isEmpty()) {
                        Text("Chargement des commodités...", fontSize = 11.sp, color = Sub)
                    }
                }
            }

            EditCard("Adresse & description") {
                EditLabel(if (locked) "Adresse / quartier (verrouillé)" else "Adresse / quartier")
                OutlinedTextField(
                    value = address, onValueChange = { address = it }, enabled = !locked,
                    singleLine = true, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                EditLabel("Description")
                OutlinedTextField(
                    value = description, onValueChange = { description = it },
                    minLines = 4, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
            }

            error?.let { Text(it, color = OrangeDeep, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(4.dp))
        }

        Box(modifier = Modifier.fillMaxWidth().background(Color.White).navigationBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp)) {
            Button(
                onClick = { save() },
                enabled = !saving,
                colors = ButtonDefaults.buttonColors(containerColor = Orange),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 14.dp)
            ) {
                if (saving) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                } else {
                    Text("Enregistrer les modifications", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun EditCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(18.dp))
            .border(1.dp, Divider, RoundedCornerShape(18.dp))
            .padding(18.dp)
    ) {
        Text(title, fontSize = 14.5.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(14.dp))
        content()
    }
}

@Composable
private fun EditAmenityChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) Green else Bg)
            .border(1.dp, if (selected) Green else Divider, RoundedCornerShape(20.dp))
            .clickableNoRipple(onClick)
            .padding(horizontal = 13.dp, vertical = 9.dp)
    ) {
        if (selected) {
            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
        }
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (selected) Color.White else Ink)
    }
}

@Composable
private fun EditLabel(text: String) {
    Text(text, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = Sub)
}
