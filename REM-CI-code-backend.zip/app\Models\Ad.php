<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

/**
 * Espace publicitaire de l'accueil (visible des locataires et des visiteurs sans compte).
 * L'administrateur publie au maximum MAX_LIVE visuels en même temps.
 */
class Ad extends Model
{
    public const MAX_LIVE = 4;

    protected $fillable = [
        'title', 'subtitle', 'image_path', 'badge', 'ends_at',
        'color_a', 'color_b', 'property_id', 'position', 'active',
    ];

    protected $casts = ['active' => 'boolean', 'ends_at' => 'date'];

    public function property()
    {
        return $this->belongsTo(Property::class);
    }

    /** Publicités affichées : actives et dont la date de fin n'est pas dépassée. */
    public function scopeActive($query)
    {
        return $query->where('active', true)
            ->where(fn ($q) => $q->whereNull('ends_at')->orWhere('ends_at', '>=', now()->toDateString()))
            ->orderBy('position')->orderBy('id');
    }

    public function isLive(): bool
    {
        return $this->active && (! $this->ends_at || $this->ends_at->gte(now()->startOfDay()));
    }

    public function isExpired(): bool
    {
        return $this->ends_at && $this->ends_at->lt(now()->startOfDay());
    }

    public static function liveCount(?int $exceptId = null): int
    {
        return static::active()->when($exceptId, fn ($q) => $q->where('id', '!=', $exceptId))->count();
    }

    public function deleteImage(): void
    {
        if ($this->image_path) {
            Storage::disk('public')->delete($this->image_path);
        }
    }
}
