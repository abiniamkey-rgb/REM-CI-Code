package com.abitechnologie.remci.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RemCiColors = lightColorScheme(
    primary = Orange,
    onPrimary = Color(0xFFFFFFFF),
    secondary = Green,
    onSecondary = Color(0xFFFFFFFF),
    tertiary = Gold,
    background = Bg,
    surface = CardBg,
    onBackground = Ink,
    onSurface = Ink,
    error = OrangeDeep,
)

@Composable
fun RemCiTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RemCiColors,
        typography = RemCiTypography,
        content = content
    )
}
