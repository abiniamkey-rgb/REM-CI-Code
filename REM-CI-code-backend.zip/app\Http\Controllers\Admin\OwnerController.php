<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

/** Dossiers d'identité des propriétaires : consulter, certifier, refuser. */
class OwnerController extends Controller
{
    public const STATUSES = [
        'pending' => 'En attente',
        'verified' => 'Certifiés',
        'rejected' => 'Refusés',
        'not_submitted' => 'Non soumis',
    ];

    public function index(Request $request)
    {
        $status = $request->query('statut', 'pending');
        $search = trim((string) $request->query('q', ''));

        $owners = User::where('role', 'proprietaire')
            ->withCount('properties')
            ->when(array_key_exists($status, self::STATUSES), fn ($q) => $q->where('owner_verification_status', $status))
            ->when($search !== '', fn ($q) => $q->where(fn ($w) => $w
                ->where('name', 'like', "%{$search}%")
                ->orWhere('phone', 'like', "%{$search}%")
                ->orWhere('email', 'like', "%{$search}%")))
            ->latest('updated_at')
            ->paginate(15)
            ->withQueryString();

        $counts = User::where('role', 'proprietaire')
            ->selectRaw('owner_verification_status as s, count(*) as c')
            ->groupBy('owner_verification_status')
            ->pluck('c', 's');

        return view('admin.owners.index', [
            'owners' => $owners,
            'status' => $status,
            'search' => $search,
            'counts' => $counts,
            'statuses' => self::STATUSES,
        ]);
    }

    public function show(User $user)
    {
        abort_unless($user->role === 'proprietaire', 404);

        $user->load(['properties.city']);

        return view('admin.owners.show', [
            'owner' => $user,
            'hasRecto' => (bool) $this->locateDocument($user->id_document_url),
            'hasVerso' => (bool) $this->locateDocument($user->id_document_verso_url),
        ]);
    }

    /**
     * Sert la photo de la pièce d'identité. Les fichiers ne sont jamais accessibles par une URL
     * publique : seul un admin connecté peut les voir, par cette route.
     */
    public function document(User $user, string $side)
    {
        abort_unless($user->role === 'proprietaire', 404);

        $path = $side === 'verso' ? $user->id_document_verso_url : $user->id_document_url;
        $disk = $this->locateDocument($path);
        abort_unless($disk, 404);

        return Storage::disk($disk)->response($path, null, [
            'Cache-Control' => 'private, no-store',
        ]);
    }

    public function certify(User $user)
    {
        abort_unless($user->role === 'proprietaire', 404);

        if ($user->owner_verification_status === 'not_submitted') {
            return back()->with('erreur', "Ce propriétaire n'a pas encore envoyé son dossier.");
        }

        $user->update([
            'owner_verification_status' => 'verified',
            'owner_verified_at' => now(),
            'is_verified' => true,
        ]);

        return back()->with('ok', "{$user->name} est certifié. Il a reçu une notification.");
    }

    public function reject(Request $request, User $user)
    {
        abort_unless($user->role === 'proprietaire', 404);

        $data = $request->validate(['motif' => ['nullable', 'string', 'max:300']]);

        if ($user->owner_verification_status === 'not_submitted') {
            return back()->with('erreur', "Ce propriétaire n'a pas encore envoyé son dossier.");
        }

        // Le motif est ajouté au texte de la notification envoyée au propriétaire (voir User::booted).
        $user->rejectionNote = trim((string) ($data['motif'] ?? '')) ?: null;
        $user->update([
            'owner_verification_status' => 'rejected',
            'owner_verified_at' => null,
            'is_verified' => false,
        ]);

        return back()->with('ok', "Le dossier de {$user->name} est refusé. Il a reçu une notification.");
    }

    /** Disque où se trouve le fichier : privé (nouveaux dossiers) ou public (anciens dossiers). */
    private function locateDocument(?string $path): ?string
    {
        if (! $path) {
            return null;
        }

        foreach (['local', 'public'] as $disk) {
            if (Storage::disk($disk)->exists($path)) {
                return $disk;
            }
        }

        return null;
    }
}
