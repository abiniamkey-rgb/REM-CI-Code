<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ads', function (Blueprint $table) {
            $table->string('image_path')->nullable()->after('subtitle');
            $table->string('badge', 20)->nullable()->after('image_path');   // ex. « -20 % », « NOUVEAU »
            $table->date('ends_at')->nullable()->after('badge');            // dernier jour d'affichage
        });
    }

    public function down(): void
    {
        Schema::table('ads', function (Blueprint $table) {
            $table->dropColumn(['image_path', 'badge', 'ends_at']);
        });
    }
};
