package com.abitechnologie.remci.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.ui.theme.*

@Composable
fun SuccessScreen(
    onHome: () -> Unit,
    title: String = "Réservation confirmée !",
    message: String = "Ta demande est bien enregistrée.",
    /** Référence réelle (ex. numéro de la demande). Rien n'est affiché si elle est absente. */
    reference: String? = null,
    homeLabel: String = "Retour à l'accueil"
) {
    Column(
        modifier = Modifier.fillMaxSize().background(Bg).padding(30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(78.dp).clip(CircleShape).background(Green.copy(alpha = 0.13f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Green, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Ink, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(message, fontSize = 12.5.sp, color = Sub, textAlign = TextAlign.Center, lineHeight = 19.sp)
        if (reference != null) {
            Spacer(Modifier.height(18.dp))
            Row(
                modifier = Modifier
                    .background(CardBg, RoundedCornerShape(14.dp))
                    .border(1.dp, Divider, RoundedCornerShape(14.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = Orange, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(8.dp))
                Text("Demande n° ", fontSize = 12.sp, color = Sub)
                Text(reference, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onHome,
            colors = ButtonDefaults.buttonColors(containerColor = Orange),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(homeLabel, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, modifier = Modifier.padding(vertical = 4.dp, horizontal = 10.dp))
        }
    }
}
