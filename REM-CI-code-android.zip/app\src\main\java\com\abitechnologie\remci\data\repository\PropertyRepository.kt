package com.abitechnologie.remci.data.repository

import com.abitechnologie.remci.data.network.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

class PropertyRepository {
    private val api = RetrofitClient.api

    suspend fun getCities(): ApiResult<List<CityDto>> = safeCall { api.getCities().let { it.body()?.data ?: emptyList() } }

    suspend fun getAds(): ApiResult<List<AdDto>> = safeCall { api.getAds().let { it.body()?.data ?: emptyList() } }

    /** Liste des commodités proposables (WiFi, climatisation, piscine...) pour le formulaire résidence. */
    suspend fun getAmenities(): ApiResult<List<AmenityDto>> = safeCall { api.getAmenities().body() ?: emptyList() }

    suspend fun getProperties(city: String? = null, search: String? = null): ApiResult<List<PropertyDto>> =
        safeCall { api.getProperties(city = city, search = search).let { it.body()?.data ?: emptyList() } }

    /** Recherche avancée (onglet Recherche) : tous les filtres sont appliqués côté serveur. */
    suspend fun searchProperties(
        search: String? = null,
        citySlug: String? = null,
        minPrice: Int? = null,
        maxPrice: Int? = null,
        minRooms: Int? = null,
        guests: Int? = null,
        amenityIds: List<Int> = emptyList(),
        sort: String? = null
    ): ApiResult<List<PropertyDto>> = safeCall {
        api.getProperties(
            city = citySlug,
            search = search?.takeIf { it.isNotBlank() },
            minPrice = minPrice,
            maxPrice = maxPrice,
            minRooms = minRooms,
            guests = guests,
            amenityIds = amenityIds.takeIf { it.isNotEmpty() }?.joinToString(","),
            sort = sort,
            perPage = 60
        ).let { response ->
            if (!response.isSuccessful) throw java.io.IOException("Erreur serveur (${response.code()})")
            response.body()?.data ?: emptyList()
        }
    }

    suspend fun getProperty(id: Int): ApiResult<PropertyDto> = try {
        val response = api.getProperty(id)
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error("Résidence introuvable")
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    suspend fun getFavorites(): ApiResult<List<PropertyDto>> = safeCall { api.getFavorites().let { it.body()?.data ?: emptyList() } }

    /** Propriétaire — crée une résidence (reste "en attente" tant qu'elle n'est pas activée manuellement) */
    suspend fun createProperty(body: CreatePropertyRequest): ApiResult<PropertyDto> = try {
        val response = api.createProperty(body)
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible de créer la résidence"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /** Propriétaire — toutes ses résidences, y compris celles en attente d'activation manuelle */
    suspend fun getMyProperties(): ApiResult<List<PropertyDto>> =
        safeCall { api.getMyProperties().let { it.body()?.data ?: emptyList() } }

    /** Propriétaire — modifie une résidence (y compris déjà publiée) : texte, prix, commodités… */
    suspend fun updateProperty(propertyId: Int, body: UpdatePropertyRequest): ApiResult<PropertyDto> = try {
        val response = api.updateProperty(propertyId, body)
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible d'enregistrer les modifications"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /** Propriétaire — marque sa résidence disponible (icône bleue) ou occupée (icône rouge). */
    suspend fun setAvailability(propertyId: Int, available: Boolean): ApiResult<PropertyDto> = try {
        val response = api.setAvailability(propertyId, mapOf("is_available" to available))
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible de modifier la disponibilité"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /** Envoie les photos prises avec l'appareil photo (jamais la galerie) pour une résidence. */
    suspend fun uploadPhotos(propertyId: Int, files: List<File>): ApiResult<PropertyDto> = try {
        val parts = files.map { original ->
            val file = com.abitechnologie.remci.data.ImageCompressor.compressForUpload(original)
            val body = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("photos[]", file.name, body)
        }
        val response = api.uploadPropertyPhotos(propertyId, parts)
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible d'envoyer les photos"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    suspend fun toggleFavorite(propertyId: Int): ApiResult<Boolean> = try {
        val response = api.toggleFavorite(propertyId)
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.favorite)
        else ApiResult.Error("Action impossible, connecte-toi d'abord")
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    private suspend fun <T> safeCall(block: suspend () -> T): ApiResult<T> = try {
        ApiResult.Success(block())
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }
}
