<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CityResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'slug' => $this->slug,
            'tone_color' => $this->tone_color,
            'photo_url' => $this->photo_url,
            'properties_count' => $this->whenCounted('properties'),
        ];
    }
}
