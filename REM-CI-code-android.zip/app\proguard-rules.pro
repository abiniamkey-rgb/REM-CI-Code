# Règles R8/ProGuard — utiles le jour où isMinifyEnabled passera à true.

# Modèles échangés avec l'API (Gson lit les noms des champs par réflexion)
-keep class com.abitechnologie.remci.data.network.** { *; }
-keep class com.abitechnologie.remci.data.** { *; }
-keepattributes Signature, *Annotation*, InnerClasses, EnclosingMethod

# Retrofit / OkHttp / Gson
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
-keep,allowobfuscation,allowshrinking interface retrofit2.Call
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken
