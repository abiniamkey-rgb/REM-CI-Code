package com.abitechnologie.remci.data.network

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {

    /**
     * Adresse de l'API : définie par type de build dans app/build.gradle.kts
     * (debug = tunnel ngrok de développement, release = serveur de production).
     */
    var BASE_URL: String = com.abitechnologie.remci.BuildConfig.API_BASE_URL

    private val authInterceptor = Interceptor { chain ->
        val original = chain.request()
        val token = TokenManager.getToken()
        val request = if (!token.isNullOrBlank()) {
            original.newBuilder().addHeader("Authorization", "Bearer $token")
                .addHeader("Accept", "application/json")
                .build()
        } else {
            original.newBuilder().addHeader("Accept", "application/json").build()
        }
        chain.proceed(request)
    }

    // Jeton refusé (401) alors qu'on en avait envoyé un : session expirée -> l'interface
    // renvoie l'utilisateur vers la connexion avec un message clair.
    private val sessionInterceptor = Interceptor { chain ->
        val request = chain.request()
        val response = chain.proceed(request)
        if (response.code == 401 && request.header("Authorization") != null &&
            !request.url.encodedPath.endsWith("/logout")
        ) {
            SessionEvents.expired.tryEmit(Unit)
        }
        response
    }

    // BASIC (et non BODY) : en BODY, chaque photo envoyée était écrite en entier dans Logcat,
    // ce qui ralentissait fortement l'envoi des dossiers et des photos de résidence.
    private val logging = HttpLoggingInterceptor().apply {
        // Aucun journal réseau dans la version publiée (seulement en développement)
        level = if (com.abitechnologie.remci.BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .addInterceptor(sessionInterceptor)
        .addInterceptor(logging)
        // L'envoi de photos sur réseau mobile peut être long : timeouts généreux
        // (le défaut d'OkHttp est de 10 s en écriture, trop court pour des photos).
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
