package com.abitechnologie.remci.ui.components

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException

sealed class GoogleSignInResult {
    data class Token(val idToken: String) : GoogleSignInResult()
    object Cancelled : GoogleSignInResult()
    data class Failure(val message: String) : GoogleSignInResult()
}

/**
 * Ouvre la feuille « Se connecter avec Google » (choix du compte du téléphone) et renvoie
 * le jeton d'identité, que le serveur REM-CI vérifie ensuite auprès de Google.
 * [context] doit être une Activity (LocalContext dans Compose).
 */
suspend fun requestGoogleIdToken(context: Context, webClientId: String): GoogleSignInResult {
    return try {
        val option = GetSignInWithGoogleOption.Builder(webClientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = CredentialManager.create(context).getCredential(context, request)
        val credential = result.credential
        if (credential is CustomCredential &&
            credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            GoogleSignInResult.Token(GoogleIdTokenCredential.createFrom(credential.data).idToken)
        } else {
            GoogleSignInResult.Failure("Type de connexion Google non reconnu.")
        }
    } catch (e: GetCredentialCancellationException) {
        GoogleSignInResult.Cancelled
    } catch (e: NoCredentialException) {
        GoogleSignInResult.Failure("Aucun compte Google disponible sur ce téléphone. Ajoute-en un dans les paramètres Android, puis réessaie.")
    } catch (e: GetCredentialException) {
        GoogleSignInResult.Failure("Connexion Google impossible (${e.type.substringAfterLast('.')}). Vérifie la configuration Google du projet.")
    } catch (e: GoogleIdTokenParsingException) {
        GoogleSignInResult.Failure("Réponse Google invalide. Réessaie.")
    } catch (e: Exception) {
        GoogleSignInResult.Failure("Connexion Google impossible : ${e.message ?: "erreur inconnue"}")
    }
}
