@extends('admin.layout')
@section('title', 'Utilisateurs')
@section('content')
  <h1>Utilisateurs</h1>
  <div class="sub">Tous les comptes de l'application.</div>

  <div class="tabs">
    @foreach(['all' => 'Tous', 'locataire' => 'Locataires', 'proprietaire' => 'Propriétaires', 'admin' => 'Admins'] as $key => $label)
      <a class="{{ $role === $key && ! $identity ? 'on' : '' }}" href="{{ route('admin.users.index', ['role' => $key, 'q' => $search ?: null]) }}">{{ $label }}@if($key !== 'all')<small>{{ $counts[$key] ?? 0 }}</small>@endif</a>
    @endforeach
    <a class="{{ $identity === 'submitted' ? 'on' : '' }}" href="{{ route('admin.users.index', ['identite' => 'submitted']) }}">Identités à examiner @if($toReview)<small>{{ $toReview }}</small>@endif</a>
  </div>
  <form class="search" method="GET" action="{{ route('admin.users.index') }}">
    <input type="hidden" name="role" value="{{ $role }}">
    <input type="text" name="q" value="{{ $search }}" placeholder="Rechercher un nom, un téléphone, un e-mail…">
    <button class="btn" type="submit">Rechercher</button>
  </form>

  <div class="card tablewrap" style="margin-top:12px">
    <table>
      <thead><tr><th>Nom</th><th>Téléphone</th><th>Rôle</th><th>Identité</th><th>Résidences</th><th>Réservations</th><th>Inscrit</th></tr></thead>
      <tbody>
      @forelse($users as $u)
        <tr>
          <td><strong>{{ $u->name }}</strong><div class="sub">{{ $u->email }}</div></td>
          <td>{{ $u->phone }}</td>
          <td>
            @if($u->role === 'proprietaire')<a href="{{ route('admin.owners.show', $u) }}">Propriétaire</a>
            @elseif($u->role === 'admin')<strong>Admin</strong>
            @else <a href="{{ route('admin.tenants.show', $u) }}">Locataire</a> @endif
          </td>
          <td>
            @if($u->role === 'locataire')
              <a href="{{ route('admin.tenants.show', $u) }}">@include('admin._badge', ['status' => $u->identity_status])</a>
            @else — @endif
          </td>
          <td>{{ $u->role === 'proprietaire' ? $u->properties_count : '—' }}</td>
          <td>{{ $u->bookings_count }}</td>
          <td class="sub">{{ $u->created_at?->format('d/m/Y') }}</td>
        </tr>
      @empty
        <tr><td colspan="7" class="empty">Aucun utilisateur.</td></tr>
      @endforelse
      </tbody>
    </table>
  </div>
  @include('admin._pager', ['items' => $users])
@endsection
