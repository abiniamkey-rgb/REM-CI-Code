@extends('admin.layout')
@section('title', $owner->name)
@section('content')
  <a href="{{ route('admin.owners.index') }}" class="sub">← Retour aux propriétaires</a>
  <h1 style="margin-top:8px">{{ $owner->name }} @include('admin._badge', ['status' => $owner->owner_verification_status])</h1>

  <div class="grid two" style="margin-top:14px">
    <div class="card">
      <h2>Informations</h2>
      <dl>
        <dt>Téléphone</dt><dd>{{ $owner->phone ?: '—' }}</dd>
        <dt>E-mail</dt><dd>{{ $owner->email ?: '—' }}</dd>
        <dt>Adresse</dt><dd>{{ $owner->address ?: '—' }}</dd>
        <dt>Nom lu sur la pièce</dt><dd>{{ $owner->detected_name ?: '—' }}</dd>
        <dt>N° de pièce lu</dt><dd>{{ $owner->detected_id_number ?: '—' }}</dd>
        <dt>Inscrit</dt><dd>{{ $owner->created_at?->format('d/m/Y H:i') }}</dd>
        <dt>Certifié le</dt><dd>{{ $owner->owner_verified_at?->format('d/m/Y H:i') ?: '—' }}</dd>
      </dl>
      <div class="sub" style="margin-top:10px">« Nom lu » et « N° lu » viennent de la lecture automatique sur le téléphone : ce n'est qu'une aide. Compare toujours avec les photos.</div>
    </div>

    <div class="card">
      <h2>Décision</h2>
      @if($owner->owner_verification_status === 'not_submitted')
        <div class="sub">Ce propriétaire n'a pas encore envoyé son dossier.</div>
      @else
        <div class="actions">
          @if($owner->owner_verification_status !== 'verified')
            <form method="POST" action="{{ route('admin.owners.certify', $owner) }}" onsubmit="return confirm('Certifier {{ addslashes($owner->name) }} ?')">
              @csrf <button class="btn" type="submit">✓ Certifier le propriétaire</button>
            </form>
          @endif
        </div>
        @if($owner->owner_verification_status !== 'rejected')
          <form method="POST" action="{{ route('admin.owners.reject', $owner) }}" style="margin-top:16px" onsubmit="return confirm('Refuser ce dossier ?')">
            @csrf
            <label for="motif" class="sub">Motif du refus (visible par le propriétaire, facultatif)</label>
            <textarea id="motif" name="motif" rows="2" maxlength="300" placeholder="Ex. Photo floue, merci de refaire la photo du verso."></textarea>
            <button class="btn red" type="submit" style="margin-top:10px">Refuser le dossier</button>
          </form>
        @endif
        <div class="sub" style="margin-top:12px">Le propriétaire reçoit automatiquement une notification dans l'application.</div>
      @endif
    </div>
  </div>

  <div class="card" style="margin-top:14px">
    <h2>Pièce d'identité</h2>
    @if($hasRecto || $hasVerso)
      <div class="docs">
        @if($hasRecto)<a href="{{ route('admin.owners.document', [$owner, 'recto']) }}" target="_blank"><div class="sub">Recto</div><img src="{{ route('admin.owners.document', [$owner, 'recto']) }}" alt="Recto de la pièce d'identité"></a>@endif
        @if($hasVerso)<a href="{{ route('admin.owners.document', [$owner, 'verso']) }}" target="_blank"><div class="sub">Verso</div><img src="{{ route('admin.owners.document', [$owner, 'verso']) }}" alt="Verso de la pièce d'identité"></a>@endif
      </div>
    @else
      <div class="sub">Aucune photo disponible.</div>
    @endif
  </div>

  <div class="card tablewrap" style="margin-top:14px">
    <h2>Résidences de ce propriétaire ({{ $owner->properties->count() }})</h2>
    <table>
      <thead><tr><th>Résidence</th><th>Ville</th><th>Prix / nuit</th><th>Statut</th><th></th></tr></thead>
      <tbody>
      @forelse($owner->properties as $p)
        <tr>
          <td><strong>{{ $p->title }}</strong></td><td>{{ $p->city?->name }}</td>
          <td>{{ number_format($p->price_per_night, 0, ',', ' ') }} FCFA</td>
          <td>@include('admin._badge', ['status' => $p->status])</td>
          <td><a class="btn ghost" href="{{ route('admin.properties.show', $p) }}">Ouvrir</a></td>
        </tr>
      @empty
        <tr><td colspan="5" class="empty">Aucune résidence.</td></tr>
      @endforelse
      </tbody>
    </table>
  </div>
@endsection
