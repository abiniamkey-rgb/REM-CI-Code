@if($items->hasPages())
  <div class="pager">
    <span>Page {{ $items->currentPage() }} sur {{ $items->lastPage() }} · {{ $items->total() }} résultat(s)</span>
    <span>
      @if($items->previousPageUrl())<a class="btn ghost" href="{{ $items->previousPageUrl() }}">← Précédent</a>@endif
      @if($items->nextPageUrl())<a class="btn ghost" href="{{ $items->nextPageUrl() }}">Suivant →</a>@endif
    </span>
  </div>
@endif
