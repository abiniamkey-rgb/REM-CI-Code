<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Models\UserNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    /** Première notification : message de bienvenue adapté au rôle. */
    private static function welcome(User $user): void
    {
        if ($user->role === 'proprietaire') {
            UserNotification::notify(
                $user, 'welcome', 'Bienvenue sur REM-CI 👋',
                "Soumets ton dossier d'identité (pièce recto/verso), puis ajoute ta résidence. Pour la validation, contacte l'administrateur REM-CI au ".UserNotification::adminContacts().'.'
            );
        } else {
            UserNotification::notify(
                $user, 'welcome', 'Bienvenue sur REM-CI 👋',
                'Parcours les résidences meublées, enregistre tes favoris et contacte directement les propriétaires.'
            );
        }
    }

    /** Retire espaces, points, tirets et parenthèses d'un numéro de téléphone. */
    private static function normalizePhone(string $phone): string
    {
        return preg_replace('/[\s.\-()]+/', '', trim($phone)) ?? $phone;
    }

    /** POST /api/register */
    public function register(Request $request)
    {
        // L'app envoie parfois une chaîne vide "" quand l'e-mail n'est pas rempli.
        // "nullable" n'accepte que null, pas "" : sans ça, la validation de format
        // e-mail échouait systématiquement en 422 même avec le champ laissé vide.
        if ($request->email === '') {
            $request->merge(['email' => null]);
        }
        if ($request->filled('email')) {
            $request->merge(['email' => strtolower(trim((string) $request->email))]);
        }

        // "07 07 98 28 02" et "0707982802" doivent désigner le même compte.
        $request->merge(['phone' => self::normalizePhone((string) $request->phone)]);

        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'unique:users,phone'],
            // Obligatoire : c'est le moyen de récupérer le mot de passe (code envoyé par e-mail).
            'email' => ['required', 'email', 'unique:users,email'],
            'password' => ['required', 'string', 'min:6'],
            'role' => ['required', 'in:locataire,proprietaire'],
        ], [
            'name.required' => 'Indique ton nom complet.',
            'phone.required' => 'Indique ton numéro de téléphone.',
            'phone.unique' => 'Ce numéro est déjà utilisé. Connecte-toi, ou utilise « Mot de passe oublié ».',
            'email.required' => "L'adresse e-mail est obligatoire : elle sert à récupérer ton mot de passe.",
            'email.email' => 'Cette adresse e-mail semble invalide.',
            'email.unique' => 'Cette adresse e-mail est déjà utilisée. Connecte-toi, ou utilise « Mot de passe oublié ».',
            'password.required' => 'Choisis un mot de passe.',
            'password.min' => 'Le mot de passe doit contenir au moins 6 caractères.',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'Erreur de validation', 'errors' => $validator->errors()], 422);
        }

        $user = User::create([
            'name' => $request->name,
            'phone' => $request->phone,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => $request->role,
        ]);

        self::welcome($user);

        $token = $user->createToken('remci-mobile')->plainTextToken;

        return response()->json([
            'message' => 'Compte créé avec succès',
            'user' => new UserResource($user),
            'token' => $token,
        ], 201);
    }

    /** POST /api/login  (phone + password) */
    public function login(Request $request)
    {
        $request->validate([
            'phone' => ['required', 'string'],
            'password' => ['required', 'string'],
            // Mode choisi avec le bouton Locataire / Propriétaire de l'écran de connexion.
            'role' => ['nullable', 'in:locataire,proprietaire'],
        ]);

        // Anti force brute : 5 essais ratés par minute pour un même identifiant (numéro ou e-mail).
        // La clé est l'identifiant et non l'adresse IP : derrière un tunnel ou un proxy, tous les
        // utilisateurs partageraient la même IP et se bloqueraient entre eux.
        $throttleKey = 'login:'.Str::lower(self::normalizePhone(trim((string) $request->phone)));
        if (RateLimiter::tooManyAttempts($throttleKey, 5)) {
            $seconds = RateLimiter::availableIn($throttleKey);

            return response()->json([
                'message' => "Trop de tentatives. Réessaie dans {$seconds} seconde(s) ou utilise « Mot de passe oublié ».",
            ], 429);
        }

        // Cherche d'abord le numéro normalisé, puis tel que saisi (anciens comptes enregistrés avec espaces).
        // Le champ peut aussi contenir l'adresse e-mail (comptes créés avec Google, sans numéro).
        $login = trim((string) $request->phone);
        if (str_contains($login, '@')) {
            $user = User::where('email', strtolower($login))->first();
        } else {
            $normalized = self::normalizePhone($login);
            $user = User::whereIn('phone', array_unique([$normalized, $login]))->first();
        }

        if (! $user || ! Hash::check($request->password, $user->password)) {
            RateLimiter::hit($throttleKey, 60);

            return response()->json(['message' => 'Identifiants incorrects'], 401);
        }

        RateLimiter::clear($throttleKey);

        // Un compte a un seul rôle (locataire OU propriétaire), chacun ayant son propre
        // tableau de bord. Le bouton choisi à la connexion doit correspondre au rôle du
        // compte, sinon on refuse avec un message clair au lieu de mélanger les deux.
        if ($request->filled('role') && $user->role !== $request->role) {
            return $this->roleMismatch($user, (string) $request->role);
        }

        $token = $user->createToken('remci-mobile')->plainTextToken;

        return response()->json([
            'message' => 'Connexion réussie',
            'user' => new UserResource($user->fresh()),
            'token' => $token,
        ]);
    }

    /** Un compte n'a qu'un seul rôle : message clair si le mauvais bouton a été choisi. */
    private function roleMismatch(User $user, string $chosenRole)
    {
        $actual = $user->role === 'proprietaire' ? 'Propriétaire' : 'Locataire';
        $chosen = $chosenRole === 'proprietaire' ? 'Propriétaire' : 'Locataire';

        return response()->json([
            'message' => "Ce compte est un compte {$actual}. Choisis « {$actual} » pour te connecter, ou crée un compte {$chosen} avec une autre adresse e-mail.",
        ], 403);
    }

    /**
     * POST /api/auth/google  { id_token, role }
     * L'app envoie le jeton d'identité Google ; on le fait vérifier par Google, puis on
     * connecte le compte correspondant (ou on en crée un avec le rôle choisi).
     */
    public function googleLogin(Request $request)
    {
        $data = $request->validate([
            'id_token' => ['required', 'string'],
            'role' => ['required', 'in:locataire,proprietaire'],
        ]);

        $clientId = (string) config('services.google.client_id');
        if ($clientId === '') {
            return response()->json(['message' => "La connexion Google n'est pas encore configurée sur le serveur."], 503);
        }

        try {
            $response = Http::timeout(10)->get('https://oauth2.googleapis.com/tokeninfo', ['id_token' => $data['id_token']]);
        } catch (\Throwable $e) {
            return response()->json(['message' => 'Impossible de contacter Google pour le moment. Réessaie dans un instant.'], 503);
        }

        $google = $response->json();
        $valid = $response->ok()
            && is_array($google)
            && hash_equals($clientId, (string) ($google['aud'] ?? ''))
            && in_array($google['iss'] ?? '', ['accounts.google.com', 'https://accounts.google.com'], true)
            && filter_var($google['email_verified'] ?? false, FILTER_VALIDATE_BOOLEAN)
            && ! empty($google['email'])
            && ! empty($google['sub']);

        if (! $valid) {
            return response()->json(['message' => 'Connexion Google refusée. Réessaie ou utilise ton numéro et ton mot de passe.'], 401);
        }

        $email = strtolower((string) $google['email']);
        $user = User::where('google_id', $google['sub'])->first();

        if (! $user && ($byEmail = User::where('email', $email)->first())) {
            // Sécurité : on ne rattache Google à un compte existant que si l'adresse e-mail de ce compte
            // a été prouvée (code reçu par e-mail). Sinon, quelqu'un pourrait créer un compte avec
            // l'adresse d'une autre personne et récupérer sa connexion Google.
            if (! $byEmail->email_verified_at) {
                return response()->json([
                    'message' => 'Un compte existe déjà avec cette adresse e-mail. Connecte-toi avec ton numéro et ton mot de passe '
                        .'(ou utilise « Mot de passe oublié »), puis réessaie avec Google.',
                    'code' => 'email_not_verified',
                ], 409);
            }
            $user = $byEmail;
        }

        if ($user) {
            if ($user->role !== $data['role']) {
                return $this->roleMismatch($user, $data['role']);
            }
            if (! $user->google_id) {
                $user->forceFill(['google_id' => $google['sub']])->save();
            }
            $status = 200;
            $message = 'Connexion réussie';
        } else {
            $user = User::create([
                'name' => $google['name'] ?? Str::before($email, '@'),
                'email' => $email,
                'google_id' => $google['sub'],
                'email_verified_at' => now(),
                'avatar' => $google['picture'] ?? null,
                // Mot de passe aléatoire : ce compte se connecte avec Google
                // (ou définit un mot de passe via « Mot de passe oublié »).
                'password' => Str::random(40),
                'role' => $data['role'],
            ]);
            self::welcome($user);
            $status = 201;
            $message = 'Compte créé avec succès';
        }

        return response()->json([
            'message' => $message,
            'user' => new UserResource($user->fresh()),
            'token' => $user->createToken('remci-mobile')->plainTextToken,
        ], $status);
    }

    /** POST /api/logout */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json(['message' => 'Déconnecté']);
    }

    /** GET /api/me */
    public function me(Request $request)
    {
        return new UserResource($request->user());
    }
}
