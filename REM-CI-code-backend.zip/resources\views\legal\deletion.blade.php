@extends('legal.layout')
@section('title', 'Supprimer mon compte')
@section('description', 'Comment supprimer votre compte REM-CI et vos données.')
@section('content')
  <h1>Supprimer mon compte REM-CI</h1>
  <p class="upd">Application « REM-CI » — {{ config('remci.company') }}</p>

  <h2>Depuis l'application (recommandé)</h2>
  <ol>
    <li>Ouvrez REM-CI et connectez-vous.</li>
    <li>Allez dans l'onglet <strong>Profil</strong> puis <strong>Paramètres</strong>.</li>
    <li>En bas de la page, touchez <strong>Supprimer mon compte</strong> et suivez la confirmation.</li>
  </ol>
  <p>La suppression est immédiate et définitive.</p>

  <h2>Sans accès à l'application</h2>
  <p>Envoyez un e-mail à <a href="mailto:{{ config('remci.contact_email') }}?subject=Suppression%20de%20mon%20compte%20REM-CI">{{ config('remci.contact_email') }}</a> avec pour objet « Suppression de mon compte REM-CI », en indiquant votre <strong>nom</strong> et le <strong>numéro de téléphone</strong> du compte. Par sécurité, nous pourrons vous demander de confirmer votre identité. Votre demande est traitée sous 30 jours maximum.</p>

  <h2>Ce qui est supprimé</h2>
  <ul>
    <li>Votre profil (nom, téléphone, e-mail, photo de profil) et vos identifiants de connexion.</li>
    <li>Votre dossier d'identité et les photos de votre pièce d'identité.</li>
    <li>Vos favoris, vos notifications et l'historique de vos réservations.</li>
    <li>Pour un propriétaire : ses annonces, leurs photos et les demandes de réservation associées.</li>
  </ul>

  <h2>Ce qui peut être conservé</h2>
  <p>Des journaux techniques de sécurité (par exemple adresse IP et date des connexions) peuvent être conservés pour une durée limitée afin de prévenir la fraude, ainsi que les données que la loi nous oblige à garder.</p>

  <h2>Conditions</h2>
  <p>Le compte ne peut pas être supprimé tant qu'une réservation est <strong>en attente ou confirmée avec des dates à venir</strong> : annulez-la ou attendez la fin du séjour. Un compte administrateur ne se supprime pas depuis l'application.</p>
@endsection
