<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('properties', function (Blueprint $table) {
            // Frais de publication que le propriétaire doit payer avant que sa résidence soit visible
            $table->enum('listing_fee_status', ['unpaid', 'paid'])->default('unpaid')->after('status');
            $table->unsignedInteger('listing_fee_amount')->default(10000)->after('listing_fee_status');
            $table->string('listing_payment_method')->nullable()->after('listing_fee_amount');
            $table->string('listing_transaction_ref')->nullable()->after('listing_payment_method');
            $table->timestamp('listing_paid_at')->nullable()->after('listing_transaction_ref');
        });
    }

    public function down(): void
    {
        Schema::table('properties', function (Blueprint $table) {
            $table->dropColumn([
                'listing_fee_status', 'listing_fee_amount', 'listing_payment_method',
                'listing_transaction_ref', 'listing_paid_at',
            ]);
        });
    }
};
