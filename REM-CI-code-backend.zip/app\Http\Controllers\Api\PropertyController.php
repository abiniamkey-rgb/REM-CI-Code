<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PropertyResource;
use App\Models\Property;
use App\Models\PropertyEdit;
use App\Models\User;
use App\Models\UserNotification;
use App\Support\ListingRules;
use App\Support\TextModerator;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PropertyController extends Controller
{
    /** GET /api/properties?city=abidjan&search=cocody&min_price=&max_price=&featured=1&min_rooms=&guests=&amenity_ids=1,2&sort=price_asc */
    public function index(Request $request)
    {
        $query = Property::active()
            ->with(['city', 'photos'])
            ->inCity($request->query('city'))
            ->search($request->query('search'));

        if ($request->filled('min_price')) {
            $query->where('price_per_night', '>=', (int) $request->query('min_price'));
        }
        if ($request->filled('max_price')) {
            $query->where('price_per_night', '<=', (int) $request->query('max_price'));
        }
        if ($request->boolean('featured')) {
            $query->where('is_featured', true);
        }
        // Filtres de l'onglet Recherche
        if ($request->filled('min_rooms')) {
            $query->where('beds', '>=', (int) $request->query('min_rooms'));
        }
        if ($request->filled('guests')) {
            $query->where('capacity', '>=', (int) $request->query('guests'));
        }
        if ($request->filled('amenity_ids')) {
            // Une résidence doit proposer TOUTES les commodités cochées
            $ids = array_filter(array_map('intval', explode(',', (string) $request->query('amenity_ids'))));
            foreach ($ids as $amenityId) {
                $query->whereHas('amenities', fn ($q) => $q->where('amenities.id', $amenityId));
            }
        }

        // Les résidences occupées passent après celles qui sont disponibles
        $query->orderByDesc('is_available');

        match ($request->query('sort')) {
            'price_asc' => $query->orderBy('price_per_night'),
            'price_desc' => $query->orderByDesc('price_per_night'),
            'rating' => $query->orderByDesc('rating'),
            default => $query->latest(),
        };

        $properties = $query->paginate(min(max($request->integer('per_page', 20), 1), 50));

        if ($user = $request->user('sanctum')) {
            $favoriteIds = $user->favorites()->pluck('properties.id')->toArray();
            $properties->getCollection()->transform(function ($p) use ($favoriteIds) {
                $p->is_favorite = in_array($p->id, $favoriteIds);
                return $p;
            });
        }

        return PropertyResource::collection($properties);
    }

    /** GET /api/properties/{property} */
    public function show(Request $request, Property $property)
    {
        // Une résidence en attente ou retirée n'est visible que par son propriétaire (et l'admin).
        $viewer = $request->user('sanctum');
        if ($property->status !== 'active' && ! ($viewer && ($viewer->id === $property->owner_id || $viewer->role === 'admin'))) {
            abort(404, 'Résidence introuvable');
        }

        $property->load(['city', 'photos', 'amenities', 'owner']);

        if ($user = $viewer) {
            $property->is_favorite = $user->favorites()->where('properties.id', $property->id)->exists();
        }

        return new PropertyResource($property);
    }

    /** GET /api/my-properties — toutes les résidences du propriétaire connecté, quel que soit leur statut */
    public function myProperties(Request $request)
    {
        if (! $request->user()->isOwner()) {
            return response()->json(['message' => 'Réservé aux propriétaires'], 403);
        }

        $properties = $request->user()
            ->properties()
            ->with(['city', 'photos', 'amenities'])
            ->latest()
            ->get();

        return PropertyResource::collection($properties);
    }

    /** POST /api/properties  (propriétaire uniquement) */
    public function store(Request $request)
    {
        if (! $request->user()->isOwner()) {
            return response()->json(['message' => 'Réservé aux propriétaires'], 403);
        }

        if (Property::slotsUsedBy($request->user()->id) >= Property::MAX_PER_OWNER) {
            return response()->json([
                'message' => 'Tu as atteint la limite de '.Property::MAX_PER_OWNER.' résidences par compte. '
                    .'Pour en ajouter une autre, contacte l\'administrateur REM-CI au '.UserNotification::adminContacts().'.',
                'code' => 'property_limit',
            ], 422);
        }

        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'city_id' => ['required', 'exists:cities,id'],
            'description' => ['nullable', 'string', 'max:5000'],
            'price_per_night' => ['required', 'integer', 'min:1000', 'max:10000000'],
            'beds' => ['nullable', 'integer', 'min:1', 'max:50'],
            'bathrooms' => ['nullable', 'integer', 'min:1', 'max:50'],
            'capacity' => ['nullable', 'integer', 'min:1', 'max:100'],
            'address' => ['nullable', 'string', 'max:255'],
            // Position GPS relevée au moment des photos (gratuit, via le capteur du
            // téléphone) — sert à situer précisément la résidence sur une carte.
            'latitude' => ['nullable', 'numeric', 'between:-90,90'],
            'longitude' => ['nullable', 'numeric', 'between:-180,180'],
            'amenity_ids' => ['nullable', 'array', 'max:50'],
            'amenity_ids.*' => ['integer', 'exists:amenities,id'],
        ]);

        // Titre toujours au format « Résidence meublée <nom> »
        $data['title'] = ListingRules::normalizeTitle($data['title']);
        if ($data['title'] === '') {
            return response()->json(['message' => 'Donne un nom à ta résidence (ex. Les Palmiers Cocody).', 'code' => 'title_required'], 422);
        }

        // Filtre automatique : insultes, coordonnées glissées dans le texte…
        $flags = [];
        foreach (['title' => 'Le titre', 'description' => 'La description', 'address' => "L'adresse"] as $field => $label) {
            $check = TextModerator::check($data[$field] ?? null);
            if ($check['blocked']) {
                return response()->json(['message' => "{$label} : ".$check['message'], 'code' => 'text_rejected'], 422);
            }
            $flags = array_merge($flags, $check['flags']);
            if ($field !== 'address') {
                $rule = ListingRules::screen($data[$field] ?? null, $field);
                if ($rule['blocked']) {
                    return response()->json(['message' => "{$label} ".ListingRules::refusalMessage(), 'code' => 'text_rejected'], 422);
                }
                $flags = array_merge($flags, $rule['flags']);
            }
        }

        $property = Property::create([
            ...$data,
            'review_flags' => $flags ? implode(' ; ', array_unique($flags)) : null,
            'owner_id' => $request->user()->id,
            'slug' => Str::slug($data['title']).'-'.Str::random(5),
            // En attente : rendue visible uniquement après activation manuelle par
            // l'administrateur (phpMyAdmin), une fois le propriétaire certifié.
            'status' => 'pending',
        ]);

        if (! empty($data['amenity_ids'])) {
            $property->amenities()->sync($data['amenity_ids']);
        }

        return new PropertyResource($property->load(['city', 'amenities']));
    }

    /**
     * PATCH /api/properties/{property}/availability  { "is_available": true|false }
     * Le propriétaire indique lui-même si sa résidence est libre (icône bleue côté locataires)
     * ou occupée (icône rouge) — le paiement se faisant hors application, c'est lui qui sait.
     */
    public function setAvailability(Request $request, Property $property)
    {
        if ($property->owner_id !== $request->user()->id) {
            return response()->json(['message' => 'Non autorisé'], 403);
        }

        $data = $request->validate(['is_available' => ['required', 'boolean']]);

        $property->update([
            'is_available' => $data['is_available'],
            'availability_updated_at' => now(),
        ]);

        return new PropertyResource($property->load(['city', 'photos']));
    }

    /** Champs qu'un propriétaire ne peut plus changer une fois sa résidence publiée. */
    private const LOCKED_AFTER_PUBLISH = ['title', 'price_per_night', 'beds', 'bathrooms', 'capacity', 'address'];

    /**
     * PATCH /api/properties/{property}
     *
     * - Résidence PUBLIÉE : seules la description et les commodités se modifient (faute de frappe,
     *   WiFi installé depuis…). Titre, prix, capacité et adresse sont verrouillés : pour les changer,
     *   le propriétaire contacte l'administrateur.
     * - Résidence pas encore publiée (ou retirée) : tous les champs restent modifiables.
     * Chaque texte modifié passe par le filtre automatique, et chaque modification d'une résidence
     * publiée est enregistrée et signalée à l'administrateur (panneau « Modifications »).
     */
    public function update(Request $request, Property $property)
    {
        if ($property->owner_id !== $request->user()->id) {
            return response()->json(['message' => 'Non autorisé'], 403);
        }

        $data = $request->validate([
            'title' => ['sometimes', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:5000'],
            'price_per_night' => ['sometimes', 'integer', 'min:1000', 'max:10000000'],
            'beds' => ['sometimes', 'integer', 'min:1', 'max:50'],
            'bathrooms' => ['sometimes', 'integer', 'min:1', 'max:50'],
            'capacity' => ['sometimes', 'integer', 'min:1', 'max:100'],
            'address' => ['nullable', 'string', 'max:255'],
            // Liste complète des commodités à jour : celles décochées sont retirées.
            'amenity_ids' => ['sometimes', 'array'],
            'amenity_ids.*' => ['integer', 'exists:amenities,id'],
        ]);

        $published = $property->status === 'active';

        if (array_key_exists('title', $data)) {
            $data['title'] = ListingRules::normalizeTitle($data['title']);
            if ($data['title'] === '') {
                return response()->json(['message' => 'Donne un nom à ta résidence (ex. Les Palmiers Cocody).', 'code' => 'title_required'], 422);
            }
        }

        if ($published) {
            foreach (self::LOCKED_AFTER_PUBLISH as $field) {
                $current = $field === 'title' ? ListingRules::normalizeTitle($property->title) : (string) $property->{$field};
                if (array_key_exists($field, $data) && (string) $data[$field] !== (string) $current) {
                    return response()->json([
                        'message' => 'Une fois la résidence publiée, tu ne peux modifier que la description et les commodités. '
                            .'Pour changer le titre, le prix, la capacité ou l\'adresse, contacte l\'administrateur REM-CI au '
                            .UserNotification::adminContacts().'.',
                        'code' => 'locked_after_publish',
                    ], 422);
                }
            }
            $data = array_intersect_key($data, array_flip(['description', 'amenity_ids']));
        }

        // Filtre automatique sur chaque texte réellement modifié
        $flags = [];
        foreach (['title' => 'Le titre', 'description' => 'La description', 'address' => "L'adresse"] as $field => $label) {
            if (! array_key_exists($field, $data) || (string) $data[$field] === (string) $property->{$field}) {
                continue;
            }
            $check = TextModerator::check($data[$field]);
            if ($check['blocked']) {
                return response()->json(['message' => "{$label} : ".$check['message'], 'code' => 'text_rejected'], 422);
            }
            $flags = array_merge($flags, $check['flags']);
            if ($field !== 'address') {
                $rule = ListingRules::screen($data[$field], $field);
                if ($rule['blocked']) {
                    return response()->json(['message' => "{$label} ".ListingRules::refusalMessage(), 'code' => 'text_rejected'], 422);
                }
                $flags = array_merge($flags, $rule['flags']);
            }
        }

        // Résidence pas encore publiée : les signalements restent visibles pour l'administrateur avant activation
        if (! $published && $flags) {
            $data['review_flags'] = implode(' ; ', array_unique(array_merge(
                array_filter(explode(' ; ', (string) $property->review_flags)), $flags
            )));
        }

        $amenityIds = $data['amenity_ids'] ?? null;
        unset($data['amenity_ids']);

        $oldDescription = $property->description;
        $oldAmenities = $property->amenities()->pluck('name')->sort()->values()->all();

        $property->update($data);
        if ($amenityIds !== null) {
            $property->amenities()->sync($amenityIds);
        }
        $property->load(['city', 'photos', 'amenities']);

        // Journal + signalement à l'administrateur (résidence publiée uniquement)
        if ($published) {
            $this->logEdits($request->user(), $property, $oldDescription, $oldAmenities, $flags);
        }

        return new PropertyResource($property);
    }

    /** Enregistre ce qui a changé et prévient les administrateurs. */
    private function logEdits(User $owner, Property $property, ?string $oldDescription, array $oldAmenities, array $flags): void
    {
        $changed = [];

        if ((string) $oldDescription !== (string) $property->description) {
            PropertyEdit::create([
                'property_id' => $property->id,
                'user_id' => $owner->id,
                'field' => 'description',
                'old_value' => $oldDescription,
                'new_value' => $property->description,
                'flagged' => $flags !== [],
                'flag_reason' => $flags ? implode(' ; ', array_unique($flags)) : null,
            ]);
            $changed[] = 'description'.($flags ? ' ⚠' : '');
        }

        $newAmenities = $property->amenities->pluck('name')->sort()->values()->all();
        if ($oldAmenities !== $newAmenities) {
            PropertyEdit::create([
                'property_id' => $property->id,
                'user_id' => $owner->id,
                'field' => 'amenities',
                'old_value' => implode(', ', $oldAmenities),
                'new_value' => implode(', ', $newAmenities),
            ]);
            $changed[] = 'commodités';
        }

        if ($changed === []) {
            return;
        }

        $body = "{$owner->name} a modifié « {$property->title} » : ".implode(' et ', $changed).'.'
            .($flags ? ' À vérifier en priorité.' : '').' Voir Administration > Modifications.';
        foreach (User::where('role', 'admin')->get() as $admin) {
            UserNotification::notify($admin, 'property_edit', 'Annonce modifiée', $body, ['property_id' => $property->id]);
        }
    }
}
