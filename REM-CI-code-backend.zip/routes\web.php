<?php

use App\Http\Controllers\Admin\AdController as AdminAdController;
use App\Http\Controllers\Admin\AuthController as AdminAuthController;
use App\Http\Controllers\Admin\BookingController as AdminBookingController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\EditController;
use App\Http\Controllers\Admin\OwnerController;
use App\Http\Controllers\Admin\PropertyController as AdminPropertyController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ReceiptVerificationController;
use App\Http\Middleware\EnsureAdmin;
use Illuminate\Support\Facades\Route;

// Pages publiques (exigées par Google Play : politique de confidentialité, conditions, suppression de compte)
Route::get('/', [PageController::class, 'home'])->name('home');
Route::get('/confidentialite', [PageController::class, 'privacy'])->name('legal.privacy');
Route::get('/conditions', [PageController::class, 'terms'])->name('legal.terms');
Route::get('/media/ads/{file}', [PageController::class, 'adImage'])
    ->where('file', '[A-Za-z0-9\-]+\.(jpg|jpeg|png|webp)')->name('media.ad');
Route::get('/media/{dir}/{file}', [PageController::class, 'mediaFile'])
    ->whereIn('dir', ['ads', 'property_photos', 'avatars'])
    ->where('file', '[A-Za-z0-9._\-]+\.(jpg|jpeg|png|webp|gif)')->name('media.file');
Route::get('/suppression-compte', [PageController::class, 'deletion'])->name('legal.deletion');

// Vérification publique d'un reçu de réservation (page ouverte par le code QR du reçu)
Route::get('/verifier/{reference}', [ReceiptVerificationController::class, 'show'])
    ->where('reference', 'REMCI-[A-Z0-9]{8}')
    ->middleware('throttle:40,1')
    ->name('receipt.verify');

/*
|--------------------------------------------------------------------------
| Panneau d'administration REM-CI — https://tondomaine.com/admin
|--------------------------------------------------------------------------
| Réservé aux comptes dont le rôle est "admin" (voir `php artisan remci:create-admin`).
| Certification des propriétaires, activation des résidences, suivi des utilisateurs.
*/
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('login', [AdminAuthController::class, 'showLogin'])->name('login');
    Route::post('login', [AdminAuthController::class, 'login'])->middleware('throttle:10,1')->name('login.submit');

    Route::middleware(EnsureAdmin::class)->group(function () {
        Route::post('logout', [AdminAuthController::class, 'logout'])->name('logout');

        Route::get('/', DashboardController::class)->name('dashboard');

        Route::get('proprietaires', [OwnerController::class, 'index'])->name('owners.index');
        Route::get('proprietaires/{user}', [OwnerController::class, 'show'])->name('owners.show');
        Route::get('proprietaires/{user}/document/{side}', [OwnerController::class, 'document'])
            ->whereIn('side', ['recto', 'verso'])->name('owners.document');
        Route::post('proprietaires/{user}/certifier', [OwnerController::class, 'certify'])->name('owners.certify');
        Route::post('proprietaires/{user}/refuser', [OwnerController::class, 'reject'])->name('owners.reject');

        Route::get('residences', [AdminPropertyController::class, 'index'])->name('properties.index');
        Route::get('residences/photo/{photo}', [AdminPropertyController::class, 'photo'])->name('properties.photo');
        Route::get('residences/{property}', [AdminPropertyController::class, 'show'])->name('properties.show');
        Route::post('residences/{property}/statut', [AdminPropertyController::class, 'setStatus'])->name('properties.status');
        Route::post('residences/{property}/informations', [AdminPropertyController::class, 'updateDetails'])->name('properties.details');

        Route::get('utilisateurs', [AdminUserController::class, 'index'])->name('users.index');
        Route::get('locataires/{user}', [AdminUserController::class, 'show'])->name('tenants.show');
        Route::get('locataires/{user}/document/{side}', [AdminUserController::class, 'document'])
            ->whereIn('side', ['recto', 'verso'])->name('tenants.document');
        Route::post('locataires/{user}/identite/valider', [AdminUserController::class, 'verifyIdentity'])->name('tenants.verify');
        Route::post('locataires/{user}/identite/refuser', [AdminUserController::class, 'rejectIdentity'])->name('tenants.reject');
        Route::get('reservations', [AdminBookingController::class, 'index'])->name('bookings.index');

        Route::get('publicites', [AdminAdController::class, 'index'])->name('ads.index');
        Route::post('publicites', [AdminAdController::class, 'store'])->name('ads.store');
        Route::post('publicites/{ad}', [AdminAdController::class, 'update'])->name('ads.update');
        Route::post('publicites/{ad}/afficher', [AdminAdController::class, 'toggle'])->name('ads.toggle');
        Route::post('publicites/{ad}/supprimer', [AdminAdController::class, 'destroy'])->name('ads.destroy');

        Route::get('modifications', [EditController::class, 'index'])->name('edits.index');
        Route::post('modifications/{edit}/verifier', [EditController::class, 'review'])->name('edits.review');
        Route::post('modifications/{edit}/annuler', [EditController::class, 'revert'])->name('edits.revert');
    });
});
