package com.abitechnologie.remci.data.repository

import com.abitechnologie.remci.data.network.ForgotPasswordRequest
import com.abitechnologie.remci.data.network.ForgotPasswordResponse
import com.abitechnologie.remci.data.network.GoogleLoginRequest
import com.abitechnologie.remci.data.network.LoginRequest
import com.abitechnologie.remci.data.network.ResetPasswordRequest
import com.abitechnologie.remci.data.network.RegisterRequest
import com.abitechnologie.remci.data.network.RetrofitClient
import com.abitechnologie.remci.data.network.TokenManager
import com.abitechnologie.remci.data.network.UserDto

sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    /** `code` : identifiant renvoyé par le serveur (ex. "profile_incomplete", "daily_limit"). */
    data class Error(val message: String, val code: String? = null) : ApiResult<Nothing>()
}

class AuthRepository {
    private val api = RetrofitClient.api

    suspend fun login(phone: String, password: String, role: String? = null): ApiResult<UserDto> = try {
        val response = api.login(LoginRequest(phone, password, role))
        if (response.isSuccessful && response.body() != null) {
            val body = response.body()!!
            TokenManager.saveToken(body.token)
            TokenManager.saveRole(body.user.role)
            ApiResult.Success(body.user)
        } else {
            ApiResult.Error(errorMessage(response.errorBody()?.string(), "Identifiants incorrects"))
        }
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    suspend fun register(name: String, phone: String, email: String?, password: String, role: String): ApiResult<UserDto> = try {
        val response = api.register(RegisterRequest(name, phone, email, password, role))
        if (response.isSuccessful && response.body() != null) {
            val body = response.body()!!
            TokenManager.saveToken(body.token)
            TokenManager.saveRole(body.user.role)
            ApiResult.Success(body.user)
        } else {
            ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible de créer le compte"))
        }
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /** Connexion / création de compte avec Google (le jeton est vérifié par le serveur). */
    suspend fun googleLogin(idToken: String, role: String): ApiResult<UserDto> = try {
        val response = api.googleLogin(GoogleLoginRequest(idToken, role))
        if (response.isSuccessful && response.body() != null) {
            val body = response.body()!!
            TokenManager.saveToken(body.token)
            TokenManager.saveRole(body.user.role)
            ApiResult.Success(body.user)
        } else {
            ApiResult.Error(errorMessage(response.errorBody()?.string(), "Connexion Google impossible"))
        }
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /** Étape 1 du mot de passe oublié : envoie un code à 6 chiffres par e-mail. */
    suspend fun forgotPassword(identifier: String): ApiResult<ForgotPasswordResponse> = try {
        val response = api.forgotPassword(ForgotPasswordRequest(identifier))
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible d'envoyer le code"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /** Étape 2 : vérifie le code et enregistre le nouveau mot de passe. */
    suspend fun resetPassword(identifier: String, code: String, password: String, confirmation: String): ApiResult<String> = try {
        val response = api.resetPassword(ResetPasswordRequest(identifier, code, password, confirmation))
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.message)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible de modifier le mot de passe"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    suspend fun logout() {
        try { api.logout() } catch (_: Exception) { }
        TokenManager.clear()
    }

    /** Session déjà active (token stocké) — récupère le profil à jour pour savoir,
     * entre autres, si un propriétaire doit encore être redirigé vers la vérification. */
    suspend fun me(): ApiResult<UserDto> = try {
        val response = api.me()
        when {
            response.isSuccessful && response.body() != null -> ApiResult.Success(response.body()!!.data)
            response.code() == 401 -> ApiResult.Error("Session expirée, reconnecte-toi", SESSION_EXPIRED)
            else -> ApiResult.Error("Le serveur est momentanément indisponible. Réessaie dans un instant.", NETWORK)
        }
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e), NETWORK)
    }
}

/** Codes d'erreur locaux (ne viennent pas du serveur). */
const val SESSION_EXPIRED = "session_expired"
const val NETWORK = "network"


/** Message d'erreur lisible même quand le backend est injoignable */
fun networkErrorMessage(e: Exception): String = when {
    e is java.net.SocketTimeoutException || e.message?.contains("timeout", true) == true ->
        "Le serveur met trop de temps à répondre (connexion lente ?). Réessaie dans un instant."
    e is java.net.UnknownHostException ->
        "Impossible de joindre le serveur. Vérifie ta connexion internet."
    e.message?.contains("Connection refused", true) == true || e.message?.contains("ECONNREFUSED", true) == true ||
        e is java.net.ConnectException ->
        "Impossible de joindre le serveur. Vérifie ta connexion internet et réessaie."
    else -> "Erreur réseau : ${e.message ?: "inconnue"}"
}

/** Code d'erreur métier renvoyé par le serveur (champ "code"), ou null. */
fun errorCode(rawBody: String?): String? = try {
    org.json.JSONObject(rawBody ?: "").optString("code").takeIf { it.isNotBlank() }
} catch (_: Exception) {
    null
}

fun errorMessage(rawBody: String?, fallback: String): String {
    if (rawBody.isNullOrBlank()) return fallback
    return try {
        // JSONObject décode correctement les accents échappés par Laravel (\u00e9...)
        val json = org.json.JSONObject(rawBody)
        val errors = json.optJSONObject("errors")
        val firstFieldError = errors?.keys()?.asSequence()?.firstOrNull()?.let { key ->
            errors?.optJSONArray(key)?.optString(0)
        }
        val message = json.optString("message")
        when {
            // 422 générique « Erreur de validation » : le détail du champ est plus utile
            !firstFieldError.isNullOrBlank() && (message.isBlank() || message == "Erreur de validation" || message.startsWith("The ")) -> firstFieldError
            message.isNotBlank() -> message
            else -> fallback
        }
    } catch (_: Exception) {
        fallback
    }
}
