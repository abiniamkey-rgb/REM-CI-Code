package com.abitechnologie.remci.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.abitechnologie.remci.data.network.AmenityDto
import com.abitechnologie.remci.data.network.CityDto
import com.abitechnologie.remci.data.network.CreatePropertyRequest
import com.abitechnologie.remci.data.network.PropertyDto
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.PropertyRepository
import com.abitechnologie.remci.ui.components.CircleIconButton
import com.abitechnologie.remci.ui.components.GeoPoint
import com.abitechnologie.remci.ui.components.clickableNoRipple
import com.abitechnologie.remci.ui.components.rememberCameraCapture
import com.abitechnologie.remci.ui.components.rememberLocationCapture
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val MAX_PHOTOS = 8

/** Une annonce sans photos se loue très mal : au moins 3 photos sont exigées. */
private const val MIN_PHOTOS = 3

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun AddPropertyScreen(onBack: () -> Unit, onCreated: (PropertyDto) -> Unit) {
    val repository = remember { PropertyRepository() }
    var cities by remember { mutableStateOf<List<CityDto>>(emptyList()) }
    var selectedCity by remember { mutableStateOf<CityDto?>(null) }
    var cityMenuOpen by remember { mutableStateOf(false) }

    var amenities by remember { mutableStateOf<List<AmenityDto>>(emptyList()) }
    var selectedAmenityIds by remember { mutableStateOf<Set<Int>>(emptySet()) }

    var title by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var rooms by remember { mutableStateOf("2") }
    var capacity by remember { mutableStateOf("2") }
    var bathrooms by remember { mutableStateOf("1") }
    var address by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var photos by remember { mutableStateOf<List<File>>(emptyList()) }
    var location by remember { mutableStateOf<GeoPoint?>(null) }
    var locating by remember { mutableStateOf(false) }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val captureLocation = rememberLocationCapture { point ->
        location = point
        locating = false
    }

    // Photos prises sur place avec l'appareil photo (au moins une : c'est elle qui fixe la position GPS)
    var cameraPhotos by remember { mutableStateOf<Set<File>>(emptySet()) }
    var importing by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Après la 1re photo prise sur place : les suivantes peuvent venir de la galerie
    val pickFromGallery = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(MAX_PHOTOS - 1)
    ) { uris ->
        val room = MAX_PHOTOS - photos.size
        if (uris.isNullOrEmpty() || room <= 0) return@rememberLauncherForActivityResult
        importing = true
        scope.launch {
            val files = withContext(Dispatchers.IO) {
                uris.take(room).mapIndexedNotNull { i, uri -> copyGalleryImage(context, uri, i) }
            }
            photos = (photos + files).take(MAX_PHOTOS)
            importing = false
            if (files.size < uris.size.coerceAtMost(room)) error = "Certaines images n'ont pas pu être lues."
            if (uris.size > room) error = "$MAX_PHOTOS photos maximum : seules les $room premières ont été ajoutées."
        }
    }

    val capturePhoto = rememberCameraCapture { file ->
        if (photos.size < MAX_PHOTOS) {
            photos = photos + file
            cameraPhotos = cameraPhotos + file
        }
        // On relève la position GPS au moment de la première photo — gratuit, et ça
        // évite de demander la permission avant que le propriétaire en voie l'intérêt.
        if (location == null && !locating) {
            locating = true
            captureLocation()
        }
    }

    LaunchedEffect(Unit) {
        val citiesResult = repository.getCities()
        if (citiesResult is ApiResult.Success) cities = citiesResult.data
        val amenitiesResult = repository.getAmenities()
        if (amenitiesResult is ApiResult.Success) amenities = amenitiesResult.data
    }

    fun validate(): Boolean {
        if (com.abitechnologie.remci.ui.components.ListingTitle.nameOf(title).isBlank() || selectedCity == null || price.toIntOrNull() == null) {
            error = "Merci de remplir au minimum le nom de la résidence, la ville et le prix"
            return false
        }
        if (photos.none { it in cameraPhotos }) {
            error = "La première photo doit être prise sur place avec l'appareil photo (elle enregistre la position de la résidence)."
            return false
        }
        if (photos.size < MIN_PHOTOS) {
            error = "Ajoute au moins $MIN_PHOTOS photos de la résidence (${photos.size}/$MIN_PHOTOS)."
            return false
        }
        error = null
        return true
    }

    // Une fois créée, la résidence est mémorisée : si l'envoi des photos échoue, un nouvel
    // essai renvoie seulement les photos (pas de doublon de résidence).
    var createdProperty by remember { mutableStateOf<PropertyDto?>(null) }
    var triggerSubmit by remember { mutableStateOf(false) }
    LaunchedEffect(triggerSubmit) {
        if (!triggerSubmit) return@LaunchedEffect

        var property = createdProperty
        if (property == null) {
            val result = repository.createProperty(
                CreatePropertyRequest(
                    title = com.abitechnologie.remci.ui.components.ListingTitle.compose(title),
                    cityId = selectedCity!!.id,
                    description = description.ifBlank { null },
                    pricePerNight = price.toIntOrNull() ?: 0,
                    beds = rooms.toIntOrNull() ?: 1,
                    bathrooms = bathrooms.toIntOrNull() ?: 1,
                    capacity = capacity.toIntOrNull() ?: 2,
                    address = address.ifBlank { null },
                    latitude = location?.latitude,
                    longitude = location?.longitude,
                    amenityIds = selectedAmenityIds.toList().ifEmpty { null }
                )
            )
            when (result) {
                is ApiResult.Success -> {
                    property = result.data
                    createdProperty = result.data
                }
                is ApiResult.Error -> {
                    loading = false
                    triggerSubmit = false
                    error = result.message
                    return@LaunchedEffect
                }
            }
        }

        val propertyId = property?.id ?: return@LaunchedEffect
        when (val photoResult = repository.uploadPhotos(propertyId, photos)) {
            is ApiResult.Success -> {
                loading = false
                triggerSubmit = false
                onCreated(photoResult.data)
            }
            is ApiResult.Error -> {
                loading = false
                triggerSubmit = false
                error = "Ta résidence est enregistrée, mais l'envoi des photos a échoué : ${photoResult.message} " +
                    "Appuie de nouveau sur le bouton pour réessayer."
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())) {
        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIconButton(Icons.Default.ArrowBack, onBack)
            Spacer(Modifier.width(10.dp))
            Text("Ajouter une résidence", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
        }

        Column(modifier = Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {

            // Bandeau d'information — clarifie qu'il n'y a rien à payer et donne un vrai
            // contact si besoin d'aide, sans donner l'impression d'un blocage.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Blue.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = Blue, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        "Remplis les informations ci-dessous et ajoute quelques photos. Pas de paiement à faire : " +
                            "ta demande est examinée par l'administrateur REM-CI avant d'être publiée.",
                        fontSize = 11.5.sp, color = Ink, lineHeight = 16.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Besoin d'aide ? Contacte l'administrateur REM-CI au ${com.abitechnologie.remci.data.AppConfig.ADMIN_PHONES_TEXT}.",
                        fontSize = 11.sp, color = Blue, fontWeight = FontWeight.SemiBold
                    )
                }
            }

            SectionCard("Informations générales") {
                FieldLabel("Nom de la résidence")
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    visualTransformation = com.abitechnologie.remci.ui.components.TitlePrefixTransformation(Green),
                    singleLine = true, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
                Text("Ex. : Les Palmiers Cocody", fontSize = 11.sp, color = Sub, modifier = Modifier.padding(top = 4.dp))

                Spacer(Modifier.height(12.dp))
                FieldLabel("Ville")
                ExposedDropdownMenuBox(expanded = cityMenuOpen, onExpandedChange = { cityMenuOpen = it }) {
                    OutlinedTextField(
                        value = selectedCity?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        placeholder = { Text("Choisir une ville") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = cityMenuOpen) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = cityMenuOpen, onDismissRequest = { cityMenuOpen = false }) {
                        cities.sortedBy { it.name }.forEach { c ->
                            DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedCity = c; cityMenuOpen = false })
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                FieldLabel("Prix par nuit (FCFA)")
                OutlinedTextField(
                    value = price, onValueChange = { price = it.filter { ch -> ch.isDigit() } },
                    placeholder = { Text("Ex. 25000") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
            }

            SectionCard("Capacité de la résidence") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        FieldLabel("Nombre de pièces")
                        OutlinedTextField(
                            value = rooms, onValueChange = { rooms = it.filter { ch -> ch.isDigit() } },
                            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        FieldLabel("Voyageurs")
                        OutlinedTextField(
                            value = capacity, onValueChange = { capacity = it.filter { ch -> ch.isDigit() } },
                            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        FieldLabel("Salle de bain")
                        OutlinedTextField(
                            value = bathrooms, onValueChange = { bathrooms = it.filter { ch -> ch.isDigit() } },
                            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            SectionCard("Commodités disponibles") {
                Text(
                    "Sélectionne tout ce que ta résidence meublée propose.",
                    fontSize = 11.5.sp, color = Sub, modifier = Modifier.padding(bottom = 10.dp)
                )
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    amenities.forEach { amenity ->
                        val selected = selectedAmenityIds.contains(amenity.id)
                        AmenityChip(amenity.name, selected) {
                            selectedAmenityIds = if (selected) selectedAmenityIds - amenity.id else selectedAmenityIds + amenity.id
                        }
                    }
                    if (amenities.isEmpty()) {
                        Text("Chargement des commodités...", fontSize = 11.sp, color = Sub)
                    }
                }
            }

            SectionCard("Adresse & description") {
                FieldLabel("Adresse / quartier")
                OutlinedTextField(
                    value = address, onValueChange = { address = it },
                    placeholder = { Text("Ex. Cocody Riviera 3, Abidjan") },
                    singleLine = true, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                FieldLabel("Description")
                OutlinedTextField(
                    value = description, onValueChange = { description = it },
                    placeholder = { Text("Décris ta résidence : équipements, ambiance, quartier...") },
                    minLines = 3, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
            }

            SectionCard("Photos de la résidence") {
                Text(
                    "Prends la 1re photo sur place avec l'appareil photo : la position GPS de la résidence est " +
                        "relevée automatiquement. Tu peux ensuite compléter avec des photos de ta galerie.",
                    fontSize = 11.5.sp, color = Sub, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 6.dp)
                )
                Text(
                    if (photos.size < MIN_PHOTOS) "${photos.size}/$MIN_PHOTOS photos minimum — ajoute-en ${MIN_PHOTOS - photos.size} de plus"
                    else "${photos.size} photo(s) · $MAX_PHOTOS maximum",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (photos.size < MIN_PHOTOS) OrangeDeep else Green,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(photos) { file ->
                        Box(modifier = Modifier.size(84.dp)) {
                            AsyncImage(
                                model = file,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(3.dp)
                                    .size(20.dp)
                                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                                    .clickableNoRipple { photos = photos - file; cameraPhotos = cameraPhotos - file },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Retirer", tint = Color.White, modifier = Modifier.size(12.dp))
                            }
                        }
                    }
                    if (importing) {
                        item {
                            Box(Modifier.size(84.dp).background(Bg, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = Orange, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                    if (photos.size < MAX_PHOTOS && !importing) {
                        val hasCameraPhoto = photos.any { it in cameraPhotos }
                        item {
                            PhotoTile(
                                icon = Icons.Default.CameraAlt,
                                label = if (hasCameraPhoto) "Appareil" else "1re photo",
                                onClick = capturePhoto
                            )
                        }
                        if (hasCameraPhoto) {
                            item {
                                PhotoTile(
                                    icon = Icons.Default.PhotoLibrary,
                                    label = "Galerie",
                                    onClick = {
                                        pickFromGallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    when {
                        locating -> {
                            CircularProgressIndicator(color = Orange, strokeWidth = 2.dp, modifier = Modifier.size(13.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Localisation en cours...", fontSize = 11.sp, color = Sub)
                        }
                        location != null -> {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = Green, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Position enregistrée", fontSize = 11.sp, color = Green, fontWeight = FontWeight.SemiBold)
                        }
                        photos.isEmpty() -> {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = Sub, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("La position sera relevée à la première photo", fontSize = 11.sp, color = Sub)
                        }
                        else -> {
                            Icon(Icons.Default.LocationOff, contentDescription = null, tint = Sub, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Position non disponible — tu peux publier quand même", fontSize = 11.sp, color = Sub)
                        }
                    }
                }
            }

            if (error != null) {
                Text(error!!, color = OrangeDeep, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }

            Button(
                onClick = { if (validate()) { loading = true; triggerSubmit = true } },
                enabled = !loading,
                colors = ButtonDefaults.buttonColors(containerColor = Orange),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                } else {
                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Envoyer ma demande", fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                }
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(18.dp))
            .border(1.dp, Divider, RoundedCornerShape(18.dp))
            .padding(18.dp)
    ) {
        Text(title, fontSize = 14.5.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(14.dp))
        content()
    }
}

@Composable
private fun AmenityChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) Green else Bg)
            .border(1.dp, if (selected) Green else Divider, RoundedCornerShape(20.dp))
            .clickableNoRipple(onClick)
            .padding(horizontal = 13.dp, vertical = 9.dp)
    ) {
        if (selected) {
            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
        }
        Text(
            label,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (selected) Color.White else Ink
        )
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(text, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = Sub)
}

@Composable
private fun PhotoTile(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(84.dp)
            .background(Bg, RoundedCornerShape(12.dp))
            .border(1.5.dp, Divider, RoundedCornerShape(12.dp))
            .clickableNoRipple(onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = Orange, modifier = Modifier.size(20.dp))
            Text(label, fontSize = 9.5.sp, color = Sub, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

/** Copie une image de la galerie dans le cache de l'app (elle sera compressée avant l'envoi). */
private fun copyGalleryImage(context: android.content.Context, uri: android.net.Uri, index: Int): File? = try {
    val dir = File(context.cacheDir, "camera").apply { mkdirs() }
    val file = File(dir, "galerie_${System.currentTimeMillis()}_$index.jpg")
    context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { input.copyTo(it) } }
    if (file.length() > 0) file else null
} catch (e: Exception) {
    null
}
