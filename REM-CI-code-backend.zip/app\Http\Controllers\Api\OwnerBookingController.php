<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\BookingResource;
use App\Models\Booking;
use App\Models\UserNotification;
use Illuminate\Http\Request;

/** Tableau de bord propriétaire : réservations reçues sur ses propres résidences. */
class OwnerBookingController extends Controller
{
    /** GET /api/owner/bookings */
    public function index(Request $request)
    {
        if (! $request->user()->isOwner()) {
            return response()->json(['message' => 'Réservé aux propriétaires'], 403);
        }

        Booking::expireStale();

        $bookings = Booking::whereHas('property', fn ($q) => $q->where('owner_id', $request->user()->id))
            ->with('property.city', 'user')
            ->latest()
            ->get();

        return BookingResource::collection($bookings);
    }

    /** PATCH /api/owner/bookings/{booking}  { "status": "confirmed" | "cancelled" | "completed" } */
    public function update(Request $request, Booking $booking)
    {
        $booking->load('property');

        if (! $request->user()->isOwner() || $booking->property->owner_id !== $request->user()->id) {
            return response()->json(['message' => 'Non autorisé'], 403);
        }

        $data = $request->validate(['status' => ['required', 'in:confirmed,cancelled,completed']]);

        Booking::expireStale();
        $booking->refresh();
        if ($booking->expired_at) {
            return response()->json(['message' => 'Cette demande a expiré faute de réponse.', 'code' => 'expired'], 422);
        }
        $allowed = ['pending' => ['confirmed', 'cancelled'], 'confirmed' => ['completed', 'cancelled']];
        if (! in_array($data['status'], $allowed[$booking->status] ?? [], true)) {
            return response()->json(['message' => 'Cette demande a déjà été traitée.', 'code' => 'already_handled'], 422);
        }
        if ($data['status'] === 'confirmed') {
            $data['confirmed_at'] = now();
        }
        $booking->update($data);

        $messages = [
            'confirmed' => ['Réservation confirmée ✅', 'Le propriétaire a confirmé ta demande pour « %s ». Ton reçu de réservation avec code QR est disponible dans l\'onglet Réservations. Contacte le propriétaire pour les derniers détails.'],
            'cancelled' => ['Demande refusée', 'Le propriétaire ne peut pas accepter ta demande pour « %s ». Tu peux chercher une autre résidence.'],
            'completed' => ['Séjour terminé', 'Ton séjour à « %s » est marqué comme terminé. Merci d\'avoir choisi REM-CI !'],
        ];
        [$title, $text] = $messages[$data['status']];
        UserNotification::notify(
            $booking->user, 'booking_update', $title, sprintf($text, $booking->property->title),
            ['booking_id' => $booking->id]
        );

        return new BookingResource($booking->load('property.city', 'user'));
    }
}
