package com.abitechnologie.remci.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import com.abitechnologie.remci.R
import com.abitechnologie.remci.ui.theme.*

/** Logo officiel REM-CI (fichier fourni par le client, res/drawable/logo.png) */
@Composable
fun LogoMark(size: Int = 88, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(id = R.drawable.logo),
        contentDescription = "Logo REM-CI",
        modifier = modifier.size(size.dp)
    )
}

@Composable
fun Badge(text: String, color: Color = Orange, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp,
        modifier = modifier
            .background(color, RoundedCornerShape(20.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
fun CircleIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit = {}, tint: Color = Ink) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(CardBg)
            .border(1.dp, Divider, RoundedCornerShape(12.dp))
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        onBack?.let { CircleIconButton(Icons.Default.ArrowBack, it) }
        Text(title, style = MaterialTheme.typography.titleLarge, color = Ink)
    }
}

@Composable
fun FilterChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit = {}) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(CardBg)
            .border(1.dp, Divider, RoundedCornerShape(20.dp))
            .clickableNoRipple(onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(14.dp))
        Text(label, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = Sub, modifier = Modifier.size(14.dp))
    }
}

sealed class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Home : Tab("home", "Accueil", Icons.Default.Home)
    object Search : Tab("search", "Recherche", Icons.Default.Search)
    object Favorites : Tab("favorites", "Favoris", Icons.Default.Favorite)
    object Bookings : Tab("bookings", "Réservations", Icons.Default.CalendarMonth)
    object Profile : Tab("profile", "Profil", Icons.Default.Person)

    // Onglets du tableau de bord propriétaire
    object OwnerDashboard : Tab("owner_dashboard", "Tableau de bord", Icons.Default.Dashboard)
    object OwnerResidences : Tab("owner_residences", "Résidences", Icons.Default.Apartment)
    object OwnerBookings : Tab("owner_bookings", "Réservations", Icons.Default.EventAvailable)
}

val BottomTabs = listOf(Tab.Home, Tab.Search, Tab.Favorites, Tab.Bookings, Tab.Profile)
val OwnerBottomTabs = listOf(Tab.OwnerDashboard, Tab.OwnerResidences, Tab.OwnerBookings, Tab.Profile)

@Composable
fun RemCiBottomBar(current: Tab, tabs: List<Tab> = BottomTabs, onSelect: (Tab) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg)
            .border(width = 1.dp, color = Divider)
            .navigationBarsPadding()
            .padding(top = 8.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        tabs.forEach { tab ->
            val selected = tab.route == current.route
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickableNoRipple { onSelect(tab) }
            ) {
                Icon(tab.icon, contentDescription = tab.label, tint = if (selected) Orange else Sub, modifier = Modifier.size(19.dp))
                Text(tab.label, fontSize = 9.5.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, color = if (selected) Orange else Sub)
            }
        }
    }
}

// Small helpers -------------------------------------------------------------

@Composable
fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier {
    val source = androidx.compose.runtime.remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    return this.clickable(
        interactionSource = source,
        indication = null,
        onClick = onClick
    )
}
