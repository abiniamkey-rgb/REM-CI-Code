<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Property;
use App\Models\User;

class DashboardController extends Controller
{
    public function __invoke()
    {
        Booking::expireStale();

        $stats = [
            'owners_pending' => User::where('role', 'proprietaire')->where('owner_verification_status', 'pending')->count(),
            'owners_verified' => User::where('role', 'proprietaire')->where('owner_verification_status', 'verified')->count(),
            'properties_pending' => Property::where('status', 'pending')->count(),
            'properties_active' => Property::where('status', 'active')->count(),
            'tenants' => User::where('role', 'locataire')->count(),
            'owners' => User::where('role', 'proprietaire')->count(),
            'bookings_pending' => Booking::where('status', 'pending')->count(),
            'bookings_total' => Booking::count(),
            'edits_review' => \App\Models\PropertyEdit::whereNull('reviewed_at')->count(),
            'edits_flagged' => \App\Models\PropertyEdit::where('flagged', true)->whereNull('reviewed_at')->count(),
        ];

        $pendingOwners = User::where('role', 'proprietaire')
            ->where('owner_verification_status', 'pending')
            ->latest('updated_at')->limit(6)->get();

        $pendingProperties = Property::with(['owner', 'city'])
            ->where('status', 'pending')
            ->latest()->limit(6)->get();

        return view('admin.dashboard', compact('stats', 'pendingOwners', 'pendingProperties'));
    }
}
