@extends('admin.layout')
@section('title', $tenant->name)
@section('content')
  <a href="{{ route('admin.users.index', ['role' => 'locataire']) }}" class="sub">← Retour aux locataires</a>
  <h1 style="margin-top:8px">{{ $tenant->name }} @include('admin._badge', ['status' => $tenant->identity_status])</h1>

  <div class="grid two" style="margin-top:14px">
    <div class="card">
      <h2>Dossier locataire</h2>
      <dl>
        <dt>Téléphone</dt><dd>{{ $tenant->phone ?: '—' }}</dd>
        <dt>E-mail</dt><dd>{{ $tenant->email ?: '—' }}</dd>
        <dt>Date de naissance</dt>
        <dd>
          @if($tenant->birth_date)
            {{ $tenant->birth_date->format('d/m/Y') }} ({{ $tenant->age() }} ans)
            @if($tenant->age() < 18) <strong style="color:#c0392b">— MINEUR</strong> @endif
          @else — @endif
        </dd>
        <dt>Adresse</dt><dd>{{ $tenant->address ?: '—' }}</dd>
        <dt>Type de pièce</dt>
        <dd>{{ ['cni' => "Carte nationale d'identité", 'passeport' => 'Passeport', 'attestation' => "Attestation d'identité", 'permis' => 'Permis de conduire'][$tenant->identity_type] ?? '—' }}</dd>
        <dt>N° de pièce</dt><dd>{{ $tenant->identity_number ?: '—' }}</dd>
        <dt>Inscrit</dt><dd>{{ $tenant->created_at?->format('d/m/Y H:i') }}</dd>
        <dt>Identité vérifiée le</dt><dd>{{ $tenant->identity_verified_at?->format('d/m/Y H:i') ?: '—' }}</dd>
        @if($tenant->identity_note)<dt>Motif du refus</dt><dd>{{ $tenant->identity_note }}</dd>@endif
      </dl>
    </div>

    <div class="card">
      <h2>Décision</h2>
      @if($tenant->identity_status === 'not_submitted')
        <div class="sub">Ce locataire n'a pas encore envoyé son dossier. Il ne peut pas réserver.</div>
      @else
        @if($tenant->identity_status !== 'verified')
          <form method="POST" action="{{ route('admin.tenants.verify', $tenant) }}" onsubmit="return confirm('Valider l\'identité de {{ addslashes($tenant->name) }} ?')">
            @csrf <button class="btn" type="submit">✓ Valider l'identité</button>
          </form>
        @endif
        @if($tenant->identity_status !== 'rejected')
          <form method="POST" action="{{ route('admin.tenants.reject', $tenant) }}" style="margin-top:16px" onsubmit="return confirm('Refuser ce dossier ?')">
            @csrf
            <label for="motif" class="sub">Motif du refus (visible par le locataire, facultatif)</label>
            <textarea id="motif" name="motif" rows="2" maxlength="300" placeholder="Ex. Photo illisible, le nom ne correspond pas à la pièce."></textarea>
            <button class="btn red" type="submit" style="margin-top:10px">Refuser le dossier</button>
          </form>
        @endif
        <div class="sub" style="margin-top:12px">Un dossier « à examiner » permet déjà de réserver ; refuser le dossier bloque les nouvelles réservations jusqu'à sa correction. Le locataire reçoit une notification.</div>
      @endif
    </div>
  </div>

  <div class="card" style="margin-top:14px">
    <h2>Pièce d'identité</h2>
    @if($hasRecto || $hasVerso)
      <div class="docs">
        @if($hasRecto)<a href="{{ route('admin.tenants.document', [$tenant, 'recto']) }}" target="_blank"><div class="sub">Recto</div><img src="{{ route('admin.tenants.document', [$tenant, 'recto']) }}" alt="Recto de la pièce d'identité"></a>@endif
        @if($hasVerso)<a href="{{ route('admin.tenants.document', [$tenant, 'verso']) }}" target="_blank"><div class="sub">Verso</div><img src="{{ route('admin.tenants.document', [$tenant, 'verso']) }}" alt="Verso de la pièce d'identité"></a>@endif
      </div>
    @else
      <div class="sub">Aucune photo disponible.</div>
    @endif
  </div>

  <div class="card tablewrap" style="margin-top:14px">
    <h2>Dernières demandes de réservation</h2>
    <table>
      <thead><tr><th>Résidence</th><th>Arrivée</th><th>Départ</th><th>Statut</th><th>Envoyée</th></tr></thead>
      <tbody>
      @forelse($tenant->bookings as $b)
        <tr>
          <td>{{ $b->property?->title }}</td>
          <td>{{ $b->check_in->format('d/m/Y') }}</td><td>{{ $b->check_out->format('d/m/Y') }}</td>
          <td>@include('admin._badge', ['status' => $b->status])</td>
          <td class="sub">{{ $b->created_at?->format('d/m/Y H:i') }}</td>
        </tr>
      @empty
        <tr><td colspan="5" class="empty">Aucune demande.</td></tr>
      @endforelse
      </tbody>
    </table>
  </div>
@endsection
