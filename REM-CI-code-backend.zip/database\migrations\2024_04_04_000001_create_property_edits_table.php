<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('property_edits', function (Blueprint $table) {
            $table->id();
            $table->foreignId('property_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('field', 30);              // description | amenities
            $table->text('old_value')->nullable();
            $table->text('new_value')->nullable();
            $table->boolean('flagged')->default(false);   // signalée par le filtre automatique
            $table->string('flag_reason')->nullable();
            $table->timestamp('reviewed_at')->nullable(); // vérifiée par l'administrateur
            $table->timestamp('reverted_at')->nullable(); // modification annulée par l'administrateur
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('property_edits');
    }
};
