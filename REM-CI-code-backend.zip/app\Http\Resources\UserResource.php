<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
            'role' => $this->role,
            // URL complète : photo de Google telle quelle, ou fichier envoyé depuis l'app
            'avatar' => $this->avatar
                ? \App\Support\PublicUrl::file($request, $this->avatar)
                : null,
            'is_verified' => $this->is_verified,
            'address' => $this->address,
            'owner_verification_status' => $this->owner_verification_status,
            'needs_owner_verification' => $this->needsOwnerVerification(),
            // Lu automatiquement (OCR sur le téléphone) sur la pièce d'identité lors de la
            // soumission — juste une aide pour l'admin qui certifie manuellement le dossier.
            'detected_name' => $this->detected_name,
            'detected_id_number' => $this->detected_id_number,
        ] + ($this->role === 'locataire' ? $this->tenantFields() : []);
    }

    /** Dossier locataire + compteur de demandes du jour (affiché dans l'écran de réservation). */
    private function tenantFields(): array
    {
        return [
            'birth_date' => $this->birth_date?->toDateString(),
            'age' => $this->age(),
            'identity_type' => $this->identity_type,
            'identity_number' => $this->identity_number,
            'identity_status' => $this->identity_status,
            'identity_note' => $this->identity_note,
            'tenant_profile_complete' => $this->hasTenantProfile(),
            'bookings_today' => \App\Models\Booking::sentTodayBy($this->id),
            'daily_booking_limit' => \App\Models\Booking::DAILY_LIMIT,
        ];
    }
}
