package com.abitechnologie.remci.ui.components

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.data.AppConfig
import com.abitechnologie.remci.ui.theme.*

fun dialNumber(context: Context, rawNumber: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$rawNumber")))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "Aucune application d'appel disponible", Toast.LENGTH_SHORT).show()
    }
}

/** Numéro ivoirien à 10 chiffres → WhatsApp (indicatif +225). */
fun openWhatsAppTo(context: Context, rawNumber: String, message: String = "Bonjour, je vous contacte depuis l'application REM-CI.") {
    val digits = rawNumber.filter { it.isDigit() }
    val international = if (digits.startsWith("225")) digits else "225$digits"
    try {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$international?text=${Uri.encode(message)}"))
        )
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "WhatsApp n'est pas installé", Toast.LENGTH_SHORT).show()
    }
}

/**
 * Coordonnées de l'administrateur REM-CI : un bouton Appeler et un bouton WhatsApp par numéro.
 * Utilisé partout où l'utilisateur doit joindre l'administrateur (validation, aide).
 */
@Composable
fun AdminContactBlock(
    modifier: Modifier = Modifier,
    title: String? = "Contacter l'administrateur REM-CI",
    whatsappMessage: String = "Bonjour, je souhaite la validation de mon compte propriétaire / de ma résidence sur REM-CI."
) {
    val context = LocalContext.current
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (title != null) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        }
        AppConfig.ADMIN_PHONES.forEach { phone ->
            // Une carte par numéro : numéro sur une seule ligne, puis deux boutons de même largeur,
            // alignés (le numéro ne passe plus jamais à la ligne).
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Call, contentDescription = null, tint = Green, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        phone.display, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Ink,
                        maxLines = 1, softWrap = false, letterSpacing = 0.5.sp
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    ContactButton(Icons.Default.Call, "Appeler", Green, Modifier.weight(1f)) { dialNumber(context, phone.raw) }
                    ContactButton(Icons.Default.Chat, "WhatsApp", Color(0xFF1FA855), Modifier.weight(1f)) { openWhatsAppTo(context, phone.raw, whatsappMessage) }
                }
            }
        }
    }
}

@Composable
private fun ContactButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .height(42.dp)
            .background(color, RoundedCornerShape(12.dp))
            .clickableNoRipple(onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
    }
}
