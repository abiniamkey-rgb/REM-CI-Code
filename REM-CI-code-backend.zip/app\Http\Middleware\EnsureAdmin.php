<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/** Laisse passer uniquement un compte connecté (session web) dont le rôle est "admin". */
class EnsureAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = Auth::guard('web')->user();

        if (! $user || $user->role !== 'admin') {
            return redirect()->route('admin.login');
        }

        // Dates relatives en français ("il y a 20 minutes")
        \Carbon\Carbon::setLocale('fr');

        return $next($request);
    }
}
