<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // La pièce d'identité ivoirienne se présente recto/verso : `id_document_url`
            // (existant) sert désormais de recto, on ajoute le verso. Les deux champs
            // "detected_*" stockent ce que la reconnaissance de texte (ML Kit, sur le
            // téléphone) a lu sur la photo — juste une aide pour l'administrateur qui
            // certifie le dossier manuellement, jamais une validation automatique.
            $table->string('id_document_verso_url')->nullable()->after('id_document_url');
            $table->string('detected_name')->nullable()->after('id_document_verso_url');
            $table->string('detected_id_number')->nullable()->after('detected_name');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['id_document_verso_url', 'detected_name', 'detected_id_number']);
        });
    }
};
