<?php

namespace App\Support;

use Illuminate\Http\Request;

/**
 * Adresse de base servie aux apps pour les images (photos, avatars, publicités).
 * Derrière un tunnel (ngrok) ou un proxy, Laravel peut croire que la requête est en HTTP :
 * or Android refuse le HTTP non chiffré. Hors réseau local, on force donc HTTPS.
 */
class PublicUrl
{
    public static function base(Request $request): string
    {
        $host = $request->getHost();
        $local = in_array($host, ['localhost', '127.0.0.1', '10.0.2.2'], true)
            || (bool) preg_match('/^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/', $host);

        return ($local ? $request->getScheme() : 'https').'://'.$request->getHttpHost();
    }

    /**
     * Adresse publique d'un fichier du stockage public. Les photos de résidence, avatars et
     * publicités passent par /media/… (servi par Laravel, sans dépendre du lien `public/storage`) ;
     * les URL externes sont renvoyées telles quelles.
     */
    public static function file(Request $request, string $path): string
    {
        if (str_starts_with($path, 'http')) {
            return $path;
        }

        if (preg_match('#^(property_photos|avatars|ads)/([A-Za-z0-9._\-]+)$#', $path, $m)) {
            return self::base($request).'/media/'.$m[1].'/'.$m[2];
        }

        return self::base($request).'/storage/'.ltrim($path, '/');
    }
}
