<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AdResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'subtitle' => $this->subtitle,
            'image_url' => $this->image_path ? \App\Support\PublicUrl::file($request, $this->image_path) : null,
            'badge' => $this->badge,
            'ends_at' => $this->ends_at?->toDateString(),
            'color_a' => $this->color_a,
            'color_b' => $this->color_b,
            'property_id' => $this->property_id,
        ];
    }
}
