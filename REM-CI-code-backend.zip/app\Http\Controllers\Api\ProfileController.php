<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\Booking;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

/** Profil de l'utilisateur connecté : infos, photo, mot de passe. */
class ProfileController extends Controller
{
    /** PATCH /api/profile  { name?, email?, phone? } */
    public function update(Request $request)
    {
        $user = $request->user();

        if ($request->filled('phone')) {
            $request->merge(['phone' => preg_replace('/[\s.\-()]+/', '', trim((string) $request->phone))]);
        }
        if ($request->filled('email')) {
            $request->merge(['email' => strtolower(trim((string) $request->email))]);
        }

        $data = $request->validate([
            'name' => ['sometimes', 'required', 'string', 'max:255'],
            'email' => ['sometimes', 'required', 'email', Rule::unique('users', 'email')->ignore($user->id)],
            'phone' => ['sometimes', 'required', 'string', 'min:8', 'max:20', Rule::unique('users', 'phone')->ignore($user->id)],
        ], [
            'name.required' => 'Le nom ne peut pas être vide.',
            'email.required' => "L'adresse e-mail est obligatoire.",
            'email.email' => 'Cette adresse e-mail semble invalide.',
            'email.unique' => 'Cette adresse e-mail est déjà utilisée par un autre compte.',
            'phone.required' => 'Le numéro de téléphone est obligatoire.',
            'phone.unique' => 'Ce numéro est déjà utilisé par un autre compte.',
        ]);

        // Identité vérifiée par REM-CI : le nom doit rester celui de la pièce d'identité.
        if (isset($data['name']) && $user->role === 'locataire' && $user->identity_status === 'verified'
            && trim($data['name']) !== trim((string) $user->name)) {
            return response()->json([
                'message' => "Ton nom est verrouillé car ton identité est vérifiée. Contacte l'administrateur REM-CI pour le modifier.",
            ], 422);
        }

        // Propriétaire certifié : nom et numéro sont ceux de son dossier d'identité et de ses annonces ;
        // pour les changer, il passe par l'administrateur (évite de détourner une annonce validée).
        if ($user->role === 'proprietaire' && $user->owner_verification_status === 'verified') {
            $nameChanged = isset($data['name']) && trim($data['name']) !== trim((string) $user->name);
            $digits = fn ($v) => preg_replace('/[^\d+]/', '', (string) $v);
            $phoneChanged = isset($data['phone']) && $digits($data['phone']) !== $digits($user->phone);
            if ($nameChanged || $phoneChanged) {
                return response()->json([
                    'message' => 'Ton nom et ton numéro sont verrouillés car ton identité est certifiée. '
                        .'Pour les modifier, contacte l\'administrateur REM-CI au '.\App\Models\UserNotification::adminContacts().'.',
                    'code' => 'locked_identity',
                ], 422);
            }
        }

        // Nouvelle adresse e-mail : elle n'est plus considérée comme vérifiée.
        if (isset($data['email']) && $data['email'] !== $user->email) {
            $user->forceFill(['email_verified_at' => null]);
        }

        $user->update($data);

        return new UserResource($user->fresh());
    }

    /** POST /api/profile/avatar  (multipart : avatar) */
    public function avatar(Request $request)
    {
        $request->validate(['avatar' => ['required', 'image', 'max:5120']], [
            'avatar.required' => 'Choisis une photo.',
            'avatar.image' => 'Le fichier doit être une image.',
            'avatar.max' => 'La photo est trop lourde (5 Mo maximum).',
        ]);

        $user = $request->user();
        $path = $request->file('avatar')->store('avatars', 'public');

        // Supprime l'ancienne photo si c'était un fichier stocké chez nous
        if ($user->avatar && ! str_starts_with($user->avatar, 'http')) {
            Storage::disk('public')->delete($user->avatar);
        }

        $user->update(['avatar' => $path]);

        return new UserResource($user->fresh());
    }

    /** PUT /api/profile/password  { current_password, password, password_confirmation } */
    public function password(Request $request)
    {
        $request->validate([
            'current_password' => ['required', 'string'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
        ], [
            'current_password.required' => 'Saisis ton mot de passe actuel.',
            'password.min' => 'Le nouveau mot de passe doit contenir au moins 6 caractères.',
            'password.confirmed' => 'Les deux nouveaux mots de passe ne sont pas identiques.',
        ]);

        $user = $request->user();

        if (! Hash::check($request->current_password, $user->password)) {
            return response()->json(['message' => 'Le mot de passe actuel est incorrect.'], 422);
        }

        $user->forceFill(['password' => $request->password])->save();

        // Les autres appareils/sessions doivent se reconnecter ; la session courante reste ouverte.
        $current = $user->currentAccessToken();
        $user->tokens()->when($current?->id, fn ($q, $id) => $q->where('id', '!=', $id))->delete();

        return response()->json(['message' => 'Mot de passe modifié.']);
    }

    /**
     * DELETE /api/profile  { confirmation: "SUPPRIMER", password? }
     * Suppression définitive du compte (exigée par Google Play). Supprime le profil, les pièces
     * d'identité, la photo, les favoris, les notifications et — pour un propriétaire — ses
     * résidences et leurs photos. Refusée tant qu'une réservation est en cours ou à venir.
     */
    public function destroy(Request $request)
    {
        $user = $request->user();

        $request->validate([
            'confirmation' => ['required', 'string'],
            'password' => ['nullable', 'string'],
        ], ['confirmation.required' => 'Écris SUPPRIMER pour confirmer.']);

        if (strtoupper(trim((string) $request->confirmation)) !== 'SUPPRIMER') {
            return response()->json(['message' => 'Écris exactement le mot SUPPRIMER pour confirmer.'], 422);
        }

        // Compte créé avec Google : pas de mot de passe connu, le mot de confirmation suffit.
        if (empty($user->google_id) && ! Hash::check((string) $request->password, (string) $user->password)) {
            return response()->json(['message' => 'Le mot de passe est incorrect.'], 422);
        }

        if ($user->role === 'admin') {
            return response()->json(['message' => "Un compte administrateur ne peut pas être supprimé depuis l'application."], 403);
        }

        Booking::expireStale();

        $today = now()->startOfDay();
        $active = fn ($q) => $q->whereIn('status', ['pending', 'confirmed'])->whereNull('expired_at')->where('check_out', '>=', $today);

        $asTenant = Booking::where('user_id', $user->id)->where($active)->count();
        $asOwner = $user->role === 'proprietaire'
            ? Booking::whereHas('property', fn ($q) => $q->where('owner_id', $user->id))->where($active)->count()
            : 0;

        if ($asTenant + $asOwner > 0) {
            return response()->json([
                'message' => 'Tu as des réservations en cours ou à venir. Annule-les ou attends leur fin avant de supprimer ton compte.',
                'code' => 'active_bookings',
            ], 422);
        }

        $files = [$user->id_document_url, $user->id_document_verso_url];
        $publicFiles = [];
        if ($user->avatar && ! str_starts_with($user->avatar, 'http')) {
            $publicFiles[] = $user->avatar;
        }
        foreach ($user->properties()->with('photos')->get() as $property) {
            foreach ($property->photos as $photo) {
                $publicFiles[] = $photo->url;
            }
        }

        DB::transaction(function () use ($user) {
            $user->tokens()->delete();
            $user->delete(); // les clés étrangères en cascade suppriment résidences, réservations, favoris, notifications
        });

        foreach (array_filter($files) as $path) {
            foreach (['local', 'public'] as $disk) {
                Storage::disk($disk)->delete($path);
            }
        }
        foreach (array_filter($publicFiles) as $path) {
            if (! str_starts_with($path, 'http')) {
                Storage::disk('public')->delete($path);
            }
        }

        return response()->json(['message' => 'Ton compte et tes données ont été supprimés.']);
    }
}
