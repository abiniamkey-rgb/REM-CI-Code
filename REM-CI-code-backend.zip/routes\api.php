<?php

use App\Http\Controllers\Api\AdController;
use App\Http\Controllers\Api\AmenityController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\BookingController;
use App\Http\Controllers\Api\CityController;
use App\Http\Controllers\Api\FavoriteController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\OwnerBookingController;
use App\Http\Controllers\Api\PasswordResetController;
use App\Http\Controllers\Api\OwnerVerificationController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\PropertyController;
use App\Http\Controllers\Api\PropertyPhotoController;
use App\Http\Controllers\Api\TenantProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes — REM-CI
|--------------------------------------------------------------------------
| Toutes les routes sont préfixées par /api (fait automatiquement par Laravel).
| Utilisées par l'app Android (Kotlin/Retrofit) via https://tondomaine.com/api/...
|
| Pas de paiement en ligne : le locataire contacte le propriétaire directement
| (WhatsApp/appel) après avoir enregistré sa demande de réservation. L'activation
| d'une résidence est désormais 100% manuelle par l'administrateur (phpMyAdmin),
| après certification du propriétaire via /owner/verification.
*/

// --- Public ---
Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:30,1');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/auth/google', [AuthController::class, 'googleLogin'])->middleware('throttle:20,1');

// Mot de passe oublié : 1) demande du code par e-mail, 2) nouveau mot de passe + code
Route::post('/password/forgot', [PasswordResetController::class, 'forgot'])->middleware('throttle:6,1');
Route::post('/password/reset', [PasswordResetController::class, 'reset'])->middleware('throttle:10,1');

Route::get('/cities', [CityController::class, 'index']);
Route::get('/ads', [AdController::class, 'index']);
Route::get('/amenities', [AmenityController::class, 'index']);
Route::get('/properties', [PropertyController::class, 'index']);
Route::get('/properties/{property}', [PropertyController::class, 'show']);
Route::get('/properties/{property}/availability', [BookingController::class, 'availability']);

// --- Authentifié (Sanctum) ---
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);

    // Profil : infos, photo, mot de passe
    Route::patch('/profile', [ProfileController::class, 'update']);
    Route::post('/profile/avatar', [ProfileController::class, 'avatar']);
    Route::put('/profile/password', [ProfileController::class, 'password']);
    Route::delete('/profile', [ProfileController::class, 'destroy'])->middleware('throttle:5,1');

    // Notifications de l'app
    Route::get('/notifications', [NotificationController::class, 'index']);
    Route::post('/notifications/read-all', [NotificationController::class, 'readAll']);
    Route::post('/notifications/{id}/read', [NotificationController::class, 'read'])->whereNumber('id');

    Route::post('/properties', [PropertyController::class, 'store']);
    Route::patch('/properties/{property}', [PropertyController::class, 'update']);
    Route::patch('/properties/{property}/availability', [PropertyController::class, 'setAvailability']);
    Route::get('/my-properties', [PropertyController::class, 'myProperties']);
    Route::post('/properties/{property}/photos', [PropertyPhotoController::class, 'store']);

    // Dossier locataire (identité, âge ≥ 18, adresse, pièce d'identité) : exigé pour réserver
    Route::get('/tenant/profile', [TenantProfileController::class, 'show']);
    Route::post('/tenant/profile', [TenantProfileController::class, 'store'])->middleware('throttle:10,1');

    Route::get('/bookings', [BookingController::class, 'index']);
    Route::get('/bookings/{booking}', [BookingController::class, 'show']);
    Route::post('/bookings', [BookingController::class, 'store'])->middleware('throttle:20,1');
    Route::patch('/bookings/{booking}/cancel', [BookingController::class, 'cancel']);

    Route::get('/favorites', [FavoriteController::class, 'index']);
    Route::post('/favorites/{property}', [FavoriteController::class, 'toggle']);

    // Vérification d'identité du propriétaire — soumission du dossier (nom, téléphone,
    // adresse, photo pièce d'identité) ; certification manuelle par l'admin via phpMyAdmin.
    Route::get('/owner/bookings', [OwnerBookingController::class, 'index']);
    Route::patch('/owner/bookings/{booking}', [OwnerBookingController::class, 'update']);
    Route::get('/owner/verification', [OwnerVerificationController::class, 'show']);
    Route::post('/owner/verification', [OwnerVerificationController::class, 'store']);
});
