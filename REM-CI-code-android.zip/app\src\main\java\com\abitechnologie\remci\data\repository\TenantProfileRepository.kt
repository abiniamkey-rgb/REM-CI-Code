package com.abitechnologie.remci.data.repository

import com.abitechnologie.remci.data.ImageCompressor
import com.abitechnologie.remci.data.network.RetrofitClient
import com.abitechnologie.remci.data.network.UserDto
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

/**
 * Dossier du locataire, exigé avant la première demande de réservation : identité,
 * date de naissance (18 ans minimum), adresse, contact et pièce d'identité.
 */
class TenantProfileRepository {
    private val api = RetrofitClient.api

    /**
     * @param recto / @param verso : null quand la photo déjà envoyée est conservée.
     * @param birthDate au format "yyyy-MM-dd".
     */
    suspend fun submit(
        name: String,
        phone: String,
        address: String,
        birthDate: String,
        identityType: String,
        identityNumber: String,
        recto: File?,
        verso: File?
    ): ApiResult<UserDto> = try {
        fun text(value: String): RequestBody = value.toRequestBody("text/plain".toMediaTypeOrNull())
        suspend fun photoPart(key: String, file: File): MultipartBody.Part {
            val compressed = ImageCompressor.compressForUpload(file, maxSide = 1800, quality = 85)
            return MultipartBody.Part.createFormData(key, compressed.name, compressed.asRequestBody("image/jpeg".toMediaTypeOrNull()))
        }

        val response = api.submitTenantProfile(
            name = text(name),
            phone = text(phone),
            address = text(address),
            birthDate = text(birthDate),
            identityType = text(identityType),
            identityNumber = text(identityNumber),
            idDocumentRecto = recto?.let { photoPart("id_document_recto", it) },
            idDocumentVerso = verso?.let { photoPart("id_document_verso", it) }
        )
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible d'enregistrer ton dossier"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }
}
