<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('properties', function (Blueprint $table) {
            // Disponibilité déclarée par le propriétaire (icône bleue = disponible, rouge = occupée).
            $table->boolean('is_available')->default(true)->after('status');
            $table->timestamp('availability_updated_at')->nullable()->after('is_available');
        });
    }

    public function down(): void
    {
        Schema::table('properties', function (Blueprint $table) {
            $table->dropColumn(['is_available', 'availability_updated_at']);
        });
    }
};
