package com.abitechnologie.remci.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.abitechnologie.remci.data.network.BookingDto
import com.abitechnologie.remci.ui.components.LogoMark
import com.abitechnologie.remci.ui.components.ReceiptData
import com.abitechnologie.remci.ui.components.ReceiptPdf
import com.abitechnologie.remci.ui.components.formatFcfa
import com.abitechnologie.remci.ui.components.formatIsoDate
import com.abitechnologie.remci.ui.components.qrBitmap
import com.abitechnologie.remci.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Transforme une réservation confirmée en reçu. Les « fallback » servent quand le serveur ne
 * renvoie pas l'information (ex. côté propriétaire, l'hébergeur c'est lui-même).
 */
fun BookingDto.toReceiptData(
    tenantFallback: String? = null,
    ownerNameFallback: String? = null,
    ownerPhoneFallback: String? = null
): ReceiptData {
    val ref = reference ?: "REMCI-%04d".format(id)
    val issued = confirmedAt?.takeIf { it.length >= 10 }?.let { formatIsoDate(it, "d MMM yyyy") }
        ?: SimpleDateFormat("d MMM yyyy", Locale.FRANCE).format(Date())
    return ReceiptData(
        reference = ref,
        completed = status == "completed",
        residence = property?.title ?: "Résidence meublée",
        city = property?.city?.name ?: "",
        address = property?.address,
        checkIn = formatIsoDate(checkIn, "EEE d MMM yyyy"),
        checkOut = formatIsoDate(checkOut, "EEE d MMM yyyy"),
        nights = nights,
        guests = guests,
        pricePerNight = pricePerNight,
        total = totalPrice,
        tenantName = tenant?.name ?: tenantFallback ?: "Locataire",
        ownerName = property?.owner?.name ?: ownerNameFallback,
        ownerPhone = property?.owner?.phone ?: ownerPhoneFallback,
        qrContent = receiptUrl ?: ref,
        issuedOn = issued
    )
}

/** Reçu plein écran : ticket à l'écran + boutons Partager (PDF) et Imprimer. */
@Composable
fun ReceiptDialog(data: ReceiptData, onDismiss: () -> Unit) {
    val context = LocalContext.current

    fun withPdf(forPrint: Boolean, action: (java.io.File) -> Unit) {
        try {
            action(ReceiptPdf.create(context, data, forPrint))
        } catch (e: Exception) {
            Toast.makeText(context, "Impossible de préparer le PDF du reçu.", Toast.LENGTH_LONG).show()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(modifier = Modifier.fillMaxSize().background(Bg)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Mon reçu de réservation", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(1.dp, Divider, CircleShape)
                        .clickable(onClick = onDismiss),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Ink, modifier = Modifier.size(18.dp))
                }
            }

            Column(
                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
            ) {
                Ticket(data)
                Spacer(Modifier.height(12.dp))
                Text(
                    "Aucun paiement n'a été effectué via REM-CI : le montant est une estimation à régler directement avec le propriétaire.",
                    fontSize = 10.5.sp, color = Sub, lineHeight = 15.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                )
                Spacer(Modifier.height(16.dp))
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        withPdf(forPrint = false) { file ->
                            ReceiptPdf.share(context, file, "Mon reçu de réservation REM-CI ${data.reference} — ${data.residence}")
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Partager (PDF)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Button(
                    onClick = { withPdf(forPrint = true) { file -> ReceiptPdf.print(context, file, "Reçu REM-CI ${data.reference}") } },
                    colors = ButtonDefaults.buttonColors(containerColor = Orange),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Imprimer", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

private val Paper = Color(0xFFFFFFFF)
private val TicketInk = Color(0xFF111111)
private val TicketSub = Color(0xFF555555)

/** Ticket de caisse / de distributeur : bande étroite, police à chasse fixe, bords déchirés, tirets. */
@Composable
private fun Ticket(d: ReceiptData) {
    val qr = remember(d.qrContent) { qrBitmap(d.qrContent, 600).asImageBitmap() }
    val mono = FontFamily.Monospace

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.widthIn(max = 330.dp).fillMaxWidth()) {
            TornEdge(top = true)
            Column(
                modifier = Modifier.fillMaxWidth().background(Paper).padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LogoMark(size = 72)
                Text("REM-CI", fontFamily = mono, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = TicketInk)
                Text("Résidences meublées", fontFamily = mono, fontSize = 11.sp, color = TicketSub)
                Text("Côte d'Ivoire", fontFamily = mono, fontSize = 11.sp, color = TicketSub)
                TicketDash()

                Text("REÇU DE RÉSERVATION", fontFamily = mono, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = TicketInk, textAlign = TextAlign.Center)
                Text(
                    if (d.completed) "** SÉJOUR TERMINÉ **" else "** CONFIRMÉE **",
                    fontFamily = mono, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TicketInk,
                    modifier = Modifier.padding(top = 5.dp)
                )
                TicketDash()

                TicketRow("N°", d.reference, bold = true)
                TicketRow("ÉMIS LE", d.issuedOn)
                TicketDash()

                Text(
                    d.residence.uppercase(), fontFamily = mono, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp,
                    color = TicketInk, textAlign = TextAlign.Center, lineHeight = 17.sp
                )
                val place = listOfNotNull(d.city.takeIf { it.isNotBlank() }, d.address?.takeIf { it.isNotBlank() }).joinToString(", ")
                if (place.isNotBlank()) {
                    Text(
                        place, fontFamily = mono, fontSize = 11.sp, color = TicketSub, textAlign = TextAlign.Center,
                        lineHeight = 15.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                }
                TicketDash()

                TicketRow("ARRIVÉE", d.checkIn)
                TicketRow("DÉPART", d.checkOut)
                TicketRow("DURÉE", "${d.nights} nuit(s)")
                TicketRow("VOYAGEURS", "${d.guests}")
                TicketDash()

                TicketRow("LOCATAIRE", d.tenantName)
                TicketRow("HÉBERGEUR", d.ownerName ?: "—")
                d.ownerPhone?.takeIf { it.isNotBlank() }?.let { TicketRow("TÉL. HÉBERGEUR", it) }
                TicketDash()

                TicketRow("PRIX / NUIT", "${formatFcfa(d.pricePerNight)} FCFA")
                TicketRow("NUITS", "${d.nights}")
                Spacer(Modifier.height(4.dp))
                TicketRow("TOTAL INDICATIF", "${formatFcfa(d.total)} FCFA", bold = true, size = 14)
                TicketDash()

                Spacer(Modifier.height(4.dp))
                Image(bitmap = qr, contentDescription = "Code QR du reçu", modifier = Modifier.size(160.dp))
                Spacer(Modifier.height(6.dp))
                Text("SCANNEZ POUR VÉRIFIER", fontFamily = mono, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TicketSub)
                Text(d.reference, fontFamily = mono, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = TicketInk, modifier = Modifier.padding(top = 2.dp))
                TicketDash()

                Text(
                    "Aucun paiement n'a été effectué via REM-CI. Le montant est indicatif et se règle directement avec le propriétaire.",
                    fontFamily = mono, fontSize = 9.5.sp, color = TicketSub, textAlign = TextAlign.Center, lineHeight = 13.sp
                )
                Text(
                    "MERCI DE VOTRE CONFIANCE !", fontFamily = mono, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                    color = TicketInk, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp)
                )
                Text("REM-CI · ABITECHNOLOGIE", fontFamily = mono, fontSize = 9.5.sp, color = TicketSub, modifier = Modifier.padding(top = 6.dp))
                Text("abitechnologie@outlook.fr", fontFamily = mono, fontSize = 9.5.sp, color = TicketSub)
                Spacer(Modifier.height(18.dp))
            }
            TornEdge(top = false)
        }
    }
}

/** Ligne « LIBELLÉ ........ valeur » d'un ticket (valeur alignée à droite, passe à la ligne si longue). */
@Composable
private fun TicketRow(label: String, value: String, bold: Boolean = false, size: Int = 12) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = (size - 1).sp, color = TicketSub)
        Spacer(Modifier.width(10.dp))
        Text(
            value, fontFamily = FontFamily.Monospace, fontSize = size.sp,
            fontWeight = if (bold) FontWeight.ExtraBold else FontWeight.Medium,
            color = TicketInk, textAlign = TextAlign.End, modifier = Modifier.weight(1f)
        )
    }
}

/** Séparateur en tirets, comme sur un ticket imprimé. */
@Composable
private fun TicketDash() {
    Canvas(modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp).height(1.dp)) {
        drawLine(
            color = Color(0xFF8A8A8A),
            start = Offset(0f, 0f), end = Offset(size.width, 0f),
            strokeWidth = 1.2.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 5.dp.toPx()), 0f)
        )
    }
}

/** Bord déchiré en dents de scie, en haut ou en bas du ticket. */
@Composable
private fun TornEdge(top: Boolean) {
    Canvas(modifier = Modifier.fillMaxWidth().height(9.dp)) {
        val step = 12.dp.toPx()
        val h = size.height
        val path = Path()
        if (top) {
            path.moveTo(0f, h)
            var x = 0f
            while (x < size.width) {
                path.lineTo(x + step / 2f, 0f)
                path.lineTo(x + step, h)
                x += step
            }
            path.lineTo(size.width, h)
        } else {
            path.moveTo(0f, 0f)
            var x = 0f
            while (x < size.width) {
                path.lineTo(x + step / 2f, h)
                path.lineTo(x + step, 0f)
                x += step
            }
            path.lineTo(size.width, 0f)
        }
        path.close()
        drawPath(path, Paper)
    }
}
