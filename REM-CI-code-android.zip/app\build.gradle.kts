import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---------------------------------------------------------------------------------------
// Adresses du serveur.
//  - debug   : ton tunnel ngrok actuel (tests sur téléphone pendant le développement)
//  - release : le vrai serveur, une fois le domaine acheté (APK/AAB envoyé aux testeurs et au Play Store)
// Après l'achat du domaine, remplace seulement ces deux lignes.
// ---------------------------------------------------------------------------------------
val API_URL_DEBUG = "https://emission-chewer-follicle.ngrok-free.dev/api/"
val SITE_URL_DEBUG = "https://emission-chewer-follicle.ngrok-free.dev"
val API_URL_RELEASE = "https://api.remci.app/api/"
val SITE_URL_RELEASE = "https://remci.app"

// Clé de signature de l'app (fichier keystore.properties à la racine du projet, jamais partagé).
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.abitechnologie.remci"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.abitechnologie.remci"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        if (keystoreProps.containsKey("storeFile")) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        debug {
            buildConfigField("String", "API_BASE_URL", "\"$API_URL_DEBUG\"")
            buildConfigField("String", "SITE_URL", "\"$SITE_URL_DEBUG\"")
        }
        release {
            buildConfigField("String", "API_BASE_URL", "\"$API_URL_RELEASE\"")
            buildConfigField("String", "SITE_URL", "\"$SITE_URL_RELEASE\"")
            // Gardé à false pour la première version (aucun risque de casser les échanges avec le serveur).
            // Pourra passer à true plus tard, après test complet d'un APK release.
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (keystoreProps.containsKey("storeFile")) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.material3:material3")

    implementation("androidx.navigation:navigation-compose:2.7.7")

    // Réseau — connexion au backend Laravel
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Stockage du token de connexion
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // ViewModel + coroutines pour l'état de l'app
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.4")

    // Lecture de texte sur la photo de la pièce d'identité — 100% sur l'appareil,
    // gratuit, aucune clé API ni appel réseau (pas de Google Cloud Vision payant).
    implementation("com.google.mlkit:text-recognition:16.0.1")

    // Scanner de document de Google (gratuit, sur l'appareil) : détecte les bords de la
    // pièce d'identité, la recadre et la redresse automatiquement.
    implementation("com.google.android.gms:play-services-mlkit-document-scanner:16.0.0-beta1")

    // Position GPS au moment des photos de la résidence — service Google gratuit.
    implementation("com.google.android.gms:play-services-location:21.3.0")

    // Code QR du reçu de réservation (génération 100 % locale, sans réseau)
    implementation("com.google.zxing:core:3.5.3")

    // Chargement des images (photos résidence, pièce d'identité, aperçus) — AsyncImage
    implementation("io.coil-kt:coil-compose:2.6.0")

    // Connexion avec Google (Credential Manager + bouton « Se connecter avec Google »)
    implementation("androidx.credentials:credentials:1.2.2")
    implementation("androidx.credentials:credentials-play-services-auth:1.2.2")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.06.00"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
