package com.abitechnologie.remci.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.FileProvider
import com.abitechnologie.remci.R
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/** Tout ce qu'affiche le reçu de réservation (écran, PDF et impression). */
data class ReceiptData(
    val reference: String,
    val completed: Boolean,
    val residence: String,
    val city: String,
    val address: String?,
    val checkIn: String,
    val checkOut: String,
    val nights: Int,
    val guests: Int,
    val pricePerNight: Int,
    val total: Int,
    val tenantName: String,
    val ownerName: String?,
    val ownerPhone: String?,
    /** Contenu du code QR : lien de vérification publique du reçu. */
    val qrContent: String,
    val issuedOn: String
)

/**
 * Reçu de réservation au format « ticket de caisse / de distributeur » : bande étroite de
 * 80 mm (largeur d'un rouleau thermique), police à chasse fixe, tirets, code QR centré.
 * - [create] sans option : PDF à la taille exacte du ticket (partage, enregistrement).
 * - [create] avec forPrint : le même ticket, à sa taille réelle, centré sur une feuille A4.
 */
object ReceiptPdf {
    private const val TICKET_W = 226f // 80 mm en points PDF (1 pt = 1/72 pouce)
    private const val MARGIN = 12f
    private const val A4_W = 595
    private const val A4_H = 842

    private val INK = 0xFF111111.toInt()
    private val SUB = 0xFF555555.toInt()
    private val GREY = 0xFF8A8A8A.toInt()

    fun create(context: Context, d: ReceiptData, forPrint: Boolean = false): File {
        val ticket = TicketPainter(context, d)
        val ticketH = ticket.render(null, 0f, 0f)

        val doc = PdfDocument()
        if (forPrint) {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(A4_W, A4_H, 1).create())
            val canvas = page.canvas
            canvas.drawColor(0xFFFFFFFF.toInt())
            val ox = (A4_W - TICKET_W) / 2f
            val oy = 54f
            val cut = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; color = GREY; strokeWidth = 0.8f
                pathEffect = DashPathEffect(floatArrayOf(4f, 4f), 0f)
            }
            canvas.drawRect(ox - 6f, oy - 6f, ox + TICKET_W + 6f, oy + ticketH + 6f, cut)
            val hint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 8.5f; color = SUB }
            val msg = "Découper le long du pointillé"
            canvas.drawText(msg, (A4_W - hint.measureText(msg)) / 2f, oy - 14f, hint)
            ticket.render(canvas, ox, oy)
            doc.finishPage(page)
        } else {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(TICKET_W.toInt(), Math.ceil(ticketH.toDouble()).toInt(), 1).create())
            page.canvas.drawColor(0xFFFFFFFF.toInt())
            ticket.render(page.canvas, 0f, 0f)
            doc.finishPage(page)
        }

        val dir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val file = File(dir, if (forPrint) "Recu-${d.reference}-impression.pdf" else "Recu-${d.reference}.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }

    /** Dessine le ticket (ou ne fait que mesurer sa hauteur quand [canvas] est null). */
    private class TicketPainter(private val context: Context, private val d: ReceiptData) {
        private val cw = TICKET_W - 2 * MARGIN
        private val qr: Bitmap by lazy { qrBitmap(d.qrContent, 600) }
        private val logo: Bitmap? by lazy { BitmapFactory.decodeResource(context.resources, R.drawable.logo) }

        private fun paint(size: Float, color: Int = INK, bold: Boolean = false) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

        private fun layout(text: String, p: TextPaint, align: Layout.Alignment, maxLines: Int): StaticLayout =
            StaticLayout.Builder.obtain(text, 0, text.length, p, cw.toInt())
                .setAlignment(align)
                .setMaxLines(maxLines)
                .setEllipsize(TextUtils.TruncateAt.END)
                .build()

        fun render(canvas: Canvas?, ox: Float, oy: Float): Float {
            var y = 16f
            val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; color = GREY; strokeWidth = 0.9f
                pathEffect = DashPathEffect(floatArrayOf(3f, 3f), 0f)
            }

            fun draw(l: StaticLayout, atY: Float) {
                canvas ?: return
                canvas.save()
                canvas.translate(ox + MARGIN, oy + atY)
                l.draw(canvas)
                canvas.restore()
            }

            fun centered(text: String, p: TextPaint, gap: Float = 0f, maxLines: Int = 3) {
                val l = layout(text, p, Layout.Alignment.ALIGN_CENTER, maxLines)
                draw(l, y)
                y += l.height + gap
            }

            fun dash() {
                y += 7f
                canvas?.drawLine(ox + MARGIN, oy + y, ox + TICKET_W - MARGIN, oy + y, dashPaint)
                y += 8f
            }

            // « LIBELLÉ ........ valeur » : sur une ligne si possible, sinon valeur en dessous
            fun row(label: String, value: String, bold: Boolean = false, size: Float = 8.8f) {
                val lp = paint(size, SUB)
                val vp = paint(size, INK, bold)
                val left = layout(label, lp, Layout.Alignment.ALIGN_NORMAL, 1)
                val right = layout(value, vp, Layout.Alignment.ALIGN_OPPOSITE, 3)
                if (right.lineCount == 1 && lp.measureText(label) + vp.measureText(value) + 6f <= cw) {
                    draw(left, y)
                    draw(right, y)
                    y += maxOf(left.height, right.height) + 3f
                } else {
                    draw(left, y)
                    y += left.height
                    draw(right, y)
                    y += right.height + 3f
                }
            }

            // ----- En-tête de marque -----
            logo?.let { bmp ->
                val size = 58f
                canvas?.drawBitmap(
                    bmp, null,
                    RectF(ox + (TICKET_W - size) / 2f, oy + y, ox + (TICKET_W + size) / 2f, oy + y + size),
                    Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
                )
                y += size + 4f
            }
            centered("REM-CI", paint(15f, INK, true), 2f, 1)
            centered("Résidences meublées", paint(8f, SUB), 0f, 1)
            centered("Côte d'Ivoire", paint(8f, SUB), 0f, 1)
            dash()

            // ----- Titre -----
            centered("REÇU DE RÉSERVATION", paint(10.5f, INK, true), 4f, 2)
            centered(if (d.completed) "** SÉJOUR TERMINÉ **" else "** CONFIRMÉE **", paint(9.5f, INK, true), 0f, 1)
            dash()

            row("N°", d.reference, bold = true)
            row("ÉMIS LE", d.issuedOn)
            dash()

            // ----- Résidence -----
            centered(d.residence.uppercase(), paint(9.8f, INK, true), 3f, 3)
            val place = listOfNotNull(d.city.takeIf { it.isNotBlank() }, d.address?.takeIf { it.isNotBlank() }).joinToString(", ")
            if (place.isNotBlank()) centered(place, paint(8.2f, SUB), 0f, 3)
            dash()

            // ----- Séjour -----
            row("ARRIVÉE", d.checkIn)
            row("DÉPART", d.checkOut)
            row("DURÉE", "${d.nights} nuit(s)")
            row("VOYAGEURS", "${d.guests}")
            dash()

            // ----- Personnes -----
            row("LOCATAIRE", d.tenantName)
            row("HÉBERGEUR", d.ownerName ?: "—")
            d.ownerPhone?.takeIf { it.isNotBlank() }?.let { row("TÉL. HÉBERGEUR", it) }
            dash()

            // ----- Montant -----
            row("PRIX / NUIT", "${formatFcfa(d.pricePerNight)} FCFA")
            row("NUITS", "${d.nights}")
            y += 3f
            row("TOTAL INDICATIF", "${formatFcfa(d.total)} FCFA", bold = true, size = 10f)
            dash()

            // ----- Code QR -----
            val qrSize = 112f
            y += 2f
            canvas?.drawBitmap(
                qr, null,
                RectF(ox + (TICKET_W - qrSize) / 2f, oy + y, ox + (TICKET_W + qrSize) / 2f, oy + y + qrSize),
                Paint(Paint.FILTER_BITMAP_FLAG)
            )
            y += qrSize + 6f
            centered("SCANNEZ POUR VÉRIFIER", paint(8f, SUB, true), 2f, 1)
            centered(d.reference, paint(9f, INK, true), 0f, 1)
            dash()

            // ----- Pied de ticket -----
            centered("Aucun paiement n'a été effectué via REM-CI. Le montant est indicatif et se règle directement avec le propriétaire.", paint(7.4f, SUB), 6f, 6)
            centered("MERCI DE VOTRE CONFIANCE !", paint(8.6f, INK, true), 4f, 2)
            centered("REM-CI · ABITECHNOLOGIE", paint(7.6f, SUB), 0f, 1)
            centered("abitechnologie@outlook.fr", paint(7.6f, SUB), 0f, 1)
            y += 18f
            return y
        }
    }

    // ---------- Partage et impression ----------

    private fun Context.activityOrSelf(): Context = when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.activityOrSelf()
        else -> this
    }

    /** Ouvre la feuille de partage (WhatsApp, e-mail, Drive…) avec le PDF du reçu. */
    fun share(context: Context, file: File, message: String) {
        val host = context.activityOrSelf()
        val uri = FileProvider.getUriForFile(host, "${host.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, message)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, "Envoyer le reçu")
        if (host !is Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        host.startActivity(chooser)
    }

    /** Impression (ou « Enregistrer au format PDF ») via le service d'impression d'Android. */
    fun print(context: Context, file: File, jobName: String) {
        val host = context.activityOrSelf()
        val manager = host.getSystemService(Context.PRINT_SERVICE) as PrintManager
        manager.print(jobName, object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(file.name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    FileInputStream(file).use { input ->
                        FileOutputStream(destination!!.fileDescriptor).use { output -> input.copyTo(output) }
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                }
            }
        }, null)
    }
}
