<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdResource;
use App\Models\Ad;

class AdController extends Controller
{
    /** GET /api/ads */
    public function index()
    {
        return AdResource::collection(Ad::active()->limit(Ad::MAX_LIVE)->get());
    }
}
