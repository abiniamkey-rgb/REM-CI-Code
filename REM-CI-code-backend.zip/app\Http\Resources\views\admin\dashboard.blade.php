@extends('admin.layout')
@section('title', 'Tableau de bord')
@section('content')
  <h1>Tableau de bord</h1>
  <div class="sub">Ce qui demande ton attention aujourd'hui.</div>

  <div class="grid stats">
    <a href="{{ route('admin.owners.index', ['statut' => 'pending']) }}" class="card stat {{ $stats['owners_pending'] ? 'warn' : '' }}" style="color:inherit;text-decoration:none">
      <div class="n">{{ $stats['owners_pending'] }}</div><div class="l">Dossiers propriétaires à examiner</div>
    </a>
    <a href="{{ route('admin.properties.index', ['statut' => 'pending']) }}" class="card stat {{ $stats['properties_pending'] ? 'warn' : '' }}" style="color:inherit;text-decoration:none">
      <div class="n">{{ $stats['properties_pending'] }}</div><div class="l">Résidences à valider</div>
    </a>
    <div class="card stat"><div class="n">{{ $stats['properties_active'] }}</div><div class="l">Résidences publiées</div></div>
    <div class="card stat"><div class="n">{{ $stats['owners_verified'] }}</div><div class="l">Propriétaires certifiés</div></div>
    <div class="card stat"><div class="n">{{ $stats['tenants'] }}</div><div class="l">Locataires inscrits</div></div>
    <a href="{{ route('admin.bookings.index', ['statut' => 'pending']) }}" class="card stat" style="color:inherit;text-decoration:none">
      <div class="n">{{ $stats['bookings_pending'] }}<small class="sub" style="font-size:14px"> / {{ $stats['bookings_total'] }}</small></div><div class="l">Demandes de réservation en cours / total</div>
    </a>
  </div>

  <div class="grid two">
    <div class="card">
      <h2>Dossiers en attente</h2>
      @forelse($pendingOwners as $o)
        <div style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid #F3EFE3">
          <div><a href="{{ route('admin.owners.show', $o) }}"><strong>{{ $o->name }}</strong></a><div class="sub">{{ $o->phone }}</div></div>
          <div class="sub">{{ $o->updated_at?->diffForHumans() }}</div>
        </div>
      @empty
        <div class="empty">Aucun dossier en attente 🎉</div>
      @endforelse
    </div>
    <div class="card">
      <h2>Résidences en attente</h2>
      @forelse($pendingProperties as $p)
        <div style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid #F3EFE3">
          <div><a href="{{ route('admin.properties.show', $p) }}"><strong>{{ $p->title }}</strong></a>
            <div class="sub">{{ $p->city?->name }} · {{ $p->owner?->name }}</div></div>
          <div class="sub">{{ $p->created_at?->diffForHumans() }}</div>
        </div>
      @empty
        <div class="empty">Aucune résidence en attente 🎉</div>
      @endforelse
    </div>
  </div>
@endsection
