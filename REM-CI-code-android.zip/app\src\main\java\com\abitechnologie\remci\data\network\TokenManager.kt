package com.abitechnologie.remci.data.network

import android.content.Context
import android.content.SharedPreferences

/**
 * Stocke le token Sanctum reçu après connexion.
 * Pour la production, remplacer par EncryptedSharedPreferences (androidx.security:security-crypto).
 */
object TokenManager {
    private const val PREFS = "remci_prefs"
    private const val KEY_TOKEN = "auth_token"
    private const val KEY_ROLE = "user_role"
    private const val KEY_USER = "cached_user"
    private const val KEY_WELCOMED = "has_account_on_device"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    // Une connexion ou une inscription réussie a eu lieu sur ce téléphone : les prochaines
    // fois, l'écran de connexion dit « Bon retour » au lieu de « Bienvenue ».
    fun saveToken(token: String) = prefs.edit().putString(KEY_TOKEN, token).putBoolean(KEY_WELCOMED, true).apply()

    fun hasAccountOnDevice(): Boolean = ::prefs.isInitialized && prefs.getBoolean(KEY_WELCOMED, false)

    fun getToken(): String? = if (::prefs.isInitialized) prefs.getString(KEY_TOKEN, null) else null

    fun saveRole(role: String) = prefs.edit().putString(KEY_ROLE, role).apply()

    fun getRole(): String = prefs.getString(KEY_ROLE, "locataire") ?: "locataire"

    /**
     * Copie du profil (sans mot de passe) : permet de rouvrir l'application SANS réseau
     * en restant connecté, au lieu d'être déconnecté parce que le serveur est injoignable.
     */
    fun saveUser(user: UserDto) {
        if (!::prefs.isInitialized) return
        try { prefs.edit().putString(KEY_USER, com.google.gson.Gson().toJson(user)).apply() } catch (_: Exception) { }
    }

    fun getCachedUser(): UserDto? {
        if (!::prefs.isInitialized) return null
        return try {
            prefs.getString(KEY_USER, null)?.let { com.google.gson.Gson().fromJson(it, UserDto::class.java) }
        } catch (_: Exception) {
            null
        }
    }

    // La déconnexion efface la session mais garde le souvenir d'une première connexion.
    fun clear() {
        val welcomed = hasAccountOnDevice()
        prefs.edit().clear().apply()
        if (welcomed) prefs.edit().putBoolean(KEY_WELCOMED, true).apply()
    }

    fun isLoggedIn(): Boolean = !getToken().isNullOrBlank()
}
