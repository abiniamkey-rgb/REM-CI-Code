<?php

namespace Database\Seeders;

use App\Models\Ad;
use App\Models\Property;
use Illuminate\Database\Seeder;

class AdSeeder extends Seeder
{
    public function run(): void
    {
        $ads = [
            ['title' => 'Week-end à Assinie', 'subtitle' => 'Villas piscine dès 65 000 FCFA/nuit', 'color_a' => '#0091D8', 'color_b' => '#0A6C3B', 'property' => 'Villa Piscine Assinie'],
            ['title' => '-20% ce mois-ci', 'subtitle' => 'Sur les résidences du Plateau, Abidjan', 'color_a' => '#F77F00', 'color_b' => '#D4AF37', 'property' => 'Studio Standing Plateau'],
            ['title' => 'Nouveauté Yamoussoukro', 'subtitle' => 'Suites vue lac, réservez maintenant', 'color_a' => '#0A6C3B', 'color_b' => '#063D22', 'property' => 'Suite Vue Lac Yamoussoukro'],
        ];

        foreach ($ads as $i => $a) {
            $property = Property::where('title', $a['property'])->first();

            Ad::updateOrCreate(
                ['title' => $a['title']],
                [
                    'subtitle' => $a['subtitle'],
                    'color_a' => $a['color_a'],
                    'color_b' => $a['color_b'],
                    'property_id' => $property?->id,
                    'position' => $i,
                    'active' => true,
                ]
            );
        }
    }
}
