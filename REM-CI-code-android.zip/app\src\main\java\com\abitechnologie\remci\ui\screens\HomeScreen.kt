package com.abitechnologie.remci.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.abitechnologie.remci.data.*
import com.abitechnologie.remci.data.network.toUiModel
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.PropertyRepository
import com.abitechnologie.remci.ui.components.Badge
import com.abitechnologie.remci.ui.components.PropertyCard
import com.abitechnologie.remci.ui.components.clickableNoRipple
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    favorites: Set<Int>,
    filterCity: String?,
    onFilterCity: (String?) -> Unit,
    onToggleFavorite: (Int) -> Unit,
    onOpenProperty: (Property) -> Unit,
    userName: String = "",
    onOpenSearch: () -> Unit = {},
    unreadCount: Int = 0,
    onOpenNotifications: () -> Unit = {}
) {
    val repository = remember { PropertyRepository() }
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var cities by remember { mutableStateOf<List<City>>(emptyList()) }
    var ads by remember { mutableStateOf<List<Ad>>(emptyList()) }
    var properties by remember { mutableStateOf<List<Property>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var offline by remember { mutableStateOf(false) }
    var priceSort by remember { mutableStateOf<PriceSort>(PriceSort.NONE) }
    var typeFilter by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableStateOf(0) }

    LaunchedEffect(filterCity, reload) {
        loading = true
        val citiesResult = repository.getCities()
        val adsResult = repository.getAds()
        val propsResult = repository.getProperties(city = filterCity?.let { cityNameToSlug(it) })

        if (citiesResult is ApiResult.Success) cities = citiesResult.data.map { it.toUiModel() }
        if (adsResult is ApiResult.Success) ads = adsResult.data.map { it.toUiModel() }

        when (propsResult) {
            is ApiResult.Success -> {
                properties = propsResult.data.map { it.toUiModel() }
                offline = false
            }
            is ApiResult.Error -> {
                // Serveur injoignable : on n'affiche JAMAIS de fausses résidences (un locataire
                // pourrait réserver une vraie résidence au même numéro) — message + « Réessayer ».
                properties = emptyList()
                offline = true
            }
        }
        loading = false
    }

    val list = properties
        .let { l ->
            val q = query.trim().lowercase()
            if (q.isBlank()) l else l.filter {
                it.title.lowercase().contains(q) || it.city.lowercase().contains(q) ||
                    (it.address ?: "").lowercase().contains(q)
            }
        }
        .let { l -> if (typeFilter == null) l else l.filter { it.beds >= (typeFilter?.toIntOrNull() ?: 0) } }
        .let { l ->
            when (priceSort) {
                PriceSort.ASC -> l.sortedBy { it.price }
                PriceSort.DESC -> l.sortedByDescending { it.price }
                PriceSort.NONE -> l
            }
        }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .verticalScrollFix()
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp, 10.dp, 16.dp, 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                val hello = when {
                    hour < 12 -> "Bonjour"
                    hour < 18 -> "Bon après-midi"
                    else -> "Bonsoir"
                }
                val first = userName.trim().substringBefore(" ")
                Text(if (first.isBlank()) "$hello 👋" else "$hello, $first 👋", fontSize = 12.sp, color = Sub)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Orange, modifier = Modifier.size(14.dp))
                    Text(" ${filterCity ?: "Côte d'Ivoire"}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box {
                    com.abitechnologie.remci.ui.components.CircleIconButton(Icons.Default.Notifications, onClick = onOpenNotifications)
                    if (unreadCount > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(10.dp)
                                .background(Orange, androidx.compose.foundation.shape.CircleShape)
                                .border(1.5.dp, Bg, androidx.compose.foundation.shape.CircleShape)
                        )
                    }
                }
                com.abitechnologie.remci.ui.components.CircleIconButton(Icons.Default.Tune, onClick = onOpenSearch)
            }
        }

        // Barre de recherche — filtre par titre, ville ou quartier
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .background(CardBg, RoundedCornerShape(16.dp))
                .border(1.dp, Divider, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = Sub, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            androidx.compose.foundation.text.BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = Ink),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    if (query.isEmpty()) Text("Rechercher une résidence, un quartier...", fontSize = 13.sp, color = Sub)
                    inner()
                }
            )
            if (query.isNotEmpty()) {
                Icon(
                    Icons.Default.Close, contentDescription = "Effacer", tint = Sub,
                    modifier = Modifier.size(18.dp).clickableNoRipple { query = "" }
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                label = when (priceSort) {
                    PriceSort.ASC -> "Prix ↑"
                    PriceSort.DESC -> "Prix ↓"
                    PriceSort.NONE -> "Prix"
                },
                active = priceSort != PriceSort.NONE,
                onClick = {
                    priceSort = when (priceSort) {
                        PriceSort.NONE -> PriceSort.ASC
                        PriceSort.ASC -> PriceSort.DESC
                        PriceSort.DESC -> PriceSort.NONE
                    }
                }
            )
            FilterChip(
                label = if (typeFilter == null) "Type" else "$typeFilter+ pièce(s)",
                active = typeFilter != null,
                onClick = { typeFilter = if (typeFilter == null) "2" else if (typeFilter == "2") "3" else null }
            )
        }

        Spacer(Modifier.height(18.dp))
        if (offline) {
            Row(
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .background(Gold.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                Text(
                    "Impossible de joindre le serveur. Vérifie ta connexion internet.",
                    fontSize = 11.sp, color = OrangeDeep, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f).align(Alignment.CenterVertically)
                )
                Text(
                    "Réessayer", fontSize = 11.5.sp, color = Green, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(start = 8.dp).clickableNoRipple { reload++ }.align(Alignment.CenterVertically)
                )
            }
            Spacer(Modifier.height(10.dp))
        }
        AdCarousel(ads) { ad ->
            // Touche sur une publicité liée à une résidence : on l'ouvre (un visiteur sans compte
            // verra la fenêtre « Crée ton compte », comme pour une résidence de la liste).
            val id = ad.propertyId ?: return@AdCarousel
            val known = properties.firstOrNull { it.id == id }
            if (known != null) onOpenProperty(known)
            else scope.launch {
                val r = repository.getProperty(id)
                if (r is ApiResult.Success) onOpenProperty(r.data.toUiModel())
            }
        }

        val activeCities = cities.filter { it.count > 0 || it.name == filterCity }.sortedByDescending { it.count }
        if (activeCities.isNotEmpty()) {
        Spacer(Modifier.height(18.dp))
        Text("Villes populaires", fontSize = 14.5.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(10.dp))
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 16.dp)
        ) {
            items(activeCities) { c ->
                val selected = filterCity == c.name
                Column(
                    modifier = Modifier
                        .width(92.dp)
                        .background(CardBg, RoundedCornerShape(14.dp))
                        .border(if (selected) 2.dp else 1.dp, if (selected) Orange else Divider, RoundedCornerShape(14.dp))
                        .clickableNoRipple { onFilterCity(if (selected) null else c.name) }
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(modifier = Modifier.size(26.dp).background(c.tone, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Apartment, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                    }
                    Text(c.name, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("${c.count} logement(s)", fontSize = 9.5.sp, color = Sub)
                }
            }
        }
        }

        Spacer(Modifier.height(18.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                if (filterCity != null) "Résidences à $filterCity" else "Résidences populaires",
                fontSize = 14.5.sp, fontWeight = FontWeight.Bold, color = Ink
            )
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickableNoRipple { onOpenSearch() }) {
                Text("Voir tout", fontSize = 11.5.sp, color = Blue)
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Blue, modifier = Modifier.size(14.dp))
            }
        }
        Spacer(Modifier.height(10.dp))

        if (list.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 30.dp, vertical = 36.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.size(64.dp).background(Green.copy(alpha = 0.08f), RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Apartment, contentDescription = null, tint = Green, modifier = Modifier.size(30.dp)) }
                Spacer(Modifier.height(14.dp))
                Text(
                    when {
                        offline -> "Impossible de charger les résidences"
                        query.isNotBlank() -> "Aucun résultat pour « $query »"
                        else -> "Aucune résidence disponible pour le moment"
                    },
                    fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Ink
                )
                Text(
                    if (offline) "Touche « Réessayer » en haut de la liste quand ta connexion est rétablie."
                    else "Les nouvelles résidences sont publiées après vérification par l'équipe REM-CI. Reviens très bientôt !",
                    fontSize = 11.5.sp, color = Sub, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        } else {
            // Simple two-column grid (non-lazy, list is small)
            list.chunked(2).forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { p ->
                        PropertyCard(
                            property = p,
                            isFavorite = favorites.contains(p.id),
                            onOpen = onOpenProperty,
                            onToggleFavorite = onToggleFavorite,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        Spacer(Modifier.height(90.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AdCarousel(ads: List<Ad>, onAdClick: (Ad) -> Unit) {
    if (ads.isEmpty()) return
    val pagerState = rememberPagerState(pageCount = { ads.size })

    LaunchedEffect(pagerState, ads) {
        if (ads.size < 2) return@LaunchedEffect
        while (true) {
            delay(4500)
            val next = (pagerState.currentPage + 1) % ads.size
            pagerState.animateScrollToPage(next)
        }
    }

    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        HorizontalPager(state = pagerState, pageSpacing = 12.dp) { page ->
            val ad = ads[page]
            val shape = RoundedCornerShape(20.dp)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(2f)
                    .shadow(6.dp, shape, clip = false)
                    .clip(shape)
                    .background(Brush.linearGradient(listOf(ad.colorA, ad.colorB)))
                    .then(if (ad.propertyId != null) Modifier.clickableNoRipple { onAdClick(ad) } else Modifier)
            ) {
                if (ad.imageUrl != null) {
                    AsyncImage(
                        model = ad.imageUrl,
                        contentDescription = ad.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                // Voile sombre en bas pour la lisibilité du texte
                if (ad.imageUrl != null && (ad.title.isNotBlank() || ad.sub.isNotBlank())) {
                    Box(
                        modifier = Modifier.fillMaxSize().background(
                            Brush.verticalGradient(
                                0.35f to Color.Transparent,
                                1f to Color.Black.copy(alpha = 0.72f)
                            )
                        )
                    )
                }
                // Étiquette promo (haut gauche)
                if (!ad.badge.isNullOrBlank()) {
                    Text(
                        ad.badge,
                        fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Color.White,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                            .background(Orange, RoundedCornerShape(50))
                            .padding(horizontal = 11.dp, vertical = 4.dp)
                    )
                }
                // Mention « Pub » (haut droite)
                Text(
                    "PUB",
                    fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.9f), letterSpacing = 1.sp,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .background(Color.Black.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
                // Textes (bas gauche) + flèche si la bannière ouvre une résidence
                Row(
                    verticalAlignment = Alignment.Bottom,
                    modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(14.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        if (ad.title.isNotBlank()) {
                            Text(
                                ad.title, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.White,
                                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 22.sp
                            )
                        }
                        if (ad.sub.isNotBlank()) {
                            Text(
                                ad.sub, fontSize = 12.sp, color = Color.White.copy(alpha = 0.92f),
                                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                    if (ad.propertyId != null) {
                        Spacer(Modifier.width(10.dp))
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(34.dp).background(Color.White, CircleShape)
                        ) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "Voir la résidence", tint = Green, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
        if (ads.size > 1) {
            Spacer(Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                repeat(ads.size) { i ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 2.5.dp)
                            .height(6.dp)
                            .width(if (i == pagerState.currentPage) 16.dp else 6.dp)
                            .background(if (i == pagerState.currentPage) Orange else Divider, RoundedCornerShape(4.dp))
                    )
                }
            }
        }
    }
}

@Composable
private fun Modifier.verticalScrollFix(): Modifier {
    val scrollState = androidx.compose.foundation.rememberScrollState()
    return this.verticalScroll(scrollState)
}

private enum class PriceSort { NONE, ASC, DESC }

@Composable
private fun FilterChip(label: String, active: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .background(if (active) Green else CardBg, RoundedCornerShape(20.dp))
            .border(1.dp, if (active) Green else Divider, RoundedCornerShape(20.dp))
            .clickableNoRipple(onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(label, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = if (active) Color.White else Ink)
        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = if (active) Color.White else Sub, modifier = Modifier.size(14.dp))
    }
}

/** Convertit "Grand-Bassam" -> "grand-bassam" pour matcher le slug attendu par l'API */
private fun cityNameToSlug(name: String): String = name
    .lowercase()
    .replace("é", "e").replace("è", "e").replace("ê", "e")
    .replace("à", "a").replace("ô", "o")
    .replace(" ", "-")
