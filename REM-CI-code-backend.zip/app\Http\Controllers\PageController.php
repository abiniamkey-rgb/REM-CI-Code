<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;

/** Pages publiques du site : accueil, confidentialité, conditions d'utilisation, suppression de compte. */
class PageController extends Controller
{
    public function home()
    {
        return view('legal.home');
    }

    public function privacy()
    {
        return view('legal.privacy');
    }

    public function terms()
    {
        return view('legal.terms');
    }

    public function deletion()
    {
        return view('legal.deletion');
    }

    /**
     * Image d'une publicité, servie directement depuis le stockage : ne dépend pas du lien
     * `public/storage` (souvent absent ou cassé selon la machine ou l'hébergeur).
     */
    public function adImage(string $file)
    {
        $path = 'ads/'.$file;
        abort_unless(Storage::disk('public')->exists($path), 404);

        return Storage::disk('public')->response($path, null, [
            'Cache-Control' => 'public, max-age=604800, immutable',
        ]);
    }

    /** Photos de résidence, avatars et publicités servis directement depuis le stockage public. */
    public function mediaFile(string $dir, string $file)
    {
        $path = $dir.'/'.$file;
        abort_unless(Storage::disk('public')->exists($path), 404);

        return Storage::disk('public')->response($path, null, [
            'Cache-Control' => 'public, max-age=604800',
        ]);
    }
}
