@extends('admin.layout')
@section('title', 'Résidences')
@section('content')
  <h1>Résidences</h1>
  <div class="sub">Valide les résidences pour les rendre visibles des locataires.</div>

  <div class="tabs">
    @foreach($statuses as $key => $label)
      <a class="{{ $status === $key ? 'on' : '' }}" href="{{ route('admin.properties.index', ['statut' => $key, 'q' => $search ?: null]) }}">{{ $label }}<small>{{ $counts[$key] ?? 0 }}</small></a>
    @endforeach
    <a class="{{ $status === 'all' ? 'on' : '' }}" href="{{ route('admin.properties.index', ['statut' => 'all', 'q' => $search ?: null]) }}">Toutes</a>
  </div>
  <form class="search" method="GET" action="{{ route('admin.properties.index') }}">
    <input type="hidden" name="statut" value="{{ $status }}">
    <input type="text" name="q" value="{{ $search }}" placeholder="Rechercher un titre, une adresse, un propriétaire…">
    <button class="btn" type="submit">Rechercher</button>
  </form>

  <div class="card tablewrap" style="margin-top:12px">
    <table>
      <thead><tr><th>Résidence</th><th>Propriétaire</th><th>Prix / nuit</th><th>Statut</th><th>Créée</th><th></th></tr></thead>
      <tbody>
      @forelse($properties as $p)
        <tr>
          <td><strong>{{ $p->title }}</strong><div class="sub">{{ $p->city?->name }}{{ $p->address ? ' · '.$p->address : '' }}</div></td>
          <td>{{ $p->owner?->name }}<div class="sub">@if($p->owner) @include('admin._badge', ['status' => $p->owner->owner_verification_status]) @endif</div></td>
          <td>{{ number_format($p->price_per_night, 0, ',', ' ') }} FCFA</td>
          <td>@include('admin._badge', ['status' => $p->status])</td>
          <td class="sub">{{ $p->created_at?->diffForHumans() }}</td>
          <td><a class="btn ghost" href="{{ route('admin.properties.show', $p) }}">Ouvrir</a></td>
        </tr>
      @empty
        <tr><td colspan="6" class="empty">Aucune résidence dans cette liste.</td></tr>
      @endforelse
      </tbody>
    </table>
  </div>
  @include('admin._pager', ['items' => $properties])
@endsection
