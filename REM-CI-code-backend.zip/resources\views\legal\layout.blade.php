<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title') · REM-CI</title>
  <meta name="description" content="@yield('description', 'REM-CI : trouvez une résidence meublée en Côte d\'Ivoire et contactez directement le propriétaire.')">
  <link rel="icon" type="image/png" href="{{ asset('images/favicon.png') }}">
  <style>
    *{box-sizing:border-box}
    body{margin:0;background:#FAF7F0;color:#1B231F;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;line-height:1.65}
    a{color:#0A6C3B}
    .top{background:#fff;border-bottom:1px solid #F0ECE0}
    .top .in{max-width:820px;margin:0 auto;padding:10px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px}
    .top img{height:44px;width:auto;display:block}
    .top nav a{margin-left:14px;font-size:14px;text-decoration:none;font-weight:600;color:#0A6C3B}
    .wrap{max-width:820px;margin:0 auto;padding:26px 18px 50px}
    h1{font-size:28px;margin:6px 0 4px;line-height:1.25}
    h2{font-size:19px;margin:30px 0 8px;color:#0A6C3B}
    .upd{color:#6B756E;font-size:13px;margin:0 0 18px}
    ul{padding-left:22px} li{margin:4px 0}
    .box{background:#fff;border:1px solid #F0ECE0;border-radius:16px;padding:16px 18px;margin:16px 0}
    .foot{border-top:1px solid #F0ECE0;margin-top:40px;padding-top:16px;color:#6B756E;font-size:12.5px}
    .foot a{margin-right:14px}
    table{border-collapse:collapse;width:100%;font-size:14px;background:#fff}
    th,td{border:1px solid #E9E4D6;padding:8px 10px;text-align:left;vertical-align:top}
    th{background:#F4F1E8}
  </style>
</head>
<body>
<header class="top"><div class="in">
  <a href="{{ url('/') }}"><img src="{{ asset('images/remci-logo.png') }}" alt="REM-CI"></a>
  <nav>
    <a href="{{ route('legal.privacy') }}">Confidentialité</a>
    <a href="{{ route('legal.terms') }}">Conditions</a>
  </nav>
</div></header>
<main class="wrap">
  @yield('content')
  <div class="foot">
    <a href="{{ route('legal.privacy') }}">Politique de confidentialité</a>
    <a href="{{ route('legal.terms') }}">Conditions d'utilisation</a>
    <a href="{{ route('legal.deletion') }}">Supprimer mon compte</a><br>
    © {{ date('Y') }} {{ config('remci.company') }} · <a href="mailto:{{ config('remci.contact_email') }}">{{ config('remci.contact_email') }}</a>
  </div>
</main>
</body>
</html>
