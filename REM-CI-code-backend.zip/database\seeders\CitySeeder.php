<?php

namespace Database\Seeders;

use App\Models\City;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class CitySeeder extends Seeder
{
    public function run(): void
    {
        // Grandes villes de Côte d'Ivoire où REM-CI peut avoir des résidences meublées.
        // L'app Android les affiche triées par ordre alphabétique ; l'ordre ici n'a pas
        // d'importance pour ça, mais on le garde lisible.
        $cities = [
            ['name' => 'Abengourou', 'tone_color' => '#0091D8'],
            ['name' => 'Abidjan', 'tone_color' => '#0A6C3B'],
            ['name' => 'Aboisso', 'tone_color' => '#D4AF37'],
            ['name' => 'Agboville', 'tone_color' => '#F77F00'],
            ['name' => 'Assinie', 'tone_color' => '#0091D8'],
            ['name' => 'Bondoukou', 'tone_color' => '#E0630A'],
            ['name' => 'Bouaké', 'tone_color' => '#F77F00'],
            ['name' => 'Daloa', 'tone_color' => '#D4AF37'],
            ['name' => 'Danané', 'tone_color' => '#0A6C3B'],
            ['name' => 'Divo', 'tone_color' => '#0091D8'],
            ['name' => 'Duékoué', 'tone_color' => '#E0630A'],
            ['name' => 'Ferkessédougou', 'tone_color' => '#D4AF37'],
            ['name' => 'Gagnoa', 'tone_color' => '#F77F00'],
            ['name' => 'Grand-Bassam', 'tone_color' => '#0A6C3B'],
            ['name' => 'Guiglo', 'tone_color' => '#0091D8'],
            ['name' => 'Issia', 'tone_color' => '#E0630A'],
            ['name' => 'Katiola', 'tone_color' => '#D4AF37'],
            ['name' => 'Korhogo', 'tone_color' => '#E0630A'],
            ['name' => 'Man', 'tone_color' => '#0A6C3B'],
            ['name' => 'Odienné', 'tone_color' => '#0091D8'],
            ['name' => 'San-Pédro', 'tone_color' => '#0091D8'],
            ['name' => 'Sassandra', 'tone_color' => '#F77F00'],
            ['name' => 'Séguéla', 'tone_color' => '#D4AF37'],
            ['name' => 'Soubré', 'tone_color' => '#0A6C3B'],
            ['name' => 'Tiassalé', 'tone_color' => '#E0630A'],
            ['name' => 'Toumodi', 'tone_color' => '#F77F00'],
            ['name' => 'Yamoussoukro', 'tone_color' => '#D4AF37'],
        ];

        foreach ($cities as $city) {
            City::updateOrCreate(
                ['slug' => Str::slug($city['name'])],
                ['name' => $city['name'], 'tone_color' => $city['tone_color']]
            );
        }
    }
}
