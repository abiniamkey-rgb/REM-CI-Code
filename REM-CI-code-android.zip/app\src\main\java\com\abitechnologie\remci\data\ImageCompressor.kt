package com.abitechnologie.remci.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

/**
 * Réduit une photo d'appareil photo (souvent 3 à 8 Mo) à ~300-800 Ko avant l'envoi au serveur :
 * envoi beaucoup plus rapide sur le réseau mobile, et aucun refus à cause de la limite
 * d'upload de PHP (2 Mo par défaut). Le texte de la pièce d'identité reste parfaitement lisible.
 * La photo d'origine n'est pas modifiée ; en cas de problème, on renvoie l'original.
 */
object ImageCompressor {

    suspend fun compressForUpload(source: File, maxSide: Int = 1600, quality: Int = 82): File =
        withContext(Dispatchers.IO) {
            try {
                if (!source.exists()) return@withContext source

                // 1) Dimensions sans charger l'image en mémoire
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(source.path, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@withContext source

                // 2) Décodage allégé (puissance de 2) puis mise à l'échelle exacte
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
                var bitmap = BitmapFactory.decodeFile(
                    source.path,
                    BitmapFactory.Options().apply { inSampleSize = sample }
                ) ?: return@withContext source

                val longest = max(bitmap.width, bitmap.height)
                if (longest > maxSide) {
                    val ratio = maxSide.toFloat() / longest
                    val scaled = Bitmap.createScaledBitmap(
                        bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true
                    )
                    if (scaled !== bitmap) bitmap.recycle()
                    bitmap = scaled
                }

                // 3) Respecte l'orientation EXIF (photos prises en portrait)
                val degrees = when (
                    ExifInterface(source.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                ) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
                if (degrees != 0f) {
                    val rotated = Bitmap.createBitmap(
                        bitmap, 0, 0, bitmap.width, bitmap.height, Matrix().apply { postRotate(degrees) }, true
                    )
                    if (rotated !== bitmap) bitmap.recycle()
                    bitmap = rotated
                }

                val out = File(source.parentFile, "up_${source.nameWithoutExtension}.jpg")
                out.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, quality, it) }
                bitmap.recycle()

                if (out.length() in 1 until source.length()) out else source
            } catch (e: Exception) {
                source
            }
        }
}
