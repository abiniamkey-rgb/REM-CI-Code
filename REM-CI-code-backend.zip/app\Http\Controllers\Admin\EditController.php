<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PropertyEdit;
use App\Models\UserNotification;
use Illuminate\Http\Request;

/** Modifications faites par les propriétaires sur des résidences déjà publiées : à relire. */
class EditController extends Controller
{
    public function index(Request $request)
    {
        $filter = $request->query('filtre', 'review');

        $edits = PropertyEdit::with(['property.city', 'user'])
            ->when($filter === 'review', fn ($q) => $q->whereNull('reviewed_at'))
            ->when($filter === 'flagged', fn ($q) => $q->where('flagged', true)->whereNull('reviewed_at'))
            ->when($filter === 'reverted', fn ($q) => $q->whereNotNull('reverted_at'))
            ->orderByDesc('flagged')->latest()
            ->paginate(15)
            ->withQueryString();

        $counts = [
            'review' => PropertyEdit::whereNull('reviewed_at')->count(),
            'flagged' => PropertyEdit::where('flagged', true)->whereNull('reviewed_at')->count(),
            'reverted' => PropertyEdit::whereNotNull('reverted_at')->count(),
            'all' => PropertyEdit::count(),
        ];

        return view('admin.edits.index', compact('edits', 'filter', 'counts'));
    }

    /** « C'est bon » : la modification est relue et conservée. */
    public function review(PropertyEdit $edit)
    {
        $edit->update(['reviewed_at' => now()]);

        return back()->with('ok', 'Modification marquée comme vérifiée.');
    }

    /** Annule une description jugée inappropriée : l'ancien texte est rétabli et le propriétaire prévenu. */
    public function revert(PropertyEdit $edit)
    {
        if ($edit->field !== 'description' || $edit->reverted_at) {
            return back()->with('erreur', 'Seule une modification de description peut être annulée.');
        }

        $property = $edit->property;
        $property->update(['description' => $edit->old_value]);
        $edit->update(['reviewed_at' => now(), 'reverted_at' => now()]);

        UserNotification::notify(
            $property->owner, 'property', 'Description rétablie',
            "Ta dernière modification de la description de « {$property->title} » ne respecte pas les règles de REM-CI : l'ancien texte a été rétabli. "
                .'Pour toute question, contacte l\'administrateur au '.UserNotification::adminContacts().'.',
            ['property_id' => $property->id]
        );

        return back()->with('ok', 'Modification annulée : ancien texte rétabli, propriétaire prévenu.');
    }
}
