<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\UserNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

/**
 * Dossier du locataire — exigé avant la première demande de réservation :
 * identité complète, date de naissance (majeur : 18 ans minimum), adresse, contact
 * et pièce d'identité (CNI, passeport, attestation d'identité ou permis).
 */
class TenantProfileController extends Controller
{
    public const MIN_AGE = 18;
    public const TYPES = ['cni', 'passeport', 'attestation', 'permis'];

    /** GET /api/tenant/profile */
    public function show(Request $request)
    {
        if ($request->user()->role !== 'locataire') {
            return response()->json(['message' => 'Réservé aux locataires'], 403);
        }

        return new UserResource($request->user());
    }

    /** POST /api/tenant/profile  (multipart) */
    public function store(Request $request)
    {
        $user = $request->user();

        if ($user->role !== 'locataire') {
            return response()->json(['message' => 'Réservé aux locataires'], 403);
        }

        $request->merge(['phone' => preg_replace('/[\s.\-()]+/', '', trim((string) $request->phone))]);

        $type = (string) $request->input('identity_type');
        // Une pièce refusée doit être renvoyée ; sinon on garde les photos déjà envoyées.
        $replaceDocs = $user->identity_status === 'rejected';
        $needRecto = ! $user->id_document_url || $replaceDocs;
        $needVerso = $type === 'cni' && (! $user->id_document_verso_url || $replaceDocs);
        $latestBirth = now()->subYears(self::MIN_AGE)->toDateString();

        $data = $request->validate([
            'name' => ['required', 'string', 'min:3', 'max:255'],
            'phone' => ['required', 'string', 'regex:/^\+?[0-9]{10,15}$/', Rule::unique('users', 'phone')->ignore($user->id)],
            'address' => ['required', 'string', 'min:5', 'max:255'],
            'birth_date' => ['required', 'date_format:Y-m-d', 'after:1900-01-01', 'before_or_equal:'.$latestBirth],
            'identity_type' => ['required', Rule::in(self::TYPES)],
            'identity_number' => ['required', 'string', 'min:4', 'max:50'],
            'id_document_recto' => [$needRecto ? 'required' : 'nullable', 'image', 'max:8192'],
            'id_document_verso' => [$needVerso ? 'required' : 'nullable', 'image', 'max:8192'],
        ], [
            'name.required' => 'Indique ton nom complet.',
            'name.min' => 'Indique ton nom complet.',
            'phone.required' => 'Indique ton numéro de téléphone.',
            'phone.regex' => 'Numéro de téléphone invalide : 10 chiffres (ex. 07 07 98 28 02).',
            'phone.unique' => 'Ce numéro est déjà utilisé par un autre compte.',
            'address.required' => 'Indique ton adresse (quartier, commune, ville).',
            'address.min' => "Ton adresse semble trop courte : indique le quartier, la commune et la ville.",
            'birth_date.required' => 'Indique ta date de naissance.',
            'birth_date.date_format' => 'Date de naissance invalide.',
            'birth_date.after' => 'Date de naissance invalide.',
            'birth_date.before_or_equal' => 'Tu dois avoir au moins '.self::MIN_AGE.' ans pour réserver une résidence.',
            'identity_type.required' => "Choisis le type de pièce d'identité.",
            'identity_type.in' => "Type de pièce d'identité invalide.",
            'identity_number.required' => "Indique le numéro de ta pièce d'identité.",
            'identity_number.min' => "Le numéro de ta pièce d'identité semble trop court.",
            'id_document_recto.required' => 'Ajoute la photo de ta pièce d\'identité (recto).',
            'id_document_recto.image' => 'Le recto doit être une photo.',
            'id_document_verso.required' => 'La CNI se photographie des deux côtés : ajoute le verso.',
            'id_document_verso.image' => 'Le verso doit être une photo.',
        ]);

        // Disque PRIVÉ : une pièce d'identité n'est jamais accessible par une URL publique.
        $recto = $user->id_document_url;
        $verso = $user->id_document_verso_url;

        if ($request->hasFile('id_document_recto')) {
            $this->discard($recto);
            $recto = $request->file('id_document_recto')->store('tenant_documents', 'local');
        }
        if ($request->hasFile('id_document_verso')) {
            $this->discard($verso);
            $verso = $request->file('id_document_verso')->store('tenant_documents', 'local');
        } elseif ($type !== 'cni' && $verso && ! $request->hasFile('id_document_verso') && $user->identity_type === 'cni') {
            // Passage d'une CNI à un autre type de pièce : l'ancien verso n'a plus de sens.
            $this->discard($verso);
            $verso = null;
        }

        $user->update([
            'name' => $data['name'],
            'phone' => $data['phone'],
            'address' => $data['address'],
            'birth_date' => $data['birth_date'],
            'identity_type' => $data['identity_type'],
            'identity_number' => strtoupper(trim($data['identity_number'])),
            'id_document_url' => $recto,
            'id_document_verso_url' => $verso,
            'identity_status' => 'submitted',
            'identity_note' => null,
            'identity_verified_at' => null,
        ]);

        UserNotification::notify(
            $user, 'verification', 'Dossier reçu ✅',
            'Ton dossier locataire est enregistré : tu peux maintenant réserver (3 demandes maximum par jour).'
        );

        return new UserResource($user->fresh());
    }

    private function discard(?string $path): void
    {
        if (! $path) {
            return;
        }
        foreach (['local', 'public'] as $disk) {
            Storage::disk($disk)->delete($path);
        }
    }
}
