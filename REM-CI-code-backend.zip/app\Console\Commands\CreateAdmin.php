<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class CreateAdmin extends Command
{
    protected $signature = 'remci:create-admin {--name=} {--phone=} {--email=} {--password=}';

    protected $description = "Crée (ou met à jour) un compte administrateur REM-CI pour le panneau /admin";

    public function handle(): int
    {
        $name = $this->option('name') ?: $this->ask('Nom complet', 'Administrateur REM-CI');
        $phone = preg_replace('/[\s.\-()]+/', '', (string) ($this->option('phone') ?: $this->ask('Téléphone (ex. 0707982802)')));
        $email = strtolower((string) ($this->option('email') ?: $this->ask('E-mail (facultatif)', '')));
        $password = $this->option('password') ?: $this->secret('Mot de passe (8 caractères minimum)');

        if ($phone === '' || strlen((string) $password) < 8) {
            $this->error('Téléphone obligatoire et mot de passe de 8 caractères minimum.');

            return self::FAILURE;
        }

        $existing = User::where('phone', $phone)->first();
        if ($existing && $existing->role !== 'admin' && ! $this->confirm("Ce numéro appartient à un compte « {$existing->role} ». Le transformer en administrateur ?", false)) {
            return self::FAILURE;
        }

        $attributes = ['name' => $name, 'password' => $password, 'role' => 'admin', 'is_verified' => true];
        if ($email !== '') {
            $attributes['email'] = $email;
        }

        $user = User::updateOrCreate(['phone' => $phone], $attributes);

        $this->info("Administrateur prêt : {$user->name} ({$user->phone}). Connexion sur /admin avec ce téléphone.");

        return self::SUCCESS;
    }
}
