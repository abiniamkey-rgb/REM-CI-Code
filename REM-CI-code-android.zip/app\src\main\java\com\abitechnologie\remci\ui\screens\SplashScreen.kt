package com.abitechnologie.remci.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.ui.components.LogoMark
import com.abitechnologie.remci.ui.components.clickableNoRipple
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.delay

/**
 * Écran de démarrage — dégradé "coucher de soleil" orange → vert aux couleurs de la Côte d'Ivoire,
 * logo animé (entrée en douceur + halo qui respire), promesse de la marque, trois atouts
 * et une barre de chargement. Un appui n'importe où permet de passer directement.
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    var started by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf(false) }

    fun finishOnce() {
        if (!finished) {
            finished = true
            onFinished()
        }
    }

    LaunchedEffect(Unit) {
        started = true
        delay(4800)
        finishOnce()
    }

    val logoScale by animateFloatAsState(if (started) 1f else 0.6f, tween(750, easing = FastOutSlowInEasing), label = "logoScale")
    val logoAlpha by animateFloatAsState(if (started) 1f else 0f, tween(650), label = "logoAlpha")
    val titleAlpha by animateFloatAsState(if (started) 1f else 0f, tween(700, delayMillis = 350), label = "titleAlpha")
    val defAlpha by animateFloatAsState(if (started) 1f else 0f, tween(700, delayMillis = 600), label = "defAlpha")
    val defScale by animateFloatAsState(if (started) 1f else 0.88f, tween(700, delayMillis = 600, easing = FastOutSlowInEasing), label = "defScale")
    val perksAlpha by animateFloatAsState(if (started) 1f else 0f, tween(700, delayMillis = 800), label = "perksAlpha")
    val progress by animateFloatAsState(if (started) 1f else 0f, tween(4600, easing = LinearEasing), label = "progress")

    val breathing = rememberInfiniteTransition(label = "halo")
    val haloScale by breathing.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "haloScale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    0f to Color(0xFFFFB157),
                    0.24f to Orange,
                    0.46f to Color(0xFFC9760C),
                    0.70f to Color(0xFF2E8354),
                    1f to GreenDeep
                )
            )
            .clickableNoRipple { finishOnce() }
    ) {
        // Formes décoratives douces
        Box(
            modifier = Modifier
                .size(280.dp)
                .offset(x = (-110).dp, y = (-90).dp)
                .background(Color.White.copy(alpha = 0.07f), CircleShape)
        )
        Box(
            modifier = Modifier
                .size(340.dp)
                .align(Alignment.BottomEnd)
                .offset(x = 130.dp, y = 120.dp)
                .background(Color.Black.copy(alpha = 0.10f), CircleShape)
        )

        Column(
            modifier = Modifier.fillMaxSize().navigationBarsPadding().padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(Modifier.height(1.dp))

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.alpha(logoAlpha)) {
                    Box(
                        modifier = Modifier
                            .size(250.dp)
                            .graphicsLayer(scaleX = haloScale, scaleY = haloScale)
                            .background(Color.White.copy(alpha = 0.14f), CircleShape)
                    )
                    Box(modifier = Modifier.graphicsLayer(scaleX = logoScale, scaleY = logoScale).shadow(18.dp, RoundedCornerShape(52.dp), clip = false)) {
                        LogoMark(size = 220)
                    }
                }

                Text(
                    "Bienvenue sur REM-CI",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.alpha(titleAlpha).padding(top = 22.dp, start = 24.dp, end = 24.dp)
                )

                // Définition de la marque, en ruban aux trois couleurs du drapeau ivoirien
                IvorianRibbon(
                    modifier = Modifier
                        .padding(top = 16.dp, start = 20.dp, end = 20.dp)
                        .graphicsLayer(alpha = defAlpha, scaleX = defScale, scaleY = defScale)
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(22.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().alpha(perksAlpha),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    SplashPerk(Icons.Default.VerifiedUser, "Propriétaires\nvérifiés")
                    SplashPerk(Icons.Default.Chat, "Contact direct\nWhatsApp")
                    SplashPerk(Icons.Default.Bolt, "Réservation\nsimple")
                }

                Box(
                    modifier = Modifier
                        .width(120.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White.copy(alpha = 0.28f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = progress
                                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                            }
                            .background(Color.White, RoundedCornerShape(4.dp))
                    )
                }

                Text(
                    "UNE TECHNOLOGIE ABITECHNOLOGIE",
                    fontSize = 9.5.sp,
                    color = Color.White.copy(alpha = 0.75f),
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

/** « Résidence · Meublée · de Côte d'Ivoire » sur fond orange, blanc, vert (drapeau de la Côte d'Ivoire). */
@Composable
private fun IvorianRibbon(modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(60.dp)
            .shadow(14.dp, shape, clip = false)
            .clip(shape)
            .border(1.5.dp, Color.White, shape)
    ) {
        // Largeurs proportionnelles à chaque mot : « de Côte d’Ivoire » tient sur une seule ligne
        RibbonCell("Résidence", Color(0xFFF77F00), Color.White, Modifier.weight(1.0f))
        RibbonCell("Meublée", Color.White, Color(0xFF0A6C3B), Modifier.weight(0.88f))
        RibbonCell("de Côte d’Ivoire", Color(0xFF0A6C3B), Color.White, Modifier.weight(1.6f))
    }
}

@Composable
private fun RibbonCell(text: String, bg: Color, fg: Color, modifier: Modifier) {
    Box(modifier = modifier.fillMaxSize().background(bg), contentAlignment = Alignment.Center) {
        Text(
            text,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            color = fg,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            maxLines = 1,
            softWrap = false,
            letterSpacing = (-0.1).sp,
            modifier = Modifier.padding(horizontal = 2.dp)
        )
    }
}

@Composable
private fun SplashPerk(icon: ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            modifier = Modifier.size(42.dp).background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Text(
            label,
            fontSize = 10.5.sp,
            color = Color.White.copy(alpha = 0.92f),
            fontWeight = FontWeight.Medium,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 14.sp
        )
    }
}
