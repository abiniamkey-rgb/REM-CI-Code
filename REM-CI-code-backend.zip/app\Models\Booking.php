<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id', 'property_id', 'check_in', 'check_out', 'guests', 'nights',
        'price_per_night', 'service_fee', 'total_price', 'status',
        'payment_method', 'payment_status', 'expired_at', 'reference', 'confirmed_at',
    ];

    /** Nombre maximal de demandes de réservation qu'un locataire peut envoyer par jour. */
    public const DAILY_LIMIT = 3;

    /** Une demande sans réponse du propriétaire expire au bout de ce nombre d'heures. */
    public const EXPIRY_HOURS = 48;

    /** Durée maximale d'un séjour demandé, en nuits. */
    public const MAX_NIGHTS = 30;

    /** Demandes envoyées aujourd'hui par ce locataire (les annulées comptent aussi : anti-abus). */
    public static function sentTodayBy(int $userId): int
    {
        return static::where('user_id', $userId)->where('created_at', '>=', now()->startOfDay())->count();
    }

    protected $casts = [
        'check_in' => 'date',
        'check_out' => 'date',
        'expired_at' => 'datetime',
        'confirmed_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        // Chaque demande reçoit un numéro unique, repris sur le reçu et dans le code QR.
        static::creating(function (Booking $booking) {
            if (! $booking->reference) {
                $booking->reference = static::makeReference();
            }
        });
    }

    /** « REMCI-K7Q3PX9M » : 8 caractères sans ambiguïté (ni 0/O, ni 1/I/L), unique en base. */
    public static function makeReference(): string
    {
        $alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
        do {
            $code = '';
            for ($i = 0; $i < 8; $i++) {
                $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
            }
            $reference = 'REMCI-'.$code;
        } while (static::where('reference', $reference)->exists());

        return $reference;
    }

    /** Statut montré aux apps et à l'admin : « expired » pour une demande restée sans réponse. */
    public function getDisplayStatusAttribute(): string
    {
        return $this->expired_at ? 'expired' : $this->status;
    }

    /**
     * Expire les demandes « en attente » restées sans réponse du propriétaire pendant
     * EXPIRY_HOURS (ou dont la date d'arrivée est déjà passée). Les dates se libèrent et
     * le locataire comme le propriétaire sont prévenus. Appelée à chaque lecture des
     * réservations (aucun planificateur requis) et par la commande `bookings:expire`.
     */
    public static function expireStale(): int
    {
        $stale = static::with('property.owner', 'user')
            ->where('status', 'pending')
            ->where(function ($q) {
                $q->where('created_at', '<=', now()->subHours(self::EXPIRY_HOURS))
                    ->orWhere('check_in', '<', now()->startOfDay());
            })
            ->limit(200)
            ->get();

        foreach ($stale as $booking) {
            $booking->forceFill(['status' => 'cancelled', 'expired_at' => now()])->save();
            $title = $booking->property?->title ?? 'la résidence';
            UserNotification::notify(
                $booking->user, 'booking_update', 'Demande expirée',
                "Le propriétaire n'a pas répondu à ta demande pour « {$title} ». Elle est expirée : tu peux la renouveler ou contacter une autre résidence.",
                ['booking_id' => $booking->id]
            );
            UserNotification::notify(
                $booking->property?->owner, 'booking_update', 'Demande expirée',
                "La demande de {$booking->user?->name} pour « {$title} » a expiré faute de réponse.",
                ['booking_id' => $booking->id]
            );
        }

        return $stale->count();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function property()
    {
        return $this->belongsTo(Property::class);
    }
}
