package com.abitechnologie.remci.ui.components

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** 15000 → "15 000" (espace simple, quel que soit la langue du téléphone). */
fun formatFcfa(amount: Int): String = String.format(Locale.US, "%,d", amount).replace(',', ' ')

/**
 * "2026-10-20" → "mar. 20 oct." (ou autre [pattern]). Les dates de l'API n'ont pas d'heure :
 * on les lit et on les écrit en UTC pour ne jamais décaler d'un jour.
 */
fun formatIsoDate(iso: String, pattern: String = "EEE d MMM"): String {
    return try {
        val utc = TimeZone.getTimeZone("UTC")
        val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = utc }.parse(iso.take(10)) ?: return iso
        SimpleDateFormat(pattern, Locale.FRANCE).apply { timeZone = utc }.format(parsed)
    } catch (e: Exception) {
        iso
    }
}

/** Date issue du sélecteur de dates (millisecondes UTC) → "mar. 20 oct. 2026". */
fun formatMillisDate(utcMillis: Long, pattern: String = "EEE d MMM yyyy"): String =
    SimpleDateFormat(pattern, Locale.FRANCE).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(utcMillis))
