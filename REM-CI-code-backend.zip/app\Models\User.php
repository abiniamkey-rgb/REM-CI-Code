<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name', 'email', 'google_id', 'email_verified_at', 'phone', 'password', 'role', 'avatar', 'is_verified',
        'address', 'id_document_url', 'id_document_verso_url', 'detected_name',
        'detected_id_number', 'owner_verification_status', 'owner_verified_at',
        'birth_date', 'identity_type', 'identity_number', 'identity_status', 'identity_note', 'identity_verified_at',
    ];

    /** Motif de refus saisi par l'admin (non enregistré en base) : ajouté à la notification envoyée. */
    public ?string $rejectionNote = null;

    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'is_verified' => 'boolean',
        'owner_verified_at' => 'datetime',
        'birth_date' => 'date',
        'identity_verified_at' => 'datetime',
    ];

    /** Notifications affichées dans l'app (le trait Notifiable utilise déjà le nom `notifications`). */
    public function appNotifications()
    {
        return $this->hasMany(UserNotification::class);
    }

    protected static function booted(): void
    {
        // Prévient le propriétaire dès que l'administrateur change le statut de son dossier
        // (via tinker ou l'éditeur de base de données).
        // Dossier locataire : prévient le locataire quand l'admin valide ou refuse son identité.
        static::updated(function (User $user) {
            if (! $user->wasChanged('identity_status')) {
                return;
            }

            if ($user->identity_status === 'verified') {
                UserNotification::notify(
                    $user, 'verification', 'Identité vérifiée ✅',
                    'Ton dossier locataire est validé. Tu peux réserver en toute confiance.'
                );
            } elseif ($user->identity_status === 'rejected') {
                $reason = $user->identity_note ? " Motif : {$user->identity_note}." : '';
                UserNotification::notify(
                    $user, 'verification', 'Dossier locataire à corriger',
                    "Ton dossier n'a pas pu être validé.".$reason." Ouvre l'onglet Profil > Mon dossier pour le corriger et le renvoyer."
                );
            }
        });

        static::updated(function (User $user) {
            if (! $user->wasChanged('owner_verification_status')) {
                return;
            }

            if ($user->owner_verification_status === 'verified') {
                UserNotification::notify(
                    $user, 'verification', 'Identité certifiée ✅',
                    "Ton compte propriétaire est certifié. Tes résidences seront publiées dès leur activation par l'administrateur REM-CI."
                );
            } elseif ($user->owner_verification_status === 'rejected') {
                $reason = $user->rejectionNote ? " Motif : {$user->rejectionNote}." : '';
                UserNotification::notify(
                    $user, 'verification', 'Dossier refusé',
                    'Ton dossier d\'identité n\'a pas pu être validé.'.$reason.' Contacte l\'administrateur REM-CI au '.UserNotification::adminContacts().' pour le corriger.'
                );
            }
        });
    }

    public function properties()
    {
        return $this->hasMany(Property::class, 'owner_id');
    }

    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }

    public function favorites()
    {
        return $this->belongsToMany(Property::class, 'favorites')->withTimestamps();
    }

    /** Âge en années révolues (null si la date de naissance est inconnue). */
    public function age(): ?int
    {
        return $this->birth_date?->age;
    }

    /**
     * Dossier locataire complet : informations + pièce d'identité envoyées (et non refusées).
     * Condition pour pouvoir envoyer une demande de réservation.
     */
    public function hasTenantProfile(): bool
    {
        return in_array($this->identity_status, ['submitted', 'verified'], true)
            && $this->birth_date !== null
            && filled($this->address)
            && filled($this->phone);
    }

    public function isOwner(): bool
    {
        return $this->role === 'proprietaire';
    }

    /**
     * Un propriétaire qui n'a encore jamais soumis son dossier de vérification
     * (nom, téléphone, adresse, pièce d'identité) doit y être redirigé après connexion,
     * avant de pouvoir accéder à "Ajouter une résidence".
     */
    public function needsOwnerVerification(): bool
    {
        return $this->isOwner() && $this->owner_verification_status === 'not_submitted';
    }

    /**
     * Vérification soumise et en attente de certification manuelle par l'administrateur
     * (phpMyAdmin) — le propriétaire peut déjà remplir le formulaire de résidence, mais
     * celle-ci ne sera visible aux locataires qu'une fois le compte certifié et la
     * résidence activée manuellement.
     */
    public function isOwnerVerified(): bool
    {
        return $this->owner_verification_status === 'verified';
    }
}
