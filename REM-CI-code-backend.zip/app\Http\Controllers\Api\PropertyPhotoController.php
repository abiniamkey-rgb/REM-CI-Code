<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PropertyResource;
use App\Models\Property;
use Illuminate\Http\Request;

class PropertyPhotoController extends Controller
{
    public const MAX_PHOTOS = 12;

    /**
     * POST /api/properties/{property}/photos — ajoute des photos à une résidence.
     * Le propriétaire les prend directement avec l'appareil photo de son téléphone
     * (l'app Android n'ouvre plus la galerie), elles arrivent donc ici comme de
     * simples fichiers image envoyés en multipart.
     */
    public function store(Request $request, Property $property)
    {
        if ($property->owner_id !== $request->user()->id) {
            return response()->json(['message' => 'Non autorisé'], 403);
        }

        // Sécurité : une résidence publiée ne reçoit plus de photos sans passer par l'administrateur
        // (sinon on pourrait ajouter des images non contrôlées après la validation).
        if ($property->status === 'active') {
            return response()->json([
                'message' => 'Ta résidence est publiée : pour changer ses photos, contacte l\'administrateur REM-CI au '
                    .\App\Models\UserNotification::adminContacts().'.',
                'code' => 'locked_after_publish',
            ], 422);
        }

        $request->validate([
            'photos' => ['required', 'array', 'min:1', 'max:8'],
            'photos.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:8192'],
        ]);

        if ($property->photos()->count() + count($request->file('photos')) > self::MAX_PHOTOS) {
            return response()->json(['message' => self::MAX_PHOTOS.' photos maximum par résidence.', 'code' => 'too_many_photos'], 422);
        }

        $nextPosition = ((int) $property->photos()->max('position')) + 1;

        foreach ($request->file('photos') as $i => $file) {
            $path = $file->store('property_photos', 'public');
            $property->photos()->create([
                'url' => $path,
                'position' => $nextPosition + $i,
            ]);
        }

        return new PropertyResource($property->fresh()->load(['city', 'photos', 'amenities']));
    }
}
