package com.abitechnologie.remci.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.R
import com.abitechnologie.remci.ui.components.LogoMark
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.delay

/**
 * Choix du profil — grande photo de résidence en tête, feuille blanche aux coins arrondis
 * avec deux cartes de rôle claires (Locataire / Propriétaire), puis les garanties REM-CI.
 * Une seule décision à prendre, expliquée en une phrase pour chaque rôle.
 */
@Composable
fun ProfileChoiceScreen(onChoose: (role: String) -> Unit) {
    var showSheet by remember { mutableStateOf(false) }
    var showCards by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        showSheet = true
        delay(180)
        showCards = true
    }

    Box(modifier = Modifier.fillMaxSize().background(Bg)) {
        // ---------- Photo de couverture ----------
        Box(modifier = Modifier.fillMaxWidth().fillMaxHeight(0.48f)) {
            Image(
                painter = painterResource(id = R.drawable.choice_residence),
                contentDescription = "Résidence meublée REM-CI",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color(0xFF06120C).copy(alpha = 0.72f),
                            0.5f to Color(0xFF06120C).copy(alpha = 0.25f),
                            1f to Color(0xFF06120C).copy(alpha = 0.45f)
                        )
                    )
            )
            Column(modifier = Modifier.statusBarsPadding().padding(horizontal = 24.dp, vertical = 18.dp)) {
                LogoMark(size = 96)
                Spacer(Modifier.height(14.dp))
                Text(
                    "Votre application de publication et de réservation de résidences meublées partout en Côte d'Ivoire",
                    fontSize = 22.sp,
                    lineHeight = 29.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
            }
        }

        // ---------- Feuille de choix ----------
        AnimatedVisibility(
            visible = showSheet,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 4 }
        ) {
            Surface(
                color = Bg,
                shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                shadowElevation = 14.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .padding(horizontal = 22.dp)
                        .padding(top = 12.dp, bottom = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(40.dp)
                            .height(4.dp)
                            .background(Color(0xFFE2DCCB), RoundedCornerShape(4.dp))
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("Vous êtes ?", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                    Spacer(Modifier.height(18.dp))

                    AnimatedVisibility(
                        visible = showCards,
                        enter = fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 5 }
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            RoleCard(
                                icon = Icons.Default.Search,
                                title = "Je suis locataire",
                                description = "Je cherche une résidence meublée et je contacte le propriétaire.",
                                gradient = Brush.linearGradient(listOf(Color(0xFF1976D2), Blue)),
                                accent = Blue,
                                onClick = { onChoose("locataire") }
                            )
                            RoleCard(
                                icon = Icons.Default.Apartment,
                                title = "Je suis propriétaire",
                                description = "Je publie mes résidences et je reçois les demandes de réservation.",
                                gradient = Brush.linearGradient(listOf(Orange, OrangeDeep)),
                                accent = Orange,
                                onClick = { onChoose("proprietaire") }
                            )
                        }
                    }

                    Spacer(Modifier.height(18.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Guarantee(Icons.Default.Shield, "Propriétaires\nvérifiés")
                        Guarantee(Icons.Default.Chat, "Contact direct\nsans frais")
                        Guarantee(Icons.Default.Place, "Partout\nen Côte d'Ivoire")
                    }

                    Spacer(Modifier.height(14.dp))
                    Row {
                        Text("UNE TECHNOLOGIE ", fontSize = 9.5.sp, color = Color(0xFFB8B0A0), letterSpacing = 1.sp)
                        Text("ABITECHNOLOGIE", fontSize = 9.5.sp, color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun RoleCard(
    icon: ImageVector,
    title: String,
    description: String,
    gradient: Brush,
    accent: Color,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, tween(120), label = "roleScale")

    Surface(
        color = CardBg,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(if (pressed) 1.5.dp else 1.dp, if (pressed) accent else Divider),
        shadowElevation = if (pressed) 1.dp else 4.dp,
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer(scaleX = scale, scaleY = scale)
            .clickable(interactionSource = interaction, indication = androidx.compose.foundation.LocalIndication.current, onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(52.dp).background(gradient, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                Text(
                    description,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp,
                    color = Sub,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
            Spacer(Modifier.width(10.dp))
            Box(
                modifier = Modifier.size(32.dp).background(accent.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun Guarantee(icon: ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            modifier = Modifier.size(34.dp).background(Green.copy(alpha = 0.09f), RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(17.dp))
        }
        Text(
            label,
            fontSize = 10.sp,
            lineHeight = 13.sp,
            color = Sub,
            fontWeight = FontWeight.Medium,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
