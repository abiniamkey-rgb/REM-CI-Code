<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLogin()
    {
        if (Auth::guard('web')->check() && Auth::guard('web')->user()->role === 'admin') {
            return redirect()->route('admin.dashboard');
        }

        return view('admin.login');
    }

    public function login(Request $request)
    {
        $data = $request->validate([
            'identifier' => ['required', 'string'],
            'password' => ['required', 'string'],
        ], [
            'identifier.required' => 'Saisis ton téléphone ou ton e-mail.',
            'password.required' => 'Saisis ton mot de passe.',
        ]);

        $identifier = trim($data['identifier']);
        $field = str_contains($identifier, '@') ? 'email' : 'phone';
        $value = $field === 'email'
            ? strtolower($identifier)
            : (preg_replace('/[\s.\-()]+/', '', $identifier) ?? $identifier);

        // Le rôle fait partie des conditions : un locataire ou un propriétaire ne peut pas entrer.
        $ok = Auth::guard('web')->attempt(
            [$field => $value, 'password' => $data['password'], 'role' => 'admin'],
            $request->boolean('remember')
        );

        if (! $ok) {
            return back()->withInput($request->only('identifier'))
                ->withErrors(['identifier' => 'Identifiants incorrects ou accès non autorisé.']);
        }

        $request->session()->regenerate();

        return redirect()->intended(route('admin.dashboard'));
    }

    public function logout(Request $request)
    {
        Auth::guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('admin.login');
    }
}
