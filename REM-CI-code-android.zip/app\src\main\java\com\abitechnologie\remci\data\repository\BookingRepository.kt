package com.abitechnologie.remci.data.repository

import com.abitechnologie.remci.data.network.*

class BookingRepository {
    private val api = RetrofitClient.api

    suspend fun getMyBookings(): ApiResult<List<BookingDto>> = try {
        val response = api.getBookings()
        when {
            response.isSuccessful -> ApiResult.Success(response.body()?.data ?: emptyList())
            response.code() == 401 -> ApiResult.Error("Ta session a expiré, reconnecte-toi.", SESSION_EXPIRED)
            else -> ApiResult.Error("Impossible de charger tes réservations pour le moment. Réessaie dans un instant.")
        }
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /** Propriétaire — réservations reçues sur ses résidences. */
    suspend fun getOwnerBookings(): ApiResult<List<BookingDto>> = try {
        val response = api.getOwnerBookings()
        if (response.isSuccessful) ApiResult.Success(response.body()?.data ?: emptyList())
        else ApiResult.Error("Impossible de charger les réservations reçues")
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /** Propriétaire — confirme, refuse ("cancelled") ou termine une réservation. */
    suspend fun setOwnerBookingStatus(id: Int, status: String): ApiResult<BookingDto> = try {
        val response = api.updateOwnerBooking(id, mapOf("status" to status))
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Action impossible"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    /** Enregistre la demande de réservation — le locataire est ensuite redirigé vers
     * WhatsApp/l'appel direct du propriétaire pour finaliser avec lui, sans paiement en ligne. */
    suspend fun createBooking(propertyId: Int, checkIn: String, checkOut: String, guests: Int): ApiResult<BookingDto> = try {
        val response = api.createBooking(BookingRequest(propertyId, checkIn, checkOut, guests))
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else {
            val raw = response.errorBody()?.string()
            ApiResult.Error(errorMessage(raw, "Impossible d'envoyer ta demande"), errorCode(raw))
        }
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e), NETWORK)
    }

    /** Périodes déjà prises pour cette résidence (liste vide si le serveur ne répond pas). */
    suspend fun getAvailability(propertyId: Int): List<BookedRangeDto> = try {
        val response = api.getAvailability(propertyId)
        if (response.isSuccessful) response.body()?.data ?: emptyList() else emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    /** Le locataire annule sa propre demande (le propriétaire est prévenu par notification). */
    suspend fun cancelBooking(id: Int): ApiResult<BookingDto> = try {
        val response = api.cancelBooking(id)
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible d'annuler la demande"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }
}
