package com.abitechnologie.remci.data.network

import kotlinx.coroutines.flow.MutableSharedFlow

/**
 * Événements de session partagés entre la couche réseau et l'interface.
 * `expired` est émis quand le serveur répond 401 à une requête authentifiée :
 * le jeton n'est plus valable (expiré, révoqué, mot de passe changé sur un autre appareil).
 */
object SessionEvents {
    val expired = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
}
