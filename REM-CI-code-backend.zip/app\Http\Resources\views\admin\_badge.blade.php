@php
  $labels = [
    'pending' => 'En attente', 'verified' => 'Certifié', 'rejected' => 'Refusé', 'not_submitted' => 'Non soumis',
    'submitted' => 'À examiner', 'active' => 'Publiée', 'inactive' => 'Retirée',
    'confirmed' => 'Confirmée', 'completed' => 'Terminée', 'cancelled' => 'Annulée',
  ];
@endphp
<span class="badge b-{{ $status }}">{{ $labels[$status] ?? $status }}</span>
