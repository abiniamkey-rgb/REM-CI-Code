package com.abitechnologie.remci.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.abitechnologie.remci.data.AppConfig
import com.abitechnologie.remci.data.network.UserDto
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.ProfileRepository
import com.abitechnologie.remci.ui.components.AdminContactBlock
import com.abitechnologie.remci.ui.components.Badge
import com.abitechnologie.remci.ui.components.clickableNoRipple
import com.abitechnologie.remci.ui.components.rememberCameraCapture
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private enum class ProfilePage { MAIN, LANGUAGE, HELP, SETTINGS, VERIFICATION }

private data class ProfileOption(
    val icon: ImageVector,
    val label: String,
    val sub: String,
    val badgeCount: Int = 0,
    val onClick: () -> Unit = {}
)

/**
 * Profil — un compte est soit locataire, soit propriétaire (jamais les deux), donc les
 * options affichées diffèrent. Chaque ligne ouvre un vrai écran : notifications, langue,
 * aide et support, paramètres (infos + mot de passe), vérification d'identité…
 * La photo de profil se change en touchant l'avatar.
 */
@Composable
fun ProfileScreen(
    role: String,
    user: UserDto?,
    unreadCount: Int = 0,
    onUserUpdated: (UserDto) -> Unit = {},
    onLogout: () -> Unit,
    onMyProperties: () -> Unit = {},
    onOpenFavorites: () -> Unit = {},
    onOpenNotifications: () -> Unit = {},
    onOpenVerification: () -> Unit = {},
    onOpenTenantProfile: () -> Unit = {}
) {
    val isOwner = role == "proprietaire"
    val context = LocalContext.current
    var page by remember { mutableStateOf(ProfilePage.MAIN) }

    BackHandler(enabled = page != ProfilePage.MAIN) { page = ProfilePage.MAIN }

    when (page) {
        ProfilePage.LANGUAGE -> LanguagePage(onBack = { page = ProfilePage.MAIN })
        ProfilePage.HELP -> HelpPage(isOwner = isOwner, onBack = { page = ProfilePage.MAIN })
        ProfilePage.SETTINGS -> SettingsPage(
            user = user,
            onUserUpdated = onUserUpdated,
            onAccountDeleted = onLogout,
            onBack = { page = ProfilePage.MAIN }
        )
        ProfilePage.VERIFICATION -> VerificationPage(
            status = user?.ownerVerificationStatus,
            onBack = { page = ProfilePage.MAIN },
            onSubmit = onOpenVerification
        )
        ProfilePage.MAIN -> ProfileMain(
            isOwner = isOwner,
            user = user,
            unreadCount = unreadCount,
            onUserUpdated = onUserUpdated,
            onLogout = onLogout,
            onMyProperties = onMyProperties,
            onOpenFavorites = onOpenFavorites,
            onOpenNotifications = onOpenNotifications,
            onOpenTenantProfile = onOpenTenantProfile,
            onGo = { page = it },
            onInvite = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(
                        Intent.EXTRA_TEXT,
                        "Je cherche mes résidences meublées avec REM-CI, en Côte d'Ivoire, en contact direct avec les propriétaires. Essaie l'application !"
                    )
                }
                context.startActivity(Intent.createChooser(send, "Inviter des proches"))
            }
        )
    }
}

@Composable
private fun ProfileMain(
    isOwner: Boolean,
    user: UserDto?,
    unreadCount: Int,
    onUserUpdated: (UserDto) -> Unit,
    onLogout: () -> Unit,
    onMyProperties: () -> Unit,
    onOpenFavorites: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenTenantProfile: () -> Unit,
    onGo: (ProfilePage) -> Unit,
    onInvite: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember { ProfileRepository() }
    var uploading by remember { mutableStateOf(false) }
    var showPhotoDialog by remember { mutableStateOf(false) }

    val name = user?.name.orEmpty()
    val phone = user?.phone.orEmpty()

    fun uploadPhoto(file: File) {
        val current = user ?: return
        scope.launch {
            uploading = true
            when (val r = repository.uploadAvatar(file)) {
                is ApiResult.Success -> {
                    onUserUpdated(current.copy(avatar = r.data.avatar))
                    Toast.makeText(context, "Photo de profil mise à jour", Toast.LENGTH_SHORT).show()
                }
                is ApiResult.Error -> Toast.makeText(context, r.message, Toast.LENGTH_LONG).show()
            }
            uploading = false
        }
    }

    val takePhoto = rememberCameraCapture { file -> uploadPhoto(file) }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val file = withContext(Dispatchers.IO) { copyUriToCache(context, uri) }
                if (file != null) uploadPhoto(file)
                else Toast.makeText(context, "Impossible de lire cette image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val verificationLabel = when (user?.ownerVerificationStatus) {
        "verified" -> "Identité certifiée ✓"
        "pending" -> "Dossier en cours d'examen"
        "rejected" -> "Dossier refusé — contacte l'administrateur"
        else -> "Dossier non soumis"
    }
    val tenantLabel = when (user?.identityStatus) {
        "verified" -> "Identité vérifiée ✓"
        "submitted" -> "Dossier envoyé — en cours de vérification"
        "rejected" -> "Dossier à corriger"
        else -> "À compléter pour pouvoir réserver"
    }
    val notifSub = if (unreadCount > 0) "$unreadCount nouvelle(s) notification(s)" else "Aucune nouvelle notification"

    val options = buildList {
        if (isOwner) {
            add(ProfileOption(Icons.Default.Apartment, "Mes résidences", "Ajouter et gérer mes annonces", onClick = onMyProperties))
            add(ProfileOption(Icons.Default.VerifiedUser, "Vérification d'identité", verificationLabel, onClick = { onGo(ProfilePage.VERIFICATION) }))
            add(ProfileOption(Icons.Default.Notifications, "Notifications", notifSub, unreadCount, onOpenNotifications))
        } else {
            add(ProfileOption(Icons.Default.Badge, "Mon dossier", tenantLabel, onClick = onOpenTenantProfile))
            add(ProfileOption(Icons.Default.Favorite, "Mes favoris", "Résidences enregistrées", onClick = onOpenFavorites))
            add(ProfileOption(Icons.Default.Notifications, "Notifications", notifSub, unreadCount, onOpenNotifications))
            add(ProfileOption(Icons.Default.CardGiftcard, "Parrainage", "Invitez vos proches", onClick = onInvite))
        }
        add(ProfileOption(Icons.Default.Language, "Langue", "Français", onClick = { onGo(ProfilePage.LANGUAGE) }))
        add(ProfileOption(Icons.Default.HelpOutline, "Aide et support", "FAQ et contact de l'administrateur", onClick = { onGo(ProfilePage.HELP) }))
        add(ProfileOption(Icons.Default.Settings, "Paramètres", "Mes informations, mot de passe", onClick = { onGo(ProfilePage.SETTINGS) }))
    }

    val initials = name.trim().split(" ").filter { it.isNotBlank() }.take(2)
        .joinToString("") { it.first().uppercase() }.ifBlank { "?" }

    Column(modifier = Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Green)
                .statusBarsPadding()
                .padding(20.dp, 26.dp, 20.dp, 46.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(70.dp).clickableNoRipple { showPhotoDialog = true }) {
                Box(
                    modifier = Modifier.size(66.dp).clip(CircleShape).background(Gold),
                    contentAlignment = Alignment.Center
                ) {
                    Text(initials, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    if (!user?.avatar.isNullOrBlank()) {
                        AsyncImage(
                            model = com.abitechnologie.remci.data.network.secureUrl(user?.avatar),
                            contentDescription = "Photo de profil",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    if (uploading) {
                        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
                        }
                    }
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(24.dp)
                        .background(Orange, CircleShape)
                        .border(2.dp, Green, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = "Changer la photo", tint = Color.White, modifier = Modifier.size(12.dp))
                }
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(name.ifBlank { "Mon compte" }, fontSize = 15.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                if (phone.isNotBlank()) Text(phone, fontSize = 11.5.sp, color = Color(0xFFC9D6CD))
                Spacer(Modifier.height(6.dp))
                Badge(if (isOwner) "Propriétaire" else "Locataire", if (isOwner) Orange else Blue)
            }
        }

        Column(modifier = Modifier.padding(horizontal = 18.dp).offset(y = (-28).dp)) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardBg, RoundedCornerShape(18.dp))
                    .padding(4.dp)
            ) {
                options.forEachIndexed { i, o ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickableNoRipple(o.onClick)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(36.dp).background(Color(0xFFF0ECE0), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(o.icon, contentDescription = null, tint = Green, modifier = Modifier.size(16.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(o.label, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                            Text(o.sub, fontSize = 10.5.sp, color = Sub)
                        }
                        if (o.badgeCount > 0) {
                            Box(
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .defaultMinSize(minWidth = 20.dp, minHeight = 20.dp)
                                    .background(Orange, CircleShape)
                                    .padding(horizontal = 5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    if (o.badgeCount > 99) "99+" else o.badgeCount.toString(),
                                    color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Sub, modifier = Modifier.size(16.dp))
                    }
                    if (i < options.size - 1) HorizontalDivider(color = Color(0xFFF5F2E9))
                }
            }

            Spacer(Modifier.height(16.dp))
            OutlinedButton(
                onClick = onLogout,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = OrangeDeep),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(8.dp))
                Text("Se déconnecter", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Spacer(Modifier.height(22.dp))
            Text(
                "REM-CI v${AppConfig.APP_VERSION} · Développé par ABITECHNOLOGIE",
                fontSize = 10.sp, color = Color(0xFFB8B0A0),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(90.dp))
        }
    }

    if (showPhotoDialog) {
        AlertDialog(
            onDismissRequest = { showPhotoDialog = false },
            containerColor = CardBg,
            title = { Text("Photo de profil", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Ink) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PhotoChoice(Icons.Default.PhotoCamera, "Prendre une photo") {
                        showPhotoDialog = false
                        takePhoto()
                    }
                    PhotoChoice(Icons.Default.PhotoLibrary, "Choisir dans la galerie") {
                        showPhotoDialog = false
                        pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPhotoDialog = false }) { Text("Annuler", color = Sub) }
            }
        )
    }
}

@Composable
private fun PhotoChoice(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF7F4EA), RoundedCornerShape(14.dp))
            .clickableNoRipple(onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
    }
}

private fun copyUriToCache(context: Context, uri: Uri): File? {
    return try {
        val dir = File(context.cacheDir, "camera").apply { mkdirs() }
        val file = File(dir, "avatar_${System.currentTimeMillis()}.jpg")
        val input = context.contentResolver.openInputStream(uri) ?: return null
        input.use { source -> file.outputStream().use { target -> source.copyTo(target) } }
        file
    } catch (e: Exception) {
        null
    }
}

/* ------------------------------------------------------------------------------------ */
/*  Sous-écrans                                                                          */
/* ------------------------------------------------------------------------------------ */

@Composable
private fun SubPage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier = Modifier.fillMaxSize().background(Bg)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardBg)
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Retour", tint = Ink)
            }
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = {
                content()
                Spacer(Modifier.height(24.dp))
            }
        )
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(16.dp))
            .border(1.dp, Divider, RoundedCornerShape(16.dp))
            .padding(14.dp),
        content = content
    )
}

/* ---- Langue ---- */

@Composable
private fun LanguagePage(onBack: () -> Unit) {
    SubPage("Langue", onBack) {
        Text(
            "Choisis la langue de l'application.",
            fontSize = 12.5.sp, color = Sub
        )
        InfoCard {
            LanguageRow("Français", "Langue actuelle", selected = true)
            HorizontalDivider(color = Color(0xFFF5F2E9), modifier = Modifier.padding(vertical = 10.dp))
            LanguageRow("English", "Bientôt disponible", selected = false)
            HorizontalDivider(color = Color(0xFFF5F2E9), modifier = Modifier.padding(vertical = 10.dp))
            LanguageRow("Dioula", "Bientôt disponible", selected = false)
        }
        Text(
            "REM-CI est pour l'instant disponible en français. Les autres langues arriveront dans une prochaine mise à jour.",
            fontSize = 11.5.sp, color = Sub, lineHeight = 16.sp
        )
    }
}

@Composable
private fun LanguageRow(name: String, sub: String, selected: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                name, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                color = if (selected) Ink else Ink.copy(alpha = 0.5f)
            )
            Text(sub, fontSize = 11.sp, color = Sub)
        }
        if (selected) {
            Box(Modifier.size(24.dp).background(Green, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Check, contentDescription = "Sélectionnée", tint = Color.White, modifier = Modifier.size(15.dp))
            }
        }
    }
}

/* ---- Aide et support ---- */

private data class Faq(val question: String, val answer: String)

@Composable
private fun HelpPage(isOwner: Boolean, onBack: () -> Unit) {
    val faqs = if (isOwner) listOf(
        Faq(
            "Comment publier ma résidence ?",
            "Soumets d'abord ton dossier d'identité (pièce d'identité prise en photo), puis ajoute ta résidence avec ses photos. L'administrateur REM-CI vérifie ton dossier, te certifie puis active ta résidence."
        ),
        Faq(
            "Pourquoi ma résidence n'est pas visible ?",
            "Une résidence n'est visible des locataires qu'après validation par l'administrateur REM-CI. Contacte-le aux numéros ci-dessus pour accélérer la validation."
        ),
        Faq(
            "Comment je reçois les demandes de réservation ?",
            "Chaque demande apparaît dans l'onglet Réservations et dans tes notifications. Tu peux la confirmer ou la refuser, et appeler ou écrire au locataire sur WhatsApp."
        ),
        Faq(
            "Y a-t-il un paiement dans l'application ?",
            "Non. Le paiement et les derniers détails se règlent directement entre le locataire et toi."
        )
    ) else listOf(
        Faq(
            "Comment réserver une résidence ?",
            "Ouvre une résidence, choisis tes dates et envoie ta demande. Le propriétaire est prévenu ; il confirme ou refuse, et tu peux le contacter par appel ou WhatsApp."
        ),
        Faq(
            "Qui peut réserver ? Pourquoi un dossier ?",
            "Il faut avoir au moins 18 ans. Avant ta première réservation, tu complètes une seule fois ton dossier (Profil > Mon dossier) : identité, date de naissance, adresse, contact et photo de ta pièce d'identité (CNI, passeport, attestation d'identité ou permis). Le propriétaire voit ton nom, ton âge, ta commune et ton contact ; ta pièce reste privée."
        ),
        Faq(
            "Combien de réservations puis-je demander ?",
            "Trois demandes de réservation au maximum par jour avec ton compte. Le compteur s'affiche sur l'écran de réservation et repart à zéro chaque jour."
        ),
        Faq(
            "Dois-je payer dans l'application ?",
            "Non. REM-CI n'encaisse rien : les derniers détails et le paiement se règlent directement avec le propriétaire."
        ),
        Faq(
            "Comment savoir si un propriétaire est fiable ?",
            "Les propriétaires certifiés ont soumis une pièce d'identité vérifiée par l'administrateur REM-CI. Cherche le badge de certification sur l'annonce."
        ),
        Faq(
            "J'ai oublié mon mot de passe",
            "Sur l'écran de connexion, touche « Mot de passe oublié » : un code te sera envoyé par e-mail pour en choisir un nouveau."
        )
    )

    SubPage("Aide et support", onBack) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Green.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Une question ? Un problème ?", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text(
                "L'administrateur REM-CI te répond par téléphone ou sur WhatsApp.",
                fontSize = 11.5.sp, color = Sub
            )
            AdminContactBlock(
                title = null,
                whatsappMessage = "Bonjour, j'ai besoin d'aide sur l'application REM-CI."
            )
        }

        Text("Questions fréquentes", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        faqs.forEach { FaqItem(it) }
    }
}

@Composable
private fun FaqItem(faq: Faq) {
    var open by remember { mutableStateOf(false) }
    InfoCard {
        Row(
            modifier = Modifier.fillMaxWidth().clickableNoRipple { open = !open },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(faq.question, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
            Icon(
                if (open) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                contentDescription = null, tint = Sub
            )
        }
        AnimatedVisibility(visible = open) {
            Text(faq.answer, fontSize = 12.sp, lineHeight = 17.sp, color = Ink.copy(alpha = 0.85f), modifier = Modifier.padding(top = 8.dp))
        }
    }
}

/* ---- Paramètres ---- */

@Composable
private fun SettingsPage(user: UserDto?, onUserUpdated: (UserDto) -> Unit, onAccountDeleted: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember { ProfileRepository() }

    var name by remember(user?.id) { mutableStateOf(user?.name.orEmpty()) }
    var phone by remember(user?.id) { mutableStateOf(user?.phone.orEmpty()) }
    var email by remember(user?.id) { mutableStateOf(user?.email.orEmpty()) }
    var saving by remember { mutableStateOf(false) }
    var infoError by remember { mutableStateOf<String?>(null) }

    var currentPwd by remember { mutableStateOf("") }
    var newPwd by remember { mutableStateOf("") }
    var confirmPwd by remember { mutableStateOf("") }
    var changing by remember { mutableStateOf(false) }
    var pwdError by remember { mutableStateOf<String?>(null) }
    // Propriétaire certifié : nom et numéro verrouillés (ils correspondent à son dossier et à ses annonces)
    val identityLocked = user?.role == "proprietaire" && user.ownerVerificationStatus == "verified"

    // Suppression du compte
    var showDelete by remember { mutableStateOf(false) }
    var deletePwd by remember { mutableStateOf("") }
    var deleteWord by remember { mutableStateOf("") }
    var deleting by remember { mutableStateOf(false) }
    var deleteError by remember { mutableStateOf<String?>(null) }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { if (!deleting) showDelete = false },
            title = { Text("Supprimer mon compte ?", fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Cette action est définitive : ton profil, ta pièce d'identité, tes favoris et ton historique" +
                            (if (user?.role == "proprietaire") ", ainsi que tes résidences et leurs photos," else "") +
                            " seront effacés. Impossible si une réservation est en cours ou à venir.",
                        fontSize = 12.sp, lineHeight = 17.sp, color = Ink
                    )
                    RemField(
                        "Mot de passe", deletePwd, { deletePwd = it; deleteError = null }, Icons.Default.Lock,
                        "Vide si compte créé avec Google", visualTransformation = PasswordVisualTransformation()
                    )
                    RemField(
                        "Écris SUPPRIMER pour confirmer", deleteWord, { deleteWord = it; deleteError = null }, Icons.Default.DeleteForever,
                        "SUPPRIMER"
                    )
                    if (deleteError != null) Text(deleteError!!, color = Danger, fontSize = 11.5.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            deleting = true
                            deleteError = null
                            when (val r = repository.deleteAccount(deletePwd, deleteWord)) {
                                is ApiResult.Success -> {
                                    showDelete = false
                                    Toast.makeText(context, "Ton compte a été supprimé", Toast.LENGTH_LONG).show()
                                    onAccountDeleted()
                                }
                                is ApiResult.Error -> deleteError = r.message
                            }
                            deleting = false
                        }
                    },
                    enabled = !deleting && deleteWord.trim().equals("SUPPRIMER", ignoreCase = true),
                    colors = ButtonDefaults.buttonColors(containerColor = Danger)
                ) {
                    if (deleting) CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                    else Text("Supprimer définitivement", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDelete = false }, enabled = !deleting) { Text("Annuler") }
            }
        )
    }

    SubPage("Paramètres", onBack) {
        Text("Mes informations", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        InfoCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                RemField("Nom complet", name, { name = it; infoError = null }, Icons.Default.Person, "Ton nom", enabled = !identityLocked)
                RemField(
                    "Téléphone", phone, { phone = it; infoError = null }, Icons.Default.Phone, "07 00 00 00 00",
                    keyboardType = KeyboardType.Phone, enabled = !identityLocked
                )
                if (identityLocked) {
                    Text(
                        "Ton identité est certifiée : le nom et le numéro ne se modifient plus ici. " +
                            "Pour les changer, contacte l'administrateur REM-CI au ${com.abitechnologie.remci.data.AppConfig.ADMIN_PHONES_TEXT}.",
                        fontSize = 11.sp, color = Sub, lineHeight = 15.sp
                    )
                }
                RemField(
                    "E-mail", email, { email = it; infoError = null }, Icons.Default.Email, "ton@email.com",
                    keyboardType = KeyboardType.Email
                )
                if (infoError != null) Text(infoError!!, color = OrangeDeep, fontSize = 11.5.sp)
                Button(
                    onClick = {
                        if (name.isBlank() || phone.isBlank()) {
                            infoError = "Le nom et le téléphone sont obligatoires."
                        } else {
                            scope.launch {
                                saving = true
                                infoError = null
                                when (val r = repository.updateProfile(name.trim(), phone.trim(), email.trim())) {
                                    is ApiResult.Success -> {
                                        val current = user
                                        onUserUpdated(
                                            current?.copy(name = r.data.name, phone = r.data.phone, email = r.data.email) ?: r.data
                                        )
                                        Toast.makeText(context, "Informations enregistrées", Toast.LENGTH_SHORT).show()
                                    }
                                    is ApiResult.Error -> infoError = r.message
                                }
                                saving = false
                            }
                        }
                    },
                    enabled = !saving,
                    colors = ButtonDefaults.buttonColors(containerColor = Green),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    if (saving) CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                    else Text("Enregistrer", fontWeight = FontWeight.Bold)
                }
            }
        }

        Text("Sécurité", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        InfoCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                RemField(
                    "Mot de passe actuel", currentPwd, { currentPwd = it; pwdError = null }, Icons.Default.Lock, "••••••",
                    visualTransformation = PasswordVisualTransformation()
                )
                RemField(
                    "Nouveau mot de passe", newPwd, { newPwd = it; pwdError = null }, Icons.Default.Lock, "6 caractères minimum",
                    visualTransformation = PasswordVisualTransformation()
                )
                RemField(
                    "Confirmer le nouveau mot de passe", confirmPwd, { confirmPwd = it; pwdError = null }, Icons.Default.Lock, "••••••",
                    visualTransformation = PasswordVisualTransformation()
                )
                if (pwdError != null) Text(pwdError!!, color = OrangeDeep, fontSize = 11.5.sp)
                Button(
                    onClick = {
                        when {
                            currentPwd.isBlank() -> pwdError = "Saisis ton mot de passe actuel."
                            newPwd.length < 6 -> pwdError = "Le nouveau mot de passe doit avoir au moins 6 caractères."
                            newPwd != confirmPwd -> pwdError = "Les deux mots de passe ne sont pas identiques."
                            else -> scope.launch {
                                changing = true
                                when (val r = repository.changePassword(currentPwd, newPwd, confirmPwd)) {
                                    is ApiResult.Success -> {
                                        currentPwd = ""; newPwd = ""; confirmPwd = ""
                                        Toast.makeText(context, "Mot de passe modifié", Toast.LENGTH_SHORT).show()
                                    }
                                    is ApiResult.Error -> pwdError = r.message
                                }
                                changing = false
                            }
                        }
                    },
                    enabled = !changing,
                    colors = ButtonDefaults.buttonColors(containerColor = Orange),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    if (changing) CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                    else Text("Modifier le mot de passe", fontWeight = FontWeight.Bold)
                }
                Text(
                    "Compte créé avec Google ? Utilise « Mot de passe oublié » sur l'écran de connexion pour en définir un.",
                    fontSize = 10.5.sp, color = Sub, lineHeight = 14.sp
                )
            }
        }

        Text("Confidentialité", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        InfoCard {
            Text(
                "Ton numéro de téléphone n'est partagé qu'avec la personne concernée par une réservation (propriétaire ou locataire) afin que vous puissiez vous contacter. REM-CI ne le vend ni ne le diffuse.",
                fontSize = 12.sp, lineHeight = 17.sp, color = Ink.copy(alpha = 0.85f)
            )
        }

        Text("Informations légales", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        InfoCard {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                com.abitechnologie.remci.ui.components.LegalLinksRow(fontSize = 12.sp)
            }
        }

        Text("Zone sensible", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        InfoCard {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Supprime ton compte et toutes tes données personnelles de REM-CI.",
                    fontSize = 12.sp, lineHeight = 17.sp, color = Ink.copy(alpha = 0.85f)
                )
                OutlinedButton(
                    onClick = { deletePwd = ""; deleteWord = ""; deleteError = null; showDelete = true },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Danger),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Supprimer mon compte", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        Text(
            "REM-CI v${AppConfig.APP_VERSION} · ABITECHNOLOGIE",
            fontSize = 10.sp, color = Color(0xFFB8B0A0),
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
    }
}

/* ---- Vérification d'identité (propriétaire) ---- */

@Composable
private fun VerificationPage(status: String?, onBack: () -> Unit, onSubmit: () -> Unit) {
    val (title, text, color, icon) = when (status) {
        "verified" -> VerifInfo(
            "Identité certifiée",
            "Ton identité est certifiée. L'administrateur peut maintenant activer tes résidences pour qu'elles soient visibles des locataires.",
            Green, Icons.Default.VerifiedUser
        )
        "pending" -> VerifInfo(
            "Dossier en cours d'examen",
            "Ton dossier est bien reçu. Pour accélérer la validation, contacte l'administrateur REM-CI aux numéros ci-dessous.",
            OrangeDeep, Icons.Default.HourglassTop
        )
        "rejected" -> VerifInfo(
            "Dossier refusé",
            "Ton dossier n'a pas pu être validé. Contacte l'administrateur REM-CI pour savoir quoi corriger, puis soumets-le à nouveau.",
            OrangeDeep, Icons.Default.ErrorOutline
        )
        else -> VerifInfo(
            "Dossier non soumis",
            "Soumets ta pièce d'identité pour que l'administrateur REM-CI puisse te certifier et activer tes résidences.",
            Blue, Icons.Default.Info
        )
    }

    SubPage("Vérification d'identité", onBack) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(color.copy(alpha = 0.10f), RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = color)
                Text(text, fontSize = 12.sp, lineHeight = 17.sp, color = Ink, modifier = Modifier.padding(top = 3.dp))
            }
        }

        InfoCard {
            Text("Comment ça marche", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Spacer(Modifier.height(10.dp))
            VerifStep(1, "Tu envoies ton dossier", "Nom, téléphone, adresse et photo de ta pièce d'identité.", done = status != null)
            VerifStep(2, "L'administrateur vérifie", "Il examine ton dossier et te certifie.", done = status == "verified")
            VerifStep(3, "Tes résidences sont activées", "Elles deviennent visibles des locataires.", done = false, last = true)
        }

        if (status != "verified") {
            AdminContactBlock(
                title = "Contacter l'administrateur REM-CI pour la validation",
                whatsappMessage = "Bonjour, je suis propriétaire sur REM-CI et je souhaite la validation de mon dossier."
            )
        }

        if (status == null || status == "rejected") {
            Button(
                onClick = onSubmit,
                colors = ButtonDefaults.buttonColors(containerColor = Orange),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text(if (status == "rejected") "Soumettre à nouveau mon dossier" else "Soumettre mon dossier", fontWeight = FontWeight.Bold)
            }
        }
    }
}

private data class VerifInfo(val title: String, val text: String, val color: Color, val icon: ImageVector)

@Composable
private fun VerifStep(number: Int, title: String, sub: String, done: Boolean, last: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth().padding(bottom = if (last) 0.dp else 12.dp)) {
        Box(
            modifier = Modifier.size(26.dp).background(if (done) Green else Color(0xFFE9E4D4), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (done) Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
            else Text(number.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Sub)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(sub, fontSize = 11.sp, color = Sub, lineHeight = 15.sp)
        }
    }
}
