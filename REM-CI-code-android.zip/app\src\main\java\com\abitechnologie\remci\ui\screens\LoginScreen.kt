package com.abitechnologie.remci.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.filled.Email
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.material3.OutlinedButton
import androidx.compose.foundation.BorderStroke
import com.abitechnologie.remci.R
import com.abitechnologie.remci.data.AppConfig
import com.abitechnologie.remci.ui.components.GoogleSignInResult
import com.abitechnologie.remci.ui.components.requestGoogleIdToken
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.data.network.UserDto
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.AuthRepository
import com.abitechnologie.remci.data.network.TokenManager
import com.abitechnologie.remci.ui.components.LogoMark
import com.abitechnologie.remci.ui.components.clickableNoRipple
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.launch

/**
 * Connexion / création de compte.
 * Le rôle (Locataire / Propriétaire) choisi ici est envoyé au serveur : un compte n'a qu'un
 * seul rôle, donc un mauvais choix est refusé avec un message clair.
 */
@Composable
fun LoginScreen(
    initialRole: String = "locataire",
    /** Ouvre directement l'onglet « Créer un compte » (ex. invité qui clique sur « S'inscrire »). */
    startInRegister: Boolean = false,
    onLogin: (UserDto) -> Unit,
    onGuest: () -> Unit = {},
    onBack: (() -> Unit)? = null,
    onForgotPassword: () -> Unit = {}
) {
    var mode by remember { mutableStateOf(if (startInRegister) "register" else "login") }
    var role by remember { mutableStateOf(initialRole) }
    var showPwd by remember { mutableStateOf(false) }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var googleLoading by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val authRepository = remember { AuthRepository() }
    val focusManager = LocalFocusManager.current
    val context = LocalContext.current
    val isOwner = role == "proprietaire"
    // Première visite sur ce téléphone (aucune connexion réussie avant) : on souhaite la bienvenue.
    val firstVisit = remember { !TokenManager.hasAccountOnDevice() }
    val isRegister = mode == "register"

    fun submit() {
        val cleanPhone = phone.trim()
        val digits = cleanPhone.count { it.isDigit() }
        errorMsg = when {
            isRegister && name.isBlank() -> "Indique ton nom complet."
            !isRegister && cleanPhone.isBlank() -> "Indique ton numéro de téléphone ou ton e-mail."
            isRegister && cleanPhone.isBlank() -> "Indique ton numéro de téléphone."
            isRegister && digits < 10 -> "Numéro de téléphone invalide : 10 chiffres (ex. 07 07 98 28 02)."
            !(cleanPhone.contains("@") && !isRegister) && digits < 8 -> "Ce numéro de téléphone semble incomplet."
            isRegister && email.isBlank() -> "Indique ton adresse e-mail : elle te servira à récupérer ton mot de passe."
            isRegister && !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> "Cette adresse e-mail semble invalide."
            password.isBlank() -> "Saisis ton mot de passe."
            isRegister && password.length < 6 -> "Le mot de passe doit contenir au moins 6 caractères."
            isRegister && password != confirm -> "Les deux mots de passe ne sont pas identiques."
            else -> null
        }
        if (errorMsg != null) return
        focusManager.clearFocus()
        loading = true
        scope.launch {
            val result = if (!isRegister) {
                authRepository.login(cleanPhone, password, role)
            } else {
                authRepository.register(name.trim(), cleanPhone, email.trim().lowercase(), password, role)
            }
            loading = false
            when (result) {
                is ApiResult.Success -> onLogin(result.data)
                is ApiResult.Error -> errorMsg = result.message
            }
        }
    }

    fun signInWithGoogle() {
        if (AppConfig.GOOGLE_WEB_CLIENT_ID.isBlank()) {
            errorMsg = "La connexion Google n'est pas encore configurée dans l'application (AppConfig.GOOGLE_WEB_CLIENT_ID)."
            return
        }
        errorMsg = null
        focusManager.clearFocus()
        googleLoading = true
        scope.launch {
            when (val google = requestGoogleIdToken(context, AppConfig.GOOGLE_WEB_CLIENT_ID)) {
                is GoogleSignInResult.Token -> {
                    when (val result = authRepository.googleLogin(google.idToken, role)) {
                        is ApiResult.Success -> onLogin(result.data)
                        is ApiResult.Error -> errorMsg = result.message
                    }
                }
                is GoogleSignInResult.Failure -> errorMsg = google.message
                GoogleSignInResult.Cancelled -> Unit
            }
            googleLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .imePadding()
            .verticalScroll(rememberScrollState())
    ) {
        // ---------- En-tête de marque ----------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        0f to Color(0xFFFFA43D),
                        0.30f to Orange,
                        0.62f to Color(0xFF2E8354),
                        1f to GreenDeep
                    ),
                    RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
                )
        ) {
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 70.dp, y = (-60).dp)
                    .background(Color.White.copy(alpha = 0.08f), CircleShape)
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp)
                    .padding(top = 10.dp, bottom = 58.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    if (onBack != null) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.size(38.dp).background(Color.White.copy(alpha = 0.2f), CircleShape)
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Retour", tint = Color.White, modifier = Modifier.size(19.dp))
                        }
                    } else {
                        Spacer(Modifier.size(38.dp))
                    }
                }
                LogoMark(size = 120)
                Spacer(Modifier.height(10.dp))
                Text(
                    if (isRegister || firstVisit) "Bienvenue sur REM-CI" else "Bon retour parmi nous",
                    fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White
                )
                Text(
                    if (isOwner) "Espace propriétaire · publie et gère tes résidences"
                    else "Espace locataire · trouve ta résidence meublée",
                    fontSize = 12.sp, color = Color.White.copy(alpha = 0.92f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // ---------- Carte du formulaire (chevauche l'en-tête) ----------
        Surface(
            color = CardBg,
            shape = RoundedCornerShape(24.dp),
            shadowElevation = 8.dp,
            modifier = Modifier
                .padding(horizontal = 18.dp)
                .offset(y = (-34).dp)
                .fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Rôle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF3EFE4), RoundedCornerShape(16.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    RoleSegment("Locataire", Icons.Default.Search, role == "locataire", Modifier.weight(1f)) {
                        role = "locataire"; errorMsg = null
                    }
                    RoleSegment("Propriétaire", Icons.Default.Apartment, role == "proprietaire", Modifier.weight(1f)) {
                        role = "proprietaire"; errorMsg = null
                    }
                }

                Spacer(Modifier.height(18.dp))

                // Connexion / inscription
                Row(modifier = Modifier.fillMaxWidth()) {
                    ModeTab("Se connecter", mode == "login", Modifier.weight(1f)) { mode = "login"; errorMsg = null }
                    ModeTab("Créer un compte", mode == "register", Modifier.weight(1f)) { mode = "register"; errorMsg = null }
                }

                Spacer(Modifier.height(18.dp))

                AnimatedVisibility(
                    visible = isRegister,
                    enter = fadeIn(tween(250)) + expandVertically(tween(250)),
                    exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
                ) {
                    Column {
                        RemField(
                            label = "Nom complet", value = name, onChange = { name = it },
                            leading = Icons.Default.Person, placeholder = "Ex. Aya Kouadio",
                            imeAction = ImeAction.Next,
                            onNext = { focusManager.moveFocus(FocusDirection.Down) }
                        )
                        Spacer(Modifier.height(14.dp))
                    }
                }

                AnimatedVisibility(
                    visible = isRegister,
                    enter = fadeIn(tween(250)) + expandVertically(tween(250)),
                    exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
                ) {
                    Column {
                        RemField(
                            label = "Adresse e-mail", value = email, onChange = { email = it },
                            leading = Icons.Default.Email, placeholder = "toi@gmail.com",
                            keyboardType = KeyboardType.Email, imeAction = ImeAction.Next,
                            onNext = { focusManager.moveFocus(FocusDirection.Down) }
                        )
                        Text(
                            "Utilisée pour récupérer ton mot de passe.",
                            fontSize = 10.5.sp, color = Sub, modifier = Modifier.padding(top = 6.dp, start = 2.dp, bottom = 14.dp)
                        )
                    }
                }

                RemField(
                    label = if (isRegister) "Numéro de téléphone" else "Téléphone ou e-mail",
                    value = phone, onChange = { phone = it },
                    leading = if (isRegister) Icons.Default.Phone else Icons.Default.Person,
                    placeholder = if (isRegister) "07 00 00 00 00" else "07 00 00 00 00 ou toi@gmail.com",
                    keyboardType = if (isRegister) KeyboardType.Phone else KeyboardType.Email,
                    imeAction = ImeAction.Next,
                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                )
                Spacer(Modifier.height(14.dp))

                RemField(
                    label = "Mot de passe", value = password, onChange = { password = it },
                    leading = Icons.Default.Lock, placeholder = "••••••••",
                    keyboardType = KeyboardType.Password,
                    imeAction = if (isRegister) ImeAction.Next else ImeAction.Done,
                    onNext = { focusManager.moveFocus(FocusDirection.Down) },
                    onDone = { submit() },
                    visualTransformation = if (showPwd) VisualTransformation.None else PasswordVisualTransformation(),
                    trailing = {
                        IconButton(onClick = { showPwd = !showPwd }) {
                            Icon(
                                if (showPwd) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = if (showPwd) "Masquer" else "Afficher",
                                tint = Sub, modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                )

                AnimatedVisibility(
                    visible = isRegister,
                    enter = fadeIn(tween(250)) + expandVertically(tween(250)),
                    exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
                ) {
                    Column {
                        Spacer(Modifier.height(14.dp))
                        RemField(
                            label = "Confirmer le mot de passe", value = confirm, onChange = { confirm = it },
                            leading = Icons.Default.Lock, placeholder = "••••••••",
                            keyboardType = KeyboardType.Password, imeAction = ImeAction.Done,
                            onDone = { submit() },
                            visualTransformation = if (showPwd) VisualTransformation.None else PasswordVisualTransformation()
                        )
                        Text(
                            "6 caractères minimum.",
                            fontSize = 10.5.sp, color = Sub, modifier = Modifier.padding(top = 6.dp, start = 2.dp)
                        )
                    }
                }

                if (!isRegister) {
                    Text(
                        "Mot de passe oublié ?",
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Blue,
                        modifier = Modifier
                            .align(Alignment.End)
                            .padding(top = 10.dp)
                            .clickableNoRipple { onForgotPassword() }
                    )
                }

                // Info propriétaire à l'inscription
                AnimatedVisibility(visible = isRegister && isOwner) {
                    Row(
                        modifier = Modifier
                            .padding(top = 14.dp)
                            .fillMaxWidth()
                            .background(Orange.copy(alpha = 0.10f), RoundedCornerShape(14.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = OrangeDeep, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Après l'inscription, tu rempliras un dossier d'identité (pièce d'identité recto/verso). " +
                                "L'équipe REM-CI le vérifie avant de publier tes résidences.",
                            fontSize = 11.sp, lineHeight = 15.5.sp, color = Ink
                        )
                    }
                }

                // Erreur
                AnimatedVisibility(visible = errorMsg != null) {
                    Row(
                        modifier = Modifier
                            .padding(top = 14.dp)
                            .fillMaxWidth()
                            .background(Color(0xFFFDECE4), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = OrangeDeep, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(errorMsg ?: "", color = OrangeDeep, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, lineHeight = 15.sp)
                    }
                }

                Spacer(Modifier.height(18.dp))

                Button(
                    onClick = { submit() },
                    enabled = !loading,
                    colors = ButtonDefaults.buttonColors(containerColor = Orange, disabledContainerColor = Orange.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) {
                    if (loading) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
                    } else {
                        Text(if (isRegister) "Créer mon compte" else "Se connecter", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    }
                }

                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFFEDE8DA))
                    Text("  ou  ", fontSize = 11.sp, color = Sub)
                    HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFFEDE8DA))
                }
                Spacer(Modifier.height(14.dp))

                OutlinedButton(
                    onClick = { signInWithGoogle() },
                    enabled = !loading && !googleLoading,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFFDADCE0)),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White, contentColor = Ink),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    if (googleLoading) {
                        CircularProgressIndicator(color = Blue, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                    } else {
                        Image(painter = painterResource(id = R.drawable.ic_google), contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Continuer avec Google", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    }
                }

                if (!isOwner) {
                    TextButton(onClick = onGuest, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                        Text("Parcourir les résidences sans compte", color = Green, fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                    }
                }
            }
        }

        // ---------- Pied de page ----------
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .offset(y = (-14).dp)
                .navigationBarsPadding()
                .padding(horizontal = 30.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "En continuant, tu acceptes les conditions d'utilisation et la politique de confidentialité de REM-CI.",
                fontSize = 10.5.sp, color = Sub, textAlign = TextAlign.Center, lineHeight = 14.sp
            )
            com.abitechnologie.remci.ui.components.LegalLinksRow()
            Spacer(Modifier.height(10.dp))
            Row {
                Text("UNE TECHNOLOGIE ", fontSize = 9.5.sp, color = Color(0xFFB8B0A0), letterSpacing = 1.sp)
                Text("ABITECHNOLOGIE", fontSize = 9.5.sp, color = Gold, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
private fun RoleSegment(label: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Green else Color.Transparent, tween(200), label = "segBg")
    val fg by animateColorAsState(if (selected) Color.White else Sub, tween(200), label = "segFg")
    Row(
        modifier = modifier
            .background(bg, RoundedCornerShape(12.dp))
            .clickableNoRipple(onClick)
            .padding(vertical = 11.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(7.dp))
        Text(label, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = fg)
    }
}

@Composable
private fun ModeTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val lineColor by animateColorAsState(if (selected) Orange else Color(0xFFEDE8DA), tween(200), label = "tabLine")
    Column(
        modifier = modifier.clickableNoRipple(onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            label,
            fontSize = 13.5.sp,
            fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold,
            color = if (selected) Ink else Sub,
            modifier = Modifier.padding(bottom = 9.dp)
        )
        Box(modifier = Modifier.fillMaxWidth().height(if (selected) 3.dp else 2.dp).background(lineColor, RoundedCornerShape(3.dp)))
    }
}

@Composable
internal fun RemField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    leading: ImageVector,
    placeholder: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next,
    onNext: () -> Unit = {},
    onDone: () -> Unit = {},
    visualTransformation: VisualTransformation = VisualTransformation.None,
    trailing: (@Composable () -> Unit)? = null,
    enabled: Boolean = true
) {
    Column {
        Text(label, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            placeholder = { Text(placeholder, color = Color(0xFFA9ADA6), fontSize = 13.5.sp) },
            leadingIcon = { Icon(leading, contentDescription = null, tint = Green, modifier = Modifier.size(18.dp)) },
            trailingIcon = trailing,
            enabled = enabled,
            singleLine = true,
            visualTransformation = visualTransformation,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
            keyboardActions = KeyboardActions(onNext = { onNext() }, onDone = { onDone() }),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Green,
                unfocusedBorderColor = Color(0xFFE2DCCB),
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color(0xFFFBF9F4),
                cursorColor = Green,
                focusedTextColor = Ink,
                unfocusedTextColor = Ink,
                disabledTextColor = Sub,
                disabledBorderColor = Color(0xFFE2DCCB),
                disabledContainerColor = Color(0xFFF0ECE0),
                disabledLeadingIconColor = Sub
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
