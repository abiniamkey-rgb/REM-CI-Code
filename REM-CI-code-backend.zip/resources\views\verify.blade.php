<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title>Vérification du reçu · REM-CI</title>
  <link rel="icon" type="image/png" href="{{ asset('images/favicon.png') }}">
  @php
    $ok = in_array($state, ['valid', 'upcoming', 'completed'], true);
    $theme = [
      'valid'     => ['#0A6C3B', 'Reçu authentique', 'Réservation confirmée — séjour en cours.'],
      'upcoming'  => ['#0A6C3B', 'Reçu authentique', 'Réservation confirmée — séjour à venir.'],
      'completed' => ['#6B756E', 'Reçu authentique', 'Séjour terminé.'],
      'pending'   => ['#D4880A', 'Réservation non confirmée', "Le propriétaire n'a pas encore confirmé cette demande : ce n'est pas un reçu valable."],
      'invalid'   => ['#C62828', 'Reçu non valable', 'Cette réservation a été annulée, refusée ou a expiré.'],
      'unknown'   => ['#C62828', 'Reçu introuvable', "Aucune réservation REM-CI ne correspond à ce numéro. Le document est peut-être falsifié."],
    ][$state];
  @endphp
  <style>
    *{box-sizing:border-box} body{margin:0;background:#FAF7F0;color:#1B231F;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
    .wrap{max-width:460px;margin:0 auto;padding:22px 16px 40px}
    .logo{display:block;width:120px;height:120px;margin:0 auto 4px}
    .card{background:#fff;border:1px solid #F0ECE0;border-radius:20px;overflow:hidden;box-shadow:0 10px 30px rgba(10,108,59,.08)}
    .head{padding:22px 20px;color:#fff;text-align:center;background:{{ $theme[0] }}}
    .head .ico{width:54px;height:54px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;margin:0 auto 10px;font-size:30px;font-weight:800}
    .head h1{margin:0;font-size:20px} .head p{margin:6px 0 0;font-size:13px;opacity:.92;line-height:1.45}
    .rows{padding:6px 20px 18px} .row{display:flex;justify-content:space-between;gap:14px;padding:11px 0;border-bottom:1px dashed #E5E0D2;font-size:14px}
    .row:last-child{border-bottom:0} .row span{color:#6B756E} .row strong{text-align:right}
    .ref{font-family:ui-monospace,Consolas,monospace;letter-spacing:.5px}
    .foot{text-align:center;color:#6B756E;font-size:11.5px;line-height:1.6;margin-top:18px}
  </style>
</head>
<body>
<div class="wrap">
  <img class="logo" src="{{ asset('images/remci-logo.png') }}" alt="REM-CI">
  <div class="card">
    <div class="head">
      <div class="ico">{{ $ok ? '✓' : '✕' }}</div>
      <h1>{{ $theme[1] }}</h1>
      <p>{{ $theme[2] }}</p>
    </div>
    @if($booking)
    <div class="rows">
      <div class="row"><span>N° de réservation</span><strong class="ref">{{ $booking->reference }}</strong></div>
      <div class="row"><span>Résidence</span><strong>{{ $booking->property?->title }}</strong></div>
      <div class="row"><span>Ville</span><strong>{{ $booking->property?->city?->name }}</strong></div>
      <div class="row"><span>Arrivée</span><strong>{{ $booking->check_in->locale('fr')->translatedFormat('D d M Y') }}</strong></div>
      <div class="row"><span>Départ</span><strong>{{ $booking->check_out->locale('fr')->translatedFormat('D d M Y') }}</strong></div>
      <div class="row"><span>Durée</span><strong>{{ $booking->nights }} nuit(s) · {{ $booking->guests }} voyageur(s)</strong></div>
      <div class="row"><span>Locataire</span><strong>{{ $tenant }}</strong></div>
      @if($booking->confirmed_at)
      <div class="row"><span>Confirmé le</span><strong>{{ $booking->confirmed_at->locale('fr')->translatedFormat('d M Y') }}</strong></div>
      @endif
    </div>
    @endif
  </div>
  <div class="foot">
    Vérification officielle REM-CI · ABITECHNOLOGIE<br>
    Aucun paiement n'est effectué via REM-CI : le séjour se règle directement avec le propriétaire.
  </div>
</div>
</body>
</html>
