package com.abitechnologie.remci.ui.theme

import androidx.compose.ui.graphics.Color

// Palette REM-CI — orange & vert ivoiriens, or du logo, touche bleue (clin d'oeil Moov)
val Orange = Color(0xFFF77F00)
val OrangeDeep = Color(0xFFE0630A)
val Green = Color(0xFF0A6C3B)
val GreenDeep = Color(0xFF063D22)
val Gold = Color(0xFFD4AF37)
val Navy = Color(0xFF0B1B14)
val Blue = Color(0xFF0091D8)
val Danger = Color(0xFFE53935)
val Bg = Color(0xFFFAF7F0)
val CardBg = Color(0xFFFFFFFF)
val Ink = Color(0xFF1B231F)
val Sub = Color(0xFF6B756E)
val Divider = Color(0xFFF0ECE0)
