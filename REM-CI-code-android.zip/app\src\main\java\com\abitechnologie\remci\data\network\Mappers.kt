package com.abitechnologie.remci.data.network

import androidx.compose.ui.graphics.Color
import com.abitechnologie.remci.data.Ad
import com.abitechnologie.remci.data.City
import com.abitechnologie.remci.data.Property
import com.abitechnologie.remci.ui.theme.Blue
import com.abitechnologie.remci.ui.theme.Gold
import com.abitechnologie.remci.ui.theme.Green
import com.abitechnologie.remci.ui.theme.Orange

/**
 * Android refuse le HTTP non chiffré : une image servie en « http:// » par un serveur public
 * (tunnel ngrok, hébergement) est rechargée en « https:// ». Le réseau local reste inchangé.
 */
fun secureUrl(url: String?): String? {
    if (url == null || !url.startsWith("http://")) return url
    val host = url.removePrefix("http://").substringBefore('/').substringBefore(':')
    val local = host == "localhost" || host == "10.0.2.2" || host.startsWith("192.168.") || host.startsWith("10.") ||
        Regex("^172\\.(1[6-9]|2\\d|3[01])\\.").containsMatchIn(host)
    return if (local) url else "https://" + url.removePrefix("http://")
}

fun hexToColor(hex: String?): Color = try {
    if (hex.isNullOrBlank()) Green else Color(android.graphics.Color.parseColor(hex))
} catch (e: Exception) {
    Green
}

fun tagToColor(tag: String?): Color = when {
    tag == null -> Orange
    tag.contains("Promo", true) -> Blue
    tag.contains("cœur", true) || tag.contains("coeur", true) -> Gold
    tag.contains("Nouveau", true) -> Green
    else -> Orange
}

fun CityDto.toUiModel() = City(name = name, count = propertiesCount ?: 0, tone = hexToColor(toneColor))

fun PropertyDto.toUiModel() = Property(
    id = id,
    title = title,
    city = city?.name ?: "",
    price = pricePerNight,
    rating = rating,
    reviews = reviewsCount,
    tag = tag ?: "",
    tagColor = tagToColor(tag),
    beds = beds,
    ownerName = owner?.name,
    ownerPhone = owner?.phone,
    photos = photos?.mapNotNull { secureUrl(it) } ?: emptyList(),
    description = description,
    amenities = amenities?.map { it.name } ?: emptyList(),
    address = address,
    latitude = latitude,
    longitude = longitude,
    bathrooms = bathrooms,
    capacity = capacity,
    ownerVerified = owner?.isVerified == true,
    available = isAvailable != false
)

fun AdDto.toUiModel() = Ad(
    title = title,
    sub = subtitle ?: "",
    colorA = hexToColor(colorA),
    colorB = hexToColor(colorB),
    imageUrl = secureUrl(imageUrl),
    badge = badge,
    propertyId = propertyId
)
