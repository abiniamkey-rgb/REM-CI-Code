<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PropertyResource;
use App\Models\Property;
use Illuminate\Http\Request;

class FavoriteController extends Controller
{
    /** GET /api/favorites */
    public function index(Request $request)
    {
        // Seules les résidences publiées : une annonce en attente ou retirée ne doit pas fuiter par les favoris.
        $favorites = $request->user()->favorites()->where('properties.status', 'active')->with(['city', 'photos'])->get();

        return PropertyResource::collection($favorites);
    }

    /** POST /api/favorites/{property} — ajoute ou retire des favoris */
    public function toggle(Request $request, Property $property)
    {
        $user = $request->user();
        $exists = $user->favorites()->where('properties.id', $property->id)->exists();

        if ($exists) {
            $user->favorites()->detach($property->id);
            return response()->json(['favorite' => false]);
        }

        if ($property->status !== 'active') {
            return response()->json(['message' => 'Résidence introuvable'], 404);
        }

        $user->favorites()->attach($property->id);
        return response()->json(['favorite' => true]);
    }
}
