package com.abitechnologie.remci.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.data.Property
import com.abitechnologie.remci.data.network.AmenityDto
import com.abitechnologie.remci.data.network.CityDto
import com.abitechnologie.remci.data.network.toUiModel
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.PropertyRepository
import com.abitechnologie.remci.ui.components.PropertyCard
import com.abitechnologie.remci.ui.components.clickableNoRipple
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.delay

private const val PRICE_MAX = 200_000f
private const val PRICE_STEP = 5_000f

private val SortOptions = listOf(
    "recent" to "Plus récentes",
    "price_asc" to "Prix croissant",
    "price_desc" to "Prix décroissant",
    "rating" to "Mieux notées"
)

private fun fcfa(n: Int): String = n.toString().reversed().chunked(3).joinToString(" ").reversed()

/**
 * Onglet Recherche — recherche libre (titre, quartier, ville) + filtres avancés appliqués
 * côté serveur : ville, budget par nuit, nombre de pièces, voyageurs, commodités, tri.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
    favorites: Set<Int>,
    onToggleFavorite: (Int) -> Unit,
    onOpenProperty: (Property) -> Unit
) {
    val repository = remember { PropertyRepository() }
    val focusManager = LocalFocusManager.current

    var query by remember { mutableStateOf("") }
    var city by remember { mutableStateOf<CityDto?>(null) }
    var priceRange by remember { mutableStateOf(0f..PRICE_MAX) }
    var rooms by remember { mutableStateOf(0) }
    var guests by remember { mutableStateOf(0) }
    var selectedAmenities by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var sort by remember { mutableStateOf("recent") }
    var showFilters by remember { mutableStateOf(false) }
    var reload by remember { mutableStateOf(0) }

    var cities by remember { mutableStateOf<List<CityDto>>(emptyList()) }
    var amenities by remember { mutableStateOf<List<AmenityDto>>(emptyList()) }
    var results by remember { mutableStateOf<List<Property>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    // Listes de choix (villes, commodités) — chargées une seule fois
    LaunchedEffect(Unit) {
        val c = repository.getCities()
        if (c is ApiResult.Success) cities = c.data.sortedBy { it.name }
        val a = repository.getAmenities()
        if (a is ApiResult.Success) amenities = a.data
    }

    // Recherche : relancée à chaque changement, avec un léger délai pendant la saisie
    LaunchedEffect(query, city, priceRange, rooms, guests, selectedAmenities, sort, reload) {
        delay(350)
        loading = true
        error = null
        val result = repository.searchProperties(
            search = query.trim(),
            citySlug = city?.slug,
            minPrice = priceRange.start.toInt().takeIf { it > 0 },
            maxPrice = priceRange.endInclusive.toInt().takeIf { priceRange.endInclusive < PRICE_MAX },
            minRooms = rooms.takeIf { it > 0 },
            guests = guests.takeIf { it > 0 },
            amenityIds = selectedAmenities.toList(),
            sort = sort.takeIf { it != "recent" }
        )
        when (result) {
            is ApiResult.Success -> results = result.data.map { it.toUiModel() }
            is ApiResult.Error -> error = result.message
        }
        loading = false
    }

    val priceChanged = priceRange.start > 0f || priceRange.endInclusive < PRICE_MAX
    val activeFilters = listOf(city != null, priceChanged, rooms > 0, guests > 0).count { it } + selectedAmenities.size

    fun resetFilters() {
        city = null
        priceRange = 0f..PRICE_MAX
        rooms = 0
        guests = 0
        selectedAmenities = emptySet()
    }

    Column(modifier = Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())) {
        // ---------- En-tête ----------
        Column(modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp)) {
            Text("Rechercher", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text("Trouve la résidence qui te convient", fontSize = 12.sp, color = Sub, modifier = Modifier.padding(top = 2.dp))
        }

        // ---------- Barre de recherche + bouton filtres ----------
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .background(CardBg, RoundedCornerShape(16.dp))
                    .border(1.dp, Divider, RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, contentDescription = null, tint = Green, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 13.5.sp, color = Ink),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        if (query.isEmpty()) Text("Quartier, ville ou nom de résidence", fontSize = 13.sp, color = Color(0xFF9AA39C))
                        inner()
                    }
                )
                if (query.isNotEmpty()) {
                    Icon(
                        Icons.Default.Close, contentDescription = "Effacer", tint = Sub,
                        modifier = Modifier.size(18.dp).clickableNoRipple { query = "" }
                    )
                }
            }

            Box {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .background(if (showFilters || activeFilters > 0) Green else CardBg, RoundedCornerShape(16.dp))
                        .border(1.dp, if (showFilters || activeFilters > 0) Green else Divider, RoundedCornerShape(16.dp))
                        .clickableNoRipple { showFilters = !showFilters },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Tune, contentDescription = "Filtres",
                        tint = if (showFilters || activeFilters > 0) Color.White else Ink,
                        modifier = Modifier.size(21.dp)
                    )
                }
                if (activeFilters > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(18.dp)
                            .background(Orange, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text("$activeFilters", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.ExtraBold) }
                }
            }
        }

        // ---------- Tri rapide ----------
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(SortOptions) { (key, label) ->
                SelectChip(label, sort == key) { sort = key }
            }
        }

        // ---------- Panneau de filtres ----------
        AnimatedVisibility(
            visible = showFilters,
            enter = fadeIn(tween(200)) + expandVertically(tween(250)),
            exit = fadeOut(tween(150)) + shrinkVertically(tween(200))
        ) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .padding(top = 14.dp)
                    .fillMaxWidth()
                    .background(CardBg, RoundedCornerShape(22.dp))
                    .border(1.dp, Divider, RoundedCornerShape(22.dp))
                    .padding(16.dp)
            ) {
                FilterTitle("Ville")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { SelectChip("Toutes", city == null) { city = null } }
                    items(cities) { c -> SelectChip(c.name, city?.id == c.id) { city = c } }
                }

                Spacer(Modifier.height(18.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    FilterTitle("Budget par nuit")
                    Text(
                        "${fcfa(priceRange.start.toInt())} – ${if (priceRange.endInclusive >= PRICE_MAX) "${fcfa(PRICE_MAX.toInt())}+" else fcfa(priceRange.endInclusive.toInt())} FCFA",
                        fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Green
                    )
                }
                RangeSlider(
                    value = priceRange,
                    onValueChange = { priceRange = it },
                    valueRange = 0f..PRICE_MAX,
                    steps = (PRICE_MAX / PRICE_STEP).toInt() - 1,
                    colors = SliderDefaults.colors(
                        thumbColor = Green,
                        activeTrackColor = Green,
                        inactiveTrackColor = Color(0xFFE9E4D6),
                        activeTickColor = Color.Transparent,
                        inactiveTickColor = Color.Transparent
                    )
                )

                Spacer(Modifier.height(10.dp))
                FilterTitle("Nombre de pièces")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "Tous", 1 to "1+", 2 to "2+", 3 to "3+", 4 to "4+").forEach { (v, label) ->
                        SelectChip(label, rooms == v) { rooms = v }
                    }
                }

                Spacer(Modifier.height(18.dp))
                FilterTitle("Voyageurs")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "Tous", 2 to "2+", 4 to "4+", 6 to "6+", 8 to "8+").forEach { (v, label) ->
                        SelectChip(label, guests == v) { guests = v }
                    }
                }

                if (amenities.isNotEmpty()) {
                    Spacer(Modifier.height(18.dp))
                    FilterTitle("Commodités")
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        amenities.forEach { a ->
                            val on = selectedAmenities.contains(a.id)
                            SelectChip(a.name, on) {
                                selectedAmenities = if (on) selectedAmenities - a.id else selectedAmenities + a.id
                            }
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .border(1.dp, Color(0xFFE2DCCB), RoundedCornerShape(14.dp))
                            .clickableNoRipple { resetFilters() },
                        contentAlignment = Alignment.Center
                    ) { Text("Réinitialiser", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Sub) }
                    Box(
                        modifier = Modifier
                            .weight(1.4f)
                            .height(46.dp)
                            .background(Orange, RoundedCornerShape(14.dp))
                            .clickableNoRipple { showFilters = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (loading) "Recherche…" else "Voir ${results.size} résultat${if (results.size > 1) "s" else ""}",
                            fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = Color.White
                        )
                    }
                }
            }
        }

        // ---------- Résultats ----------
        Spacer(Modifier.height(18.dp))
        Row(
            modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                when {
                    loading -> "Recherche en cours…"
                    error != null -> "Résultats indisponibles"
                    results.isEmpty() -> "Aucun résultat"
                    else -> "${results.size} résidence${if (results.size > 1) "s" else ""} trouvée${if (results.size > 1) "s" else ""}"
                },
                fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Ink
            )
            if (activeFilters > 0) {
                Text(
                    "Effacer les filtres", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = Blue,
                    modifier = Modifier.clickableNoRipple { resetFilters() }
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        when {
            loading && results.isEmpty() -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Orange, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
            }

            error != null -> EmptyState(
                icon = { Icon(Icons.Default.CloudOff, contentDescription = null, tint = OrangeDeep, modifier = Modifier.size(30.dp)) },
                tint = OrangeDeep,
                title = "Connexion impossible",
                text = error ?: "",
                action = "Réessayer",
                onAction = { reload++ }
            )

            results.isEmpty() -> EmptyState(
                icon = { Icon(Icons.Default.Apartment, contentDescription = null, tint = Green, modifier = Modifier.size(30.dp)) },
                tint = Green,
                title = "Aucune résidence ne correspond",
                text = if (activeFilters > 0 || query.isNotBlank())
                    "Essaie d'élargir ton budget, de retirer une commodité ou de changer de ville."
                else
                    "Les résidences sont publiées après vérification par l'équipe REM-CI. Reviens très bientôt !",
                action = if (activeFilters > 0) "Effacer les filtres" else null,
                onAction = { resetFilters() }
            )

            else -> Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                results.chunked(2).forEach { rowItems ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        rowItems.forEach { p ->
                            PropertyCard(
                                property = p,
                                isFavorite = favorites.contains(p.id),
                                onOpen = onOpenProperty,
                                onToggleFavorite = onToggleFavorite,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun FilterTitle(text: String) {
    Text(text, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = Ink, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
private fun SelectChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        fontSize = 12.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        color = if (selected) Color.White else Ink,
        modifier = Modifier
            .background(if (selected) Green else Color(0xFFFBF9F4), RoundedCornerShape(20.dp))
            .border(1.dp, if (selected) Green else Color(0xFFE2DCCB), RoundedCornerShape(20.dp))
            .clickableNoRipple(onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun EmptyState(
    icon: @Composable () -> Unit,
    tint: Color,
    title: String,
    text: String,
    action: String?,
    onAction: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(66.dp).background(tint.copy(alpha = 0.09f), RoundedCornerShape(22.dp)),
            contentAlignment = Alignment.Center
        ) { icon() }
        Spacer(Modifier.height(14.dp))
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Ink, textAlign = TextAlign.Center)
        Text(
            text, fontSize = 12.sp, lineHeight = 17.sp, color = Sub, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp)
        )
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            Text(
                action, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = Color.White,
                modifier = Modifier
                    .background(Orange, RoundedCornerShape(14.dp))
                    .clickableNoRipple(onAction)
                    .padding(horizontal = 22.dp, vertical = 11.dp)
            )
        }
    }
}
