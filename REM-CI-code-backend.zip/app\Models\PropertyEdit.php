<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** Journal des modifications faites par un propriétaire sur une résidence déjà créée. */
class PropertyEdit extends Model
{
    protected $fillable = [
        'property_id', 'user_id', 'field', 'old_value', 'new_value',
        'flagged', 'flag_reason', 'reviewed_at', 'reverted_at',
    ];

    protected $casts = [
        'flagged' => 'boolean',
        'reviewed_at' => 'datetime',
        'reverted_at' => 'datetime',
    ];

    public function property()
    {
        return $this->belongsTo(Property::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function fieldLabel(): string
    {
        return $this->field === 'amenities' ? 'Commodités' : 'Description';
    }
}
