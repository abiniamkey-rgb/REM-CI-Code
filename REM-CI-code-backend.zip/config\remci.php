<?php

return [
    // Numéros de l'administrateur REM-CI (validation des propriétaires et des résidences).
    // Affichés dans l'app et dans les notifications.
    'admin_phones' => ['07 07 98 28 02', '01 70 69 26 33'],

    // Coordonnées affichées sur les pages légales (confidentialité, conditions, suppression).
    'company' => 'ABITECHNOLOGIE',
    'contact_email' => 'abitechnologie@outlook.fr',
    'legal_updated_at' => '18 octobre 2026',
];
