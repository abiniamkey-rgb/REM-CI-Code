<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Amenity;

class AmenityController extends Controller
{
    /** GET /api/amenities — toute la liste, pour le sélecteur de commodités du formulaire résidence. */
    public function index()
    {
        return Amenity::orderBy('name')->get(['id', 'name', 'icon']);
    }
}
