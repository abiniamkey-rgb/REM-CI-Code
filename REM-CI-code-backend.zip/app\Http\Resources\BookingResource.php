<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BookingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        // Adresse de base pour le lien du code QR (toujours en https en production)
        $base = app()->isProduction()
            ? 'https://'.$request->getHttpHost()
            : $request->getSchemeAndHttpHost();

        return [
            'id' => $this->id,
            'reference' => $this->reference,
            'confirmed_at' => $this->confirmed_at,
            // Page publique de vérification du reçu, encodée dans le code QR
            'receipt_url' => $this->reference && in_array($this->display_status, ['confirmed', 'completed'], true)
                ? $base.'/verifier/'.$this->reference
                : null,
            'check_in' => $this->check_in->toDateString(),
            'check_out' => $this->check_out->toDateString(),
            'guests' => $this->guests,
            'nights' => $this->nights,
            'price_per_night' => $this->price_per_night,
            'service_fee' => $this->service_fee,
            'total_price' => $this->total_price,
            'status' => $this->display_status,
            'payment_method' => $this->payment_method,
            'payment_status' => $this->payment_status,
            'property' => new PropertyResource($this->whenLoaded('property')),
            // Locataire qui a fait la demande — visible côté propriétaire pour le recontacter
            'tenant' => $this->whenLoaded('user', fn () => [
                'name' => $this->user->name,
                'phone' => $this->user->phone,
                // L'adresse personnelle du locataire n'est pas transmise au propriétaire (données minimales).
                'age' => $this->user->age(),
                // La pièce d'identité elle-même n'est jamais montrée au propriétaire.
                'identity_provided' => $this->user->hasTenantProfile(),
                'identity_verified' => $this->user->identity_status === 'verified',
            ]),
            'created_at' => $this->created_at,
        ];
    }
}
