package com.abitechnologie.remci.data.network

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    // --- Auth ---
    @POST("register")
    suspend fun register(@Body body: RegisterRequest): Response<AuthResponse>

    @POST("login")
    suspend fun login(@Body body: LoginRequest): Response<AuthResponse>

    @POST("auth/google")
    suspend fun googleLogin(@Body body: GoogleLoginRequest): Response<AuthResponse>

    @POST("password/forgot")
    suspend fun forgotPassword(@Body body: ForgotPasswordRequest): Response<ForgotPasswordResponse>

    @POST("password/reset")
    suspend fun resetPassword(@Body body: ResetPasswordRequest): Response<MessageResponse>

    @POST("logout")
    suspend fun logout(): Response<MessageResponse>

    @GET("me")
    suspend fun me(): Response<DataWrapper<UserDto>>

    // --- Profil ---
    @PATCH("profile")
    suspend fun updateProfile(@Body body: Map<String, String>): Response<DataWrapper<UserDto>>

    @Multipart
    @POST("profile/avatar")
    suspend fun uploadAvatar(@Part avatar: MultipartBody.Part): Response<DataWrapper<UserDto>>

    @PUT("profile/password")
    suspend fun changePassword(@Body body: ChangePasswordRequest): Response<MessageResponse>

    /** Suppression définitive du compte (DELETE avec corps JSON). */
    @HTTP(method = "DELETE", path = "profile", hasBody = true)
    suspend fun deleteAccount(@Body body: DeleteAccountRequest): Response<MessageResponse>

    // --- Notifications ---
    @GET("notifications")
    suspend fun getNotifications(): Response<NotificationsResponse>

    @POST("notifications/read-all")
    suspend fun readAllNotifications(): Response<MessageResponse>

    // --- Villes & publicités ---
    @GET("cities")
    suspend fun getCities(): Response<ListWrapper<CityDto>>

    @GET("ads")
    suspend fun getAds(): Response<ListWrapper<AdDto>>

    @GET("amenities")
    suspend fun getAmenities(): Response<List<AmenityDto>>

    // --- Résidences ---
    @GET("properties")
    suspend fun getProperties(
        @Query("city") city: String? = null,
        @Query("search") search: String? = null,
        @Query("min_price") minPrice: Int? = null,
        @Query("max_price") maxPrice: Int? = null,
        @Query("featured") featured: Boolean? = null,
        @Query("min_rooms") minRooms: Int? = null,
        @Query("guests") guests: Int? = null,
        @Query("amenity_ids") amenityIds: String? = null,
        @Query("sort") sort: String? = null,
        @Query("per_page") perPage: Int? = null
    ): Response<ListWrapper<PropertyDto>>

    /** Périodes déjà réservées (demandes en attente ou confirmées) — pour avertir avant l'envoi. */
    @GET("properties/{id}/availability")
    suspend fun getAvailability(@Path("id") id: Int): Response<ListWrapper<BookedRangeDto>>

    @GET("properties/{id}")
    suspend fun getProperty(@Path("id") id: Int): Response<DataWrapper<PropertyDto>>

    @POST("properties")
    suspend fun createProperty(@Body body: CreatePropertyRequest): Response<DataWrapper<PropertyDto>>

    /** Propriétaire — corrige son annonce, même déjà publiée. */
    @PATCH("properties/{id}")
    suspend fun updateProperty(@Path("id") id: Int, @Body body: UpdatePropertyRequest): Response<DataWrapper<PropertyDto>>

    /** Propriétaire — déclare sa résidence disponible (true) ou occupée (false). */
    @PATCH("properties/{id}/availability")
    suspend fun setAvailability(@Path("id") id: Int, @Body body: Map<String, Boolean>): Response<DataWrapper<PropertyDto>>

    @GET("my-properties")
    suspend fun getMyProperties(): Response<ListWrapper<PropertyDto>>

    /** Photos prises avec l'appareil photo — jamais depuis la galerie. */
    @Multipart
    @POST("properties/{id}/photos")
    suspend fun uploadPropertyPhotos(
        @Path("id") id: Int,
        @Part photos: List<MultipartBody.Part>
    ): Response<DataWrapper<PropertyDto>>

    // --- Réservations (plus de paiement en ligne : contact direct du propriétaire) ---
    @GET("bookings")
    suspend fun getBookings(): Response<ListWrapper<BookingDto>>

    @POST("bookings")
    suspend fun createBooking(@Body body: BookingRequest): Response<DataWrapper<BookingDto>>

    @PATCH("bookings/{id}/cancel")
    suspend fun cancelBooking(@Path("id") id: Int): Response<DataWrapper<BookingDto>>

    // --- Dossier locataire (identité, âge, adresse, pièce d'identité) ---
    @GET("tenant/profile")
    suspend fun getTenantProfile(): Response<DataWrapper<UserDto>>

    @Multipart
    @POST("tenant/profile")
    suspend fun submitTenantProfile(
        @Part("name") name: RequestBody,
        @Part("phone") phone: RequestBody,
        @Part("address") address: RequestBody,
        @Part("birth_date") birthDate: RequestBody,
        @Part("identity_type") identityType: RequestBody,
        @Part("identity_number") identityNumber: RequestBody,
        @Part idDocumentRecto: MultipartBody.Part?,
        @Part idDocumentVerso: MultipartBody.Part?
    ): Response<DataWrapper<UserDto>>

    // --- Favoris ---
    @GET("favorites")
    suspend fun getFavorites(): Response<ListWrapper<PropertyDto>>

    @POST("favorites/{propertyId}")
    suspend fun toggleFavorite(@Path("propertyId") propertyId: Int): Response<FavoriteToggleResponse>

    // --- Tableau de bord propriétaire : réservations reçues ---
    @GET("owner/bookings")
    suspend fun getOwnerBookings(): Response<ListWrapper<BookingDto>>

    @PATCH("owner/bookings/{id}")
    suspend fun updateOwnerBooking(@Path("id") id: Int, @Body body: Map<String, String>): Response<DataWrapper<BookingDto>>

    // --- Vérification d'identité du propriétaire ---
    @GET("owner/verification")
    suspend fun getOwnerVerification(): Response<DataWrapper<UserDto>>

    @Multipart
    @POST("owner/verification")
    suspend fun submitOwnerVerification(
        @Part("name") name: RequestBody,
        @Part("phone") phone: RequestBody,
        @Part("address") address: RequestBody,
        @Part("detected_name") detectedName: RequestBody?,
        @Part("detected_id_number") detectedIdNumber: RequestBody?,
        @Part idDocumentRecto: MultipartBody.Part,
        @Part idDocumentVerso: MultipartBody.Part
    ): Response<DataWrapper<UserDto>>
}
