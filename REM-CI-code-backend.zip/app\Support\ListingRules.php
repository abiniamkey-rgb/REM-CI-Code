<?php

namespace App\Support;

/**
 * Règles de publication REM-CI (usage interne — ne pas exposer le détail aux propriétaires).
 *
 * 1. Toutes les annonces s'intitulent « Résidence meublée <nom> » : le préfixe est imposé ici,
 *    quel que soit le texte envoyé par l'app.
 * 2. REM-CI est réservé aux résidences meublées de particuliers : les textes typiques d'un
 *    établissement hôtelier sont refusés (titre) ou signalés à l'administrateur (description).
 *    Le message renvoyé reste volontairement neutre pour ne pas indiquer comment contourner le filtre.
 */
class ListingRules
{
    public const TITLE_PREFIX = 'Résidence meublée';

    /** Message neutre affiché au propriétaire en cas de refus. */
    public static function refusalMessage(): string
    {
        return 'ne respecte pas les conditions de publication de REM-CI. Modifie le texte ou contacte l\'administrateur au '
            .\App\Models\UserNotification::adminContacts().'.';
    }

    /** « studio cocody » ou « résidence meublée studio cocody » → « Résidence meublée studio cocody ». */
    public static function normalizeTitle(?string $input): string
    {
        $name = self::nameOf((string) $input);

        return $name === '' ? '' : self::TITLE_PREFIX.' '.$name;
    }

    /** Partie libre du titre (sans le préfixe, même saisi en double ou sans accents). */
    public static function nameOf(string $title): string
    {
        $name = trim(preg_replace('/\s+/u', ' ', $title) ?? $title);
        $pattern = '/^(?:la\s+|une\s+)?r[eéèê]sidences?[\s\-]+meubl[eéèê]e?s?(?=[\s:\-–—,.]|$)\s*[:\-–—,.]?\s*/iu';
        for ($i = 0; $i < 3 && preg_match($pattern, $name); $i++) {
            $name = trim(preg_replace($pattern, '', $name, 1) ?? $name);
        }

        return mb_substr($name, 0, 200);
    }

    /**
     * Contrôle « établissement hôtelier ».
     * @return array{blocked: bool, flags: string[]}
     */
    public static function screen(?string $text, string $field): array
    {
        $result = ['blocked' => false, 'flags' => []];
        if ($text === null || trim($text) === '') {
            return $result;
        }
        $t = self::plain($text);

        $hotelWords = '(?:hotels?|motels?|auberges?|hostels?|apparthotels?|appart[\s\-]*hotels?|hoteli[eè]re?s?|hotellerie|resorts?|guest[\s\-]*house|maisons?\s+d.?hotes|chambres?\s+d.?hotes|lodges?)';

        if ($field === 'title') {
            if (preg_match('/\b'.$hotelWords.'\b/u', $t)) {
                $result['blocked'] = true;
                $result['flags'][] = 'Titre évoquant un établissement hôtelier';
            }

            return $result;
        }

        // Description : formulations propres à un hôtel → refus ; simple mention (repère « près de l'hôtel Ivoire ») → signalement.
        $strong = '/\b(?:notre|cet|mon)\s+(?:hotel|motel|auberge|etablissement\s+hotelier|complexe\s+hotelier)\b'
            .'|\bappart[\s\-]*hotel|\bapparthotel|\bresidence\s+hoteliere|\bcomplexe\s+hotelier|\betablissement\s+hotelier|\bmotel\b/u';
        if (preg_match($strong, $t)) {
            $result['blocked'] = true;
            $result['flags'][] = 'Description d\'établissement hôtelier';

            return $result;
        }

        $soft = [
            '/\b'.$hotelWords.'\b/u' => 'mention d\'hôtel (peut être un simple repère)',
            '/reception\s*(?:24|ouverte|disponible)/u' => 'réception 24h',
            '/room[\s\-]*service|service\s+(?:de\s+)?chambre/u' => 'service en chambre',
            '/petit[\s\-]*dejeuner\s+(?:inclus|offert|compris)/u' => 'petit-déjeuner inclus',
            '/\bpar\s+chambre\b|\bnos\s+chambres\b|\bchambres?\s+(?:n|no|numero)\s*°?\s*\d/u' => 'location à la chambre',
            '/\b\d+\s+chambres\s+(?:disponibles|libres)\b/u' => 'plusieurs chambres à louer',
            '/\b[1-5]\s*etoiles?\b/u' => 'classement en étoiles',
            '/\bsuites?\s+(?:junior|deluxe|executive|presidentielle)|\bchambres?\s+(?:standard|deluxe|superieure)/u' => 'catégories de chambres',
        ];
        foreach ($soft as $re => $label) {
            if (preg_match($re, $t)) {
                $result['flags'][] = 'Possible hôtel : '.$label;
            }
        }

        return $result;
    }

    /** Minuscules, sans accents. */
    private static function plain(string $text): string
    {
        $text = mb_strtolower($text, 'UTF-8');

        return strtr($text, [
            'à' => 'a', 'â' => 'a', 'ä' => 'a', 'á' => 'a', 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
            'î' => 'i', 'ï' => 'i', 'ô' => 'o', 'ö' => 'o', 'ù' => 'u', 'û' => 'u', 'ü' => 'u', 'ç' => 'c',
            '’' => "'", 'œ' => 'oe',
        ]);
    }
}
