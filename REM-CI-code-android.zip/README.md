   # REM-CI — Application Android (Kotlin + Jetpack Compose)

**Résidence meublée en Côte d'Ivoire.** *La clé de votre séjour en Côte d'Ivoire.*
Développé par **ABITECHNOLOGIE**.

## Ce que contient ce projet

Un projet Android Studio complet et fonctionnel :
- Écran de démarrage animé (splash) avec le vrai logo REM-CI
- Connexion / création de compte (Locataire / Propriétaire, Google, OTP SMS, invité)
- Accueil : recherche, bandeau publicitaire rotatif, villes de Côte d'Ivoire, résidences
- Fiche résidence détaillée
- Réservation avec Orange Money, Moov Money, MTN MoMo, Wave, carte bancaire
- Confirmation de réservation
- Profil avec 10 options (réservations, favoris, paiements, KYC, devenir hôte...)
- Navigation bas d'écran à 5 onglets
- Ton vrai logo (`res/drawable/logo.png`) déjà intégré comme icône d'app et dans le splash

## Prérequis

1. **Android Studio** (édition *Koala* ou plus récente) : https://developer.android.com/studio
2. **JDK 17** (généralement inclus avec Android Studio)
3. Une connexion internet la première fois (pour que Gradle télécharge les dépendances)

## Étapes pour obtenir ton APK

1. Ouvre Android Studio → **Open** → sélectionne le dossier `RemCiAndroid`
2. Laisse Gradle synchroniser le projet (première fois : quelques minutes)
3. Branche un téléphone Android (mode développeur + débogage USB activé) **ou** lance un émulateur depuis *Device Manager*
4. Clique sur **Run ▶** pour tester l'app directement
5. Pour générer l'APK à partager : menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
   → l'APK se trouve dans `app/build/outputs/apk/debug/app-debug.apk`
6. Pour une version signée destinée au Play Store : **Build → Generate Signed Bundle / APK**

## Prochaines étapes recommandées pour une app 100% prête pour la production

- **Backend réel** : brancher un serveur (Firebase, Supabase ou API Node/Laravel) pour gérer utilisateurs, résidences, réservations et paiements en temps réel — actuellement les données sont statiques (`data/Models.kt`) pour la démo
- **Paiements** : intégrer les SDK officiels Orange Money, MTN MoMo, Moov Money et Wave (ou un agrégateur comme CinetPay/PayDunya, très utilisés en Côte d'Ivoire)
- **Authentification** : Firebase Auth ou backend avec OTP SMS réel
- **Photos réelles** : remplacer les blocs de couleur des cartes résidences par de vraies photos (Coil pour le chargement d'images)
- **Notifications push** : Firebase Cloud Messaging pour les rappels de réservation et promos
- **Polices** : pour un rendu identique à la maquette, télécharge *Poppins* et *Inter* sur Google Fonts, place les fichiers `.ttf` dans `res/font/` et mets à jour `ui/theme/Type.kt`
- **Publication** : créer un compte Google Play Console (25$ à vie) pour publier l'app

## Structure du projet

```
app/src/main/java/com/abitechnologie/remci/
├── MainActivity.kt
├── data/Models.kt              → villes, résidences, publicités
├── navigation/NavGraph.kt      → toutes les routes de l'app
├── ui/theme/                   → couleurs, typographie
├── ui/components/               → logo, cartes, badges, barre de nav
└── ui/screens/                  → Splash, Login, Home, Detail, Booking, Success, Profile...
```

Toute l'app est écrite en Jetpack Compose (déclaratif, comme React), donc si tu as suivi la version web précédente, la logique des écrans te sera familière.
