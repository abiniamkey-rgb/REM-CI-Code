<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public const STATUSES = [
        'pending' => 'À traiter',
        'confirmed' => 'Confirmées',
        'completed' => 'Terminées',
        'cancelled' => 'Annulées',
        'expired' => 'Expirées',
    ];

    public function index(Request $request)
    {
        Booking::expireStale();
        $status = $request->query('statut', 'all');

        $bookings = Booking::with(['user', 'property.owner'])
            ->when($status === 'expired', fn ($q) => $q->whereNotNull('expired_at'))
            ->when($status === 'cancelled', fn ($q) => $q->where('status', 'cancelled')->whereNull('expired_at'))
            ->when(in_array($status, ['pending', 'confirmed', 'completed'], true), fn ($q) => $q->where('status', $status))
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $counts = Booking::selectRaw("CASE WHEN expired_at IS NOT NULL THEN 'expired' ELSE status END as s, count(*) as c")->groupBy('status')->pluck('c', 's');

        return view('admin.bookings.index', [
            'bookings' => $bookings,
            'status' => $status,
            'counts' => $counts,
            'statuses' => self::STATUSES,
        ]);
    }
}
