<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title>Connexion · Administration REM-CI</title>
  @include('admin._styles')
</head>
<body>
  <div class="login">
    <div style="text-align:center;margin-bottom:18px">
      <div style="font-size:30px;font-weight:800">REM<span style="color:var(--orange)">-</span>CI</div>
      <div class="sub">Espace administrateur</div>
    </div>
    <div class="card">
      <form method="POST" action="{{ route('admin.login.submit') }}">
        @csrf
        <label for="identifier">Téléphone ou e-mail</label>
        <input id="identifier" type="text" name="identifier" value="{{ old('identifier') }}" autocomplete="username" autofocus required>
        <label for="password">Mot de passe</label>
        <input id="password" type="password" name="password" autocomplete="current-password" required>
        @if($errors->any())<div class="err-text">{{ $errors->first() }}</div>@endif
        <label style="font-weight:500;display:flex;gap:8px;align-items:center;margin-top:14px"><input type="checkbox" name="remember" value="1" style="width:auto"> Rester connecté</label>
        <button class="btn" type="submit" style="width:100%;margin-top:16px">Se connecter</button>
      </form>
    </div>
  </div>
</body>
</html>
