package com.abitechnologie.remci.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.abitechnologie.remci.data.Property
import com.abitechnologie.remci.data.network.UserDto
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.ProfileRepository
import com.abitechnologie.remci.ui.components.GuestGateDialog
import com.abitechnologie.remci.ui.components.GuestGateScreen
import com.abitechnologie.remci.ui.components.GuestMessages
import com.abitechnologie.remci.ui.components.RemCiBottomBar
import com.abitechnologie.remci.ui.components.Tab
import com.abitechnologie.remci.ui.theme.Bg

@Composable
fun MainScreen(
    role: String,
    favorites: Set<Int>,
    onToggleFavorite: (Int) -> Unit,
    onOpenProperty: (Property) -> Unit,
    onLogout: () -> Unit,
    onMyProperties: () -> Unit = {},
    user: UserDto? = null,
    onUserUpdated: (UserDto) -> Unit = {},
    /** Invité : ouvre l'écran d'inscription / de connexion. */
    onOpenTenantProfile: () -> Unit = {},
    onRequestRegister: () -> Unit = {},
    onRequestLogin: () -> Unit = {}
) {
    // Invité = visiteur sans compte : il peut parcourir la liste des résidences, mais toute
    // autre action (fiche détaillée, réservation, favoris, profil…) demande de s'inscrire.
    val isGuest = user == null
    var guestGate by remember { mutableStateOf<String?>(null) }
    val guardedOpenProperty: (Property) -> Unit = { p ->
        if (isGuest) guestGate = GuestMessages.PROPERTY else onOpenProperty(p)
    }
    val guardedToggleFavorite: (Int) -> Unit = { id ->
        if (isGuest) guestGate = GuestMessages.FAVORITE else onToggleFavorite(id)
    }

    var currentTab by remember { mutableStateOf<Tab>(Tab.Home) }
    var filterCity by remember { mutableStateOf<String?>(null) }
    var showNotifications by remember { mutableStateOf(false) }
    var unread by remember { mutableStateOf(0) }
    val profileRepository = remember { ProfileRepository() }

    // Compteur de notifications non lues (pastille sur la cloche et dans le profil)
    LaunchedEffect(showNotifications, user?.id) {
        if (!showNotifications && user != null) {
            (profileRepository.notifications() as? ApiResult.Success)?.let { unread = it.data.unreadCount }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = { RemCiBottomBar(currentTab) { currentTab = it } }
        ) { padding ->
            val topInset = if (currentTab.route == Tab.Profile.route) Modifier else Modifier.statusBarsPadding()
            Box(modifier = Modifier.fillMaxSize().padding(bottom = padding.calculateBottomPadding()).then(topInset)) {
                when (currentTab.route) {
                    Tab.Search.route -> SearchScreen(favorites, guardedToggleFavorite, guardedOpenProperty)
                    Tab.Favorites.route -> if (isGuest) {
                        GuestGateScreen(
                            icon = Icons.Default.Favorite,
                            title = "Tes favoris t'attendent",
                            message = GuestMessages.FAVORITE,
                            onRegister = onRequestRegister,
                            onLogin = onRequestLogin
                        )
                    } else {
                        FavoritesScreen(favorites, onToggleFavorite, onOpenProperty)
                    }
                    Tab.Bookings.route -> if (isGuest) {
                        GuestGateScreen(
                            icon = Icons.Default.CalendarMonth,
                            title = "Inscris-toi pour réserver",
                            message = GuestMessages.BOOKING,
                            onRegister = onRequestRegister,
                            onLogin = onRequestLogin
                        )
                    } else {
                        BookingsScreen()
                    }
                    Tab.Profile.route -> if (isGuest) {
                        GuestGateScreen(
                            icon = Icons.Default.Person,
                            title = "Crée ton compte REM-CI",
                            message = "Inscris-toi gratuitement pour réserver une résidence meublée, contacter les propriétaires, " +
                                "enregistrer tes favoris et recevoir tes notifications.",
                            onRegister = onRequestRegister,
                            onLogin = onRequestLogin
                        )
                    } else {
                        ProfileScreen(
                            role = role,
                            user = user,
                            unreadCount = unread,
                            onUserUpdated = onUserUpdated,
                            onLogout = onLogout,
                            onMyProperties = onMyProperties,
                            onOpenFavorites = { currentTab = Tab.Favorites },
                            onOpenNotifications = { showNotifications = true },
                            onOpenTenantProfile = onOpenTenantProfile
                        )
                    }
                    else -> HomeScreen(
                        favorites = favorites,
                        filterCity = filterCity,
                        onFilterCity = { filterCity = it },
                        onToggleFavorite = guardedToggleFavorite,
                        onOpenProperty = guardedOpenProperty,
                        userName = user?.name ?: "",
                        onOpenSearch = { currentTab = Tab.Search },
                        unreadCount = unread,
                        onOpenNotifications = {
                            if (isGuest) guestGate = GuestMessages.NOTIFICATIONS else showNotifications = true
                        }
                    )
                }
            }
        }

        guestGate?.let { message ->
            GuestGateDialog(
                message = message,
                onRegister = { guestGate = null; onRequestRegister() },
                onLogin = { guestGate = null; onRequestLogin() },
                onDismiss = { guestGate = null }
            )
        }

        if (showNotifications) {
            Box(modifier = Modifier.fillMaxSize().background(Bg)) {
                NotificationsScreen(
                    onBack = { showNotifications = false },
                    onAllRead = { unread = 0 }
                )
            }
        }
    }
}
