<?php

namespace App\Console\Commands;

use App\Models\Booking;
use Illuminate\Console\Command;

class ExpireBookings extends Command
{
    protected $signature = 'bookings:expire';

    protected $description = 'Expire les demandes de réservation restées sans réponse du propriétaire (48 h)';

    public function handle(): int
    {
        $count = Booking::expireStale();
        $this->info("{$count} demande(s) expirée(s).");

        return self::SUCCESS;
    }
}
