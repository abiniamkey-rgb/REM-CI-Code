<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Vérification d'identité du propriétaire — remplace l'ancien paiement des frais
            // de publication : un propriétaire doit maintenant être certifié par l'administrateur
            // (manuellement, via phpMyAdmin) avant de pouvoir publier une résidence.
            $table->string('address')->nullable()->after('avatar');
            $table->string('id_document_url')->nullable()->after('address');
            $table->enum('owner_verification_status', ['not_submitted', 'pending', 'verified', 'rejected'])
                ->default('not_submitted')
                ->after('id_document_url');
            $table->timestamp('owner_verified_at')->nullable()->after('owner_verification_status');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['address', 'id_document_url', 'owner_verification_status', 'owner_verified_at']);
        });
    }
};
