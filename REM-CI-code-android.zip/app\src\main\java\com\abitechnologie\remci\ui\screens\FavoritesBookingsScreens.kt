package com.abitechnologie.remci.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.widget.Toast
import coil.compose.AsyncImage
import com.abitechnologie.remci.data.Property
import com.abitechnologie.remci.data.network.BookingDto
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.BookingRepository
import com.abitechnologie.remci.ui.components.dialNumber
import com.abitechnologie.remci.ui.components.formatFcfa
import com.abitechnologie.remci.ui.components.formatIsoDate
import com.abitechnologie.remci.ui.components.openWhatsAppTo
import kotlinx.coroutines.launch
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.abitechnologie.remci.data.network.toUiModel
import com.abitechnologie.remci.ui.components.PropertyCard
import com.abitechnologie.remci.ui.components.ReceiptData
import com.abitechnologie.remci.data.network.TokenManager
import com.abitechnologie.remci.ui.components.TopBar
import com.abitechnologie.remci.ui.theme.*

@Composable
fun FavoritesScreen(favorites: Set<Int>, onToggleFavorite: (Int) -> Unit, onOpenProperty: (Property) -> Unit) {
    val repository = remember { com.abitechnologie.remci.data.repository.PropertyRepository() }
    var all by remember { mutableStateOf<List<Property>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableStateOf(0) }

    LaunchedEffect(favorites, reload) {
        // Pas de clignotement quand on retire un cœur : le spinner n'apparaît que s'il n'y a encore rien à montrer
        if (all.isEmpty()) loading = true
        when (val result = repository.getFavorites()) {
            is com.abitechnologie.remci.data.repository.ApiResult.Success -> {
                all = result.data.map { it.toUiModel() }
                error = null
            }
            is com.abitechnologie.remci.data.repository.ApiResult.Error -> error = result.message
        }
        loading = false
    }
    val list = all.filter { favorites.contains(it.id) }
    Column(modifier = Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())) {
        TopBar("Mes favoris")
        when {
            loading && list.isEmpty() -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Orange, modifier = Modifier.size(28.dp))
            }

            list.isEmpty() && error != null -> Column(
                modifier = Modifier.fillMaxWidth().padding(30.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.CloudOff, contentDescription = null, tint = Sub, modifier = Modifier.size(36.dp))
                Text(error ?: "", fontSize = 12.sp, color = Sub, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
                TextButton(onClick = { reload++ }) { Text("Réessayer", color = Orange, fontWeight = FontWeight.Bold) }
            }

            list.isEmpty() -> Column(
                modifier = Modifier.fillMaxWidth().padding(30.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.FavoriteBorder, contentDescription = null, tint = Orange, modifier = Modifier.size(36.dp))
                Text("Aucun favori pour l'instant", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Ink, modifier = Modifier.padding(top = 8.dp))
                Text(
                    "Touche le cœur d'une résidence pour la retrouver ici.",
                    fontSize = 12.sp, color = Sub, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp)
                )
            }

            else -> Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                list.chunked(2).forEach { rowItems ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        rowItems.forEach { p ->
                            PropertyCard(p, true, onOpenProperty, onToggleFavorite, modifier = Modifier.weight(1f))
                        }
                        if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                }
                Spacer(Modifier.height(90.dp))
            }
        }
    }
}

@Composable
fun BookingsScreen() {
    val repository = remember { BookingRepository() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var bookings by remember { mutableStateOf<List<BookingDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) } // 0 = En cours, 1 = Terminées
    var reload by remember { mutableStateOf(0) }
    var toCancel by remember { mutableStateOf<BookingDto?>(null) }
    var receipt by remember { mutableStateOf<ReceiptData?>(null) }

    LaunchedEffect(reload) {
        loading = true
        error = null
        when (val result = repository.getMyBookings()) {
            is ApiResult.Success -> bookings = result.data
            is ApiResult.Error -> error = result.message
        }
        loading = false
    }

    val ongoing = bookings.filter { it.status == "pending" || it.status == "confirmed" }
    val done = bookings.filter { it.status == "completed" || it.status == "cancelled" || it.status == "expired" }
    val shown = if (tab == 0) ongoing else done

    Column(modifier = Modifier.fillMaxSize().background(Bg)) {
        TopBar("Mes réservations")

        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .background(Color(0xFFF0ECE0), RoundedCornerShape(14.dp))
                .padding(4.dp)
        ) {
            listOf("En cours (${ongoing.size})" to 0, "Terminées (${done.size})" to 1).forEach { (label, index) ->
                val selected = tab == index
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (selected) Green else Color.Transparent, RoundedCornerShape(11.dp))
                        .clickableNoRippleLocal { tab = index }
                        .padding(vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (selected) Color.White else Sub)
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        when {
            loading -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Orange, modifier = Modifier.size(26.dp))
            }

            error != null -> Column(
                modifier = Modifier.fillMaxWidth().padding(36.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.CloudOff, contentDescription = null, tint = Sub, modifier = Modifier.size(32.dp))
                Spacer(Modifier.height(10.dp))
                Text(error ?: "", fontSize = 12.5.sp, color = Sub, textAlign = TextAlign.Center)
                TextButton(onClick = { reload++ }) { Text("Réessayer", color = Orange, fontWeight = FontWeight.Bold) }
            }

            shown.isEmpty() -> Column(
                modifier = Modifier.fillMaxWidth().padding(40.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Sub, modifier = Modifier.size(32.dp))
                Spacer(Modifier.height(10.dp))
                Text(
                    if (tab == 0) "Aucune réservation en cours.\nTrouve une résidence et envoie ta première demande !"
                    else "Aucune réservation terminée ou annulée.",
                    fontSize = 12.5.sp, color = Sub, textAlign = TextAlign.Center, lineHeight = 18.sp
                )
            }

            else -> Column(
                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                shown.forEach { b ->
                    BookingRow(
                        b,
                        onCancel = { toCancel = b },
                        onReceipt = { receipt = b.toReceiptData(tenantFallback = TokenManager.getCachedUser()?.name) }
                    )
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    receipt?.let { ReceiptDialog(it) { receipt = null } }

    toCancel?.let { booking ->
        AlertDialog(
            onDismissRequest = { toCancel = null },
            containerColor = Color.White,
            title = { Text("Annuler cette demande ?", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Ink) },
            text = {
                Text(
                    "Ta demande pour « ${booking.property?.title ?: "la résidence"} » sera annulée et le propriétaire sera prévenu.",
                    fontSize = 13.sp, color = Sub, lineHeight = 18.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    toCancel = null
                    scope.launch {
                        when (val r = repository.cancelBooking(booking.id)) {
                            is ApiResult.Success -> {
                                // On garde la résidence (photo, titre) déjà chargée, seul le statut change
                                bookings = bookings.map { if (it.id == booking.id) it.copy(status = r.data.status) else it }
                                Toast.makeText(context, "Demande annulée", Toast.LENGTH_SHORT).show()
                            }
                            is ApiResult.Error -> Toast.makeText(context, r.message, Toast.LENGTH_LONG).show()
                        }
                    }
                }) { Text("Oui, annuler", color = OrangeDeep, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { toCancel = null }) { Text("Non", color = Sub) } }
        )
    }
}

@Composable
private fun BookingRow(b: BookingDto, onCancel: () -> Unit, onReceipt: () -> Unit) {
    val context = LocalContext.current
    val ownerPhone = b.property?.owner?.phone
    val active = b.status == "pending" || b.status == "confirmed"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(16.dp))
            .border(1.dp, Divider, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Box(
                modifier = Modifier.size(60.dp).clip(RoundedCornerShape(12.dp)).background(Brush2())
            ) {
                b.property?.photos?.firstOrNull()?.let {
                    AsyncImage(model = com.abitechnologie.remci.data.network.secureUrl(it), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(b.property?.title ?: "Résidence", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "${formatIsoDate(b.checkIn)} → ${formatIsoDate(b.checkOut)}",
                    fontSize = 11.5.sp, color = Ink, modifier = Modifier.padding(top = 2.dp)
                )
                Text(
                    "${b.nights} nuit(s) · ${b.guests} voyageur(s) · ${formatFcfa(b.totalPrice)} FCFA",
                    fontSize = 11.sp, color = Sub, modifier = Modifier.padding(top = 1.dp)
                )
                StatusBadge(b.status)
            }
        }

        if (b.status == "pending") {
            Text(
                "Réponse du propriétaire attendue sous 48 h.",
                fontSize = 10.5.sp, color = Sub, modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Reçu officiel (avec code QR) dès que le propriétaire a confirmé la réservation
        if (b.status == "confirmed" || b.status == "completed") {
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onReceipt,
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 10.dp)
            ) {
                Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Voir mon reçu (code QR)", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            }
        }

        if (active) {
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (!ownerPhone.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = { dialNumber(context, ownerPhone) },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Appeler", fontSize = 11.5.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            openWhatsAppTo(
                                context, ownerPhone,
                                "Bonjour, j'ai fait une demande de réservation pour « ${b.property?.title ?: "votre résidence"} » " +
                                    "du ${formatIsoDate(b.checkIn, "d MMM")} au ${formatIsoDate(b.checkOut, "d MMM yyyy")} sur REM-CI."
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("WhatsApp", fontSize = 11.5.sp)
                    }
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onCancel, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                    Text("Annuler", color = OrangeDeep, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(status: String) {
    val (label, color) = when (status) {
        "pending" -> "En attente" to Gold
        "confirmed" -> "Confirmée" to Green
        "completed" -> "Terminée" to Sub
        "cancelled" -> "Annulée" to OrangeDeep
        "expired" -> "Expirée" to Sub
        else -> status to Sub
    }
    Text(
        label, color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier
            .padding(top = 5.dp)
            .background(color, RoundedCornerShape(20.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    )
}

@Composable
private fun Brush2() = Brush.linearGradient(listOf(Green, GreenDeep))

@Composable
private fun Modifier.clickableNoRippleLocal(onClick: () -> Unit): Modifier {
    val source = remember { MutableInteractionSource() }
    return this.clickable(interactionSource = source, indication = null, onClick = onClick)
}
