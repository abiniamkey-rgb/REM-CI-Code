package com.abitechnologie.remci.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import java.io.File

/** Crée un fichier temporaire dans le cache de l'app et renvoie son Uri via FileProvider. */
private fun createCaptureTarget(context: Context): Pair<File, Uri> {
    val dir = File(context.cacheDir, "camera").apply { mkdirs() }
    val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    return file to uri
}

/**
 * Lance directement l'appareil photo du téléphone (jamais la galerie) et renvoie le
 * fichier capturé via [onCaptured]. Conforme à l'exigence : les photos (résidence et
 * pièce d'identité du propriétaire) doivent être prises avec le téléphone, pas choisies
 * depuis la galerie.
 *
 * Retourne une fonction à appeler pour déclencher la prise de photo.
 */
@Composable
fun rememberCameraCapture(onCaptured: (File) -> Unit): () -> Unit {
    val context = LocalContext.current
    val pendingFile = remember { mutableStateOf<File?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val file = pendingFile.value
        if (success && file != null) onCaptured(file)
        pendingFile.value = null
    }

    return {
        val (file, uri) = createCaptureTarget(context)
        pendingFile.value = file
        launcher.launch(uri)
    }
}

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * Prise de photo d'un DOCUMENT (pièce d'identité) avec cadrage automatique : le scanner de
 * Google détecte les bords de la pièce, la recadre et la redresse. Si le scanner n'est pas
 * disponible sur le téléphone, on retombe sur l'appareil photo classique.
 * Aucune importation depuis la galerie.
 */
@Composable
fun rememberDocumentScan(onScanned: (File) -> Unit): () -> Unit {
    val context = LocalContext.current
    val fallback = rememberCameraCapture(onScanned)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
                .fromActivityResultIntent(result.data)?.pages?.firstOrNull()?.imageUri
            if (uri != null) {
                try {
                    val dir = File(context.cacheDir, "camera").apply { mkdirs() }
                    val file = File(dir, "scan_${System.currentTimeMillis()}.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        file.outputStream().use { input.copyTo(it) }
                    }
                    if (file.length() > 0) onScanned(file)
                } catch (_: Exception) {
                }
            }
        }
    }
    return {
        val activity = context.findActivity()
        if (activity == null) {
            fallback()
        } else {
            val options = com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(false)
                .setPageLimit(1)
                .setResultFormats(com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                .setScannerMode(com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.SCANNER_MODE_BASE)
                .build()
            com.google.mlkit.vision.documentscanner.GmsDocumentScanning.getClient(options)
                .getStartScanIntent(activity)
                .addOnSuccessListener { sender -> launcher.launch(IntentSenderRequest.Builder(sender).build()) }
                .addOnFailureListener { fallback() }
        }
    }
}
