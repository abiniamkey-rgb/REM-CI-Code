package com.abitechnologie.remci.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.abitechnologie.remci.data.Property
import com.abitechnologie.remci.ui.components.AvailabilityPill
import com.abitechnologie.remci.ui.components.Badge
import com.abitechnologie.remci.ui.components.CircleIconButton
import com.abitechnologie.remci.ui.components.PropertyCover
import com.abitechnologie.remci.ui.components.RatingLabel
import com.abitechnologie.remci.ui.components.dialNumber
import com.abitechnologie.remci.ui.components.openWhatsAppTo
import com.abitechnologie.remci.ui.theme.*

/** Associe une commodité (nom saisi côté admin) à une icône ; coche par défaut. */
private fun amenityIcon(name: String): ImageVector {
    val n = name.lowercase()
    return when {
        "wi-fi" in n || "wifi" in n -> Icons.Default.Wifi
        "clim" in n -> Icons.Default.AcUnit
        "ventil" in n -> Icons.Default.Air
        "tv" in n -> Icons.Default.Tv
        "eau chaude" in n -> Icons.Default.HotTub
        "drap" in n -> Icons.Default.Bed
        "penderie" in n -> Icons.Default.Checkroom
        "travail" in n -> Icons.Default.Laptop
        "réfrig" in n || "congél" in n -> Icons.Default.Kitchen
        "micro" in n -> Icons.Default.Microwave
        "bouilloire" in n || "cafeti" in n -> Icons.Default.Coffee
        "cuisine" in n || "plaque" in n -> Icons.Default.Restaurant
        "lave" in n -> Icons.Default.LocalLaundryService
        "groupe" in n || "onduleur" in n -> Icons.Default.Bolt
        "eau" in n || "forage" in n -> Icons.Default.WaterDrop
        "caméra" in n -> Icons.Default.Videocam
        "portail" in n -> Icons.Default.DoorFront
        "coffre" in n -> Icons.Default.Lock
        "sécurité" in n || "gardien" in n -> Icons.Default.Security
        "parking" in n -> Icons.Default.DirectionsCar
        "piscine" in n -> Icons.Default.Pool
        "jardin" in n -> Icons.Default.Park
        "terrasse" in n || "balcon" in n -> Icons.Default.Deck
        "barbecue" in n -> Icons.Default.OutdoorGrill
        "sport" in n -> Icons.Default.FitnessCenter
        "ascenseur" in n -> Icons.Default.Elevator
        "accueil" in n || "check-in" in n -> Icons.Default.Key
        "ménage" in n -> Icons.Default.CleaningServices
        "animaux" in n -> Icons.Default.Pets
        else -> Icons.Default.CheckCircle
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DetailScreen(
    property: Property,
    isFavorite: Boolean,
    onBack: () -> Unit,
    onToggleFavorite: (Int) -> Unit,
    onBook: (Property) -> Unit
) {
    val context = LocalContext.current
    val photos = property.photos
    val pagerState = rememberPagerState(pageCount = { maxOf(photos.size, 1) })

    fun openMap() {
        val lat = property.latitude
        val lng = property.longitude
        val uri = when {
            lat != null && lng != null -> Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(property.title)})")
            !property.address.isNullOrBlank() -> Uri.parse("geo:0,0?q=${Uri.encode(property.address + ", " + property.city + ", Côte d'Ivoire")}")
            else -> null
        } ?: return
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: ActivityNotFoundException) {
            // Pas d'application de cartes : on ouvre dans le navigateur
            if (lat != null && lng != null) {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng")))
            }
        }
    }

    fun share() {
        val text = "Découvre « ${property.title} » à ${property.city} sur REM-CI — " +
            "${"%,d".format(property.price).replace(',', ' ')} FCFA / nuit."
        context.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) },
                "Partager"
            )
        )
    }

    Box(modifier = Modifier.fillMaxSize().background(Bg)) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 96.dp)) {
            // Galerie : toutes les photos prises par le propriétaire
            Box(modifier = Modifier.fillMaxWidth().height(280.dp)) {
                HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                    PropertyCover(photos.getOrNull(page), Modifier.fillMaxSize())
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth().height(80.dp).align(Alignment.TopCenter)
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.35f), Color.Transparent)))
                )
                Row(
                    modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    CircleIconButton(Icons.Default.ArrowBack, onBack)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircleIconButton(Icons.Default.Share, { share() })
                        CircleIconButton(
                            if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            { onToggleFavorite(property.id) },
                            tint = if (isFavorite) Orange else Ink
                        )
                    }
                }
                if (photos.size > 1) {
                    Text(
                        "${pagerState.currentPage + 1} / ${photos.size}",
                        color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .align(Alignment.BottomEnd).padding(14.dp)
                            .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .offset(y = (-18).dp)
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .background(Bg)
                    .padding(horizontal = 18.dp, vertical = 18.dp)
            ) {
                if (property.tag.isNotBlank()) {
                    Badge(property.tag, property.tagColor)
                    Spacer(Modifier.height(8.dp))
                }
                Text(property.title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                Spacer(Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = Orange, modifier = Modifier.size(14.dp))
                        Text(" ${property.city}, Côte d'Ivoire", fontSize = 12.5.sp, color = Sub)
                    }
                    RatingLabel(property)
                }

                // Disponibilité déclarée par le propriétaire (bleu = libre, rouge = occupée)
                Spacer(Modifier.height(10.dp))
                AvailabilityPill(property.available, modifier = Modifier.border(1.dp, Divider, RoundedCornerShape(20.dp)), large = true)
                if (!property.available) {
                    Text(
                        "Le propriétaire a indiqué que cette résidence est occupée en ce moment. Elle redeviendra réservable dès qu'il la libérera dans l'application.",
                        fontSize = 11.5.sp, color = Sub, lineHeight = 16.sp, modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatTile(Icons.Default.MeetingRoom, "${property.beds}", "pièce(s)", Modifier.weight(1f))
                    StatTile(Icons.Default.People, "${property.capacity}", "voyageur(s)", Modifier.weight(1f))
                    StatTile(Icons.Default.Bathtub, "${property.bathrooms}", "salle(s) de bain", Modifier.weight(1f))
                }

                Spacer(Modifier.height(18.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardBg, RoundedCornerShape(16.dp))
                        .border(1.dp, Divider, RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val ownerName = property.ownerName ?: "Hébergeur REM-CI"
                    Box(modifier = Modifier.size(44.dp).clip(CircleShape).background(Gold), contentAlignment = Alignment.Center) {
                        Text(ownerName.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(ownerName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text(
                            if (property.ownerVerified) "Hébergeur certifié REM-CI ✓" else "Hébergeur REM-CI",
                            fontSize = 11.sp, color = if (property.ownerVerified) Green else Sub,
                            fontWeight = if (property.ownerVerified) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                    if (!property.ownerPhone.isNullOrBlank()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CircleIconButton(
                                Icons.Default.Chat,
                                onClick = {
                                    openWhatsAppTo(
                                        context, property.ownerPhone,
                                        "Bonjour, je suis intéressé(e) par votre résidence \"${property.title}\" sur REM-CI. Est-elle disponible ?"
                                    )
                                },
                                tint = Green
                            )
                            CircleIconButton(
                                Icons.Default.Call,
                                onClick = { dialNumber(context, property.ownerPhone) },
                                tint = Green
                            )
                        }
                    }
                }

                Spacer(Modifier.height(22.dp))
                Text("À propos", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(6.dp))
                Text(
                    property.description?.takeIf { it.isNotBlank() }
                        ?: "Résidence meublée à ${property.city}. Contacte l'hébergeur pour les détails et la disponibilité.",
                    fontSize = 12.5.sp, color = Sub, lineHeight = 19.sp
                )

                if (property.amenities.isNotEmpty()) {
                    Spacer(Modifier.height(22.dp))
                    Text("Commodités", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Spacer(Modifier.height(10.dp))
                    property.amenities.chunked(2).forEach { pair ->
                        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { name ->
                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(CardBg, RoundedCornerShape(12.dp))
                                        .border(1.dp, Divider, RoundedCornerShape(12.dp))
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(amenityIcon(name), contentDescription = null, tint = Green, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(name, fontSize = 11.5.sp, color = Ink, fontWeight = FontWeight.Medium)
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }

                val hasLocation = (property.latitude != null && property.longitude != null) || !property.address.isNullOrBlank()
                if (hasLocation) {
                    Spacer(Modifier.height(12.dp))
                    Text("Emplacement", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CardBg, RoundedCornerShape(16.dp))
                            .border(1.dp, Divider, RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(40.dp).background(Green.copy(alpha = 0.1f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Place, contentDescription = null, tint = Green, modifier = Modifier.size(20.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(property.address ?: property.city, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                            Text("Position exacte relevée par l'hébergeur", fontSize = 10.5.sp, color = Sub)
                        }
                        OutlinedButton(onClick = { openMap() }, shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                            Text("Voir la carte", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // Barre de réservation fixe
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(CardBg)
                .border(width = androidx.compose.ui.unit.Dp.Hairline, color = Divider)
                .navigationBarsPadding()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("${"%,d".format(property.price).replace(',', ' ')} FCFA", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = Green)
                Text("par nuit", fontSize = 10.5.sp, color = Sub)
            }
            Button(
                onClick = { onBook(property) },
                enabled = property.available,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Orange,
                    disabledContainerColor = Danger.copy(alpha = 0.14f),
                    disabledContentColor = Danger
                ),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 22.dp, vertical = 12.dp)
            ) {
                Icon(
                    if (property.available) Icons.Default.EventAvailable else Icons.Default.Block,
                    contentDescription = null, modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(if (property.available) "Réserver" else "Occupée", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun StatTile(icon: ImageVector, value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(CardBg, RoundedCornerShape(14.dp))
            .border(1.dp, Divider, RoundedCornerShape(14.dp))
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(20.dp))
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Ink, modifier = Modifier.padding(top = 4.dp))
        Text(label, fontSize = 9.5.sp, color = Sub, textAlign = TextAlign.Center)
    }
}
