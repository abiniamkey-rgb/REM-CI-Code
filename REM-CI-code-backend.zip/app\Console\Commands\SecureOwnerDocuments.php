<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

class SecureOwnerDocuments extends Command
{
    protected $signature = 'remci:secure-documents';

    protected $description = "Déplace les anciennes pièces d'identité du disque public vers le disque privé (plus accessibles par URL)";

    public function handle(): int
    {
        $moved = 0;

        User::whereNotNull('id_document_url')->orWhereNotNull('id_document_verso_url')->each(function (User $user) use (&$moved) {
            foreach (['id_document_url', 'id_document_verso_url'] as $column) {
                $path = $user->{$column};
                if ($path && Storage::disk('public')->exists($path)) {
                    Storage::disk('local')->put($path, Storage::disk('public')->get($path));
                    Storage::disk('public')->delete($path);
                    $moved++;
                }
            }
        });

        $this->info("{$moved} fichier(s) déplacé(s) vers le stockage privé.");

        return self::SUCCESS;
    }
}
