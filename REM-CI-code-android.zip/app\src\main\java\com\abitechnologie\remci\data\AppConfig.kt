package com.abitechnologie.remci.data

/**
 * Réglages de l'application.
 *
 * GOOGLE_WEB_CLIENT_ID : identifiant client OAuth de type « Application Web » créé dans
 * Google Cloud Console (APIs et services > Identifiants). C'est le MÊME identifiant que
 * GOOGLE_CLIENT_ID dans le .env du backend Laravel. Tant qu'il est vide, le bouton
 * « Continuer avec Google » affiche un message au lieu de se connecter.
 */
object AppConfig {
    const val GOOGLE_WEB_CLIENT_ID = ""

    const val APP_VERSION = "1.0.0"

    /** Nombre maximum de résidences (en attente + publiées) par compte propriétaire. */
    const val MAX_PROPERTIES_PER_OWNER = 5

    /** Site web de REM-CI (pages légales). Défini par type de build dans build.gradle.kts. */
    val SITE_URL: String get() = com.abitechnologie.remci.BuildConfig.SITE_URL.trimEnd('/')
    val PRIVACY_URL: String get() = "$SITE_URL/confidentialite"
    val TERMS_URL: String get() = "$SITE_URL/conditions"
    val DELETION_URL: String get() = "$SITE_URL/suppression-compte"

    /** Numéros de l'administrateur REM-CI (validation des propriétaires et des résidences, aide). */
    val ADMIN_PHONES = listOf(
        AdminPhone(raw = "0707982802", display = "07 07 98 28 02"),
        AdminPhone(raw = "0170692633", display = "01 70 69 26 33")
    )

    /** "07 07 98 28 02 / 01 70 69 26 33" */
    val ADMIN_PHONES_TEXT: String get() = ADMIN_PHONES.joinToString(" / ") { it.display }
}

data class AdminPhone(val raw: String, val display: String)
