package com.abitechnologie.remci.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.data.network.NotificationDto
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.ProfileRepository
import com.abitechnologie.remci.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Notifications de l'utilisateur connecté (locataire ou propriétaire) : bienvenue,
 * demandes de réservation, décisions du propriétaire, certification du dossier,
 * publication des résidences… À l'ouverture, tout est marqué comme lu.
 */
@Composable
fun NotificationsScreen(
    onBack: () -> Unit,
    /** Appelé quand la liste est chargée : le compteur de non-lus repasse à 0. */
    onAllRead: () -> Unit = {}
) {
    BackHandler(onBack = onBack)

    val repository = remember { ProfileRepository() }
    var list by remember { mutableStateOf<List<NotificationDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableStateOf(0) }

    LaunchedEffect(reload) {
        loading = true
        error = null
        when (val r = repository.notifications()) {
            is ApiResult.Success -> {
                list = r.data.data
                if (r.data.unreadCount > 0) {
                    repository.markAllNotificationsRead()
                }
                onAllRead()
            }
            is ApiResult.Error -> error = r.message
        }
        loading = false
    }

    Column(modifier = Modifier.fillMaxSize().background(Bg)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardBg)
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Retour", tint = Ink)
            }
            Text("Notifications", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        }

        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Orange, modifier = Modifier.size(28.dp))
            }

            error != null -> Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.NotificationsNone, contentDescription = null, tint = Sub, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(10.dp))
                Text(error ?: "", fontSize = 13.sp, color = Sub, textAlign = TextAlign.Center)
                TextButton(onClick = { reload++ }) { Text("Réessayer", color = Orange, fontWeight = FontWeight.Bold) }
            }

            list.isEmpty() -> Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier.size(70.dp).background(Orange.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.NotificationsNone, contentDescription = null, tint = Orange, modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.height(14.dp))
                Text("Aucune notification", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                Text(
                    "Vos alertes (réservations, validation, résidences…) apparaîtront ici.",
                    fontSize = 12.5.sp, color = Sub, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            else -> LazyColumn(
                modifier = Modifier.fillMaxSize().navigationBarsPadding(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(list, key = { it.id }) { n -> NotificationRow(n) }
            }
        }
    }
}

@Composable
private fun NotificationRow(n: NotificationDto) {
    val (icon, color) = notificationStyle(n.type)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(16.dp))
            .border(1.dp, if (!n.read) color.copy(alpha = 0.45f) else Divider, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Box(
            modifier = Modifier.size(40.dp).background(color.copy(alpha = 0.12f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    n.title, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = Ink,
                    modifier = Modifier.weight(1f)
                )
                if (!n.read) {
                    Box(Modifier.size(8.dp).background(Orange, CircleShape))
                }
            }
            Text(n.body, fontSize = 12.sp, lineHeight = 17.sp, color = Ink.copy(alpha = 0.85f), modifier = Modifier.padding(top = 3.dp))
            Text(relativeTime(n.createdAt), fontSize = 10.5.sp, color = Sub, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

private fun notificationStyle(type: String): Pair<ImageVector, Color> = when (type) {
    "welcome" -> Icons.Default.Star to Gold
    "verification" -> Icons.Default.VerifiedUser to Green
    "property" -> Icons.Default.Home to OrangeDeep
    "booking_request", "booking_update" -> Icons.Default.CalendarMonth to Blue
    else -> Icons.Default.Notifications to Orange
}

/** "À l'instant", "Il y a 5 min", "Il y a 3 h", "Hier", "12/10/2026". */
private fun relativeTime(iso: String?): String {
    if (iso.isNullOrBlank()) return ""
    val date = listOf("yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'")
        .firstNotNullOfOrNull { pattern ->
            try {
                SimpleDateFormat(pattern, Locale.US).parse(iso)
            } catch (_: Exception) {
                null
            }
        } ?: return ""
    val diff = System.currentTimeMillis() - date.time
    val minutes = diff / 60_000
    val hours = minutes / 60
    val days = hours / 24
    return when {
        minutes < 1 -> "À l'instant"
        minutes < 60 -> "Il y a $minutes min"
        hours < 24 -> "Il y a $hours h"
        days == 1L -> "Hier"
        days < 7 -> "Il y a $days jours"
        else -> SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(date)
    }
}
