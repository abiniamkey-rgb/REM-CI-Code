@extends('legal.layout')
@section('title', "Conditions d'utilisation")
@section('description', "Règles d'utilisation de la plateforme REM-CI pour les locataires et les propriétaires.")
@section('content')
  <h1>Conditions d'utilisation</h1>
  <p class="upd">Dernière mise à jour : {{ config('remci.legal_updated_at') }}</p>

  <p>En créant un compte ou en utilisant l'application REM-CI, vous acceptez les présentes conditions. REM-CI est édité par <strong>{{ config('remci.company') }}</strong> (Côte d'Ivoire).</p>

  <h2>1. Le service</h2>
  <p>REM-CI est une plateforme de mise en relation entre des <strong>propriétaires</strong> de résidences meublées et des <strong>locataires</strong>. REM-CI n'est ni le propriétaire des résidences, ni une agence immobilière, ni partie au contrat de location : le séjour est convenu directement entre le locataire et le propriétaire.</p>

  <h2>2. Aucun paiement dans l'application</h2>
  <p>Aucun paiement n'est effectué via REM-CI. Le prix, les modalités de règlement et la remise des clés se règlent directement entre le locataire et le propriétaire, par appel ou WhatsApp. REM-CI n'encaisse aucune somme et ne garantit aucun remboursement. <strong>Soyez prudent</strong> : ne versez jamais d'argent à quelqu'un que vous n'avez pas pu identifier, et méfiez-vous des demandes d'avance avant d'avoir vu la résidence.</p>

  <h2>3. Compte</h2>
  <ul>
    <li>Vous devez avoir 18 ans révolus et fournir des informations exactes.</li>
    <li>Un compte correspond à un seul rôle : locataire ou propriétaire. Un propriétaire ne peut pas réserver avec son compte propriétaire.</li>
    <li>Vous êtes responsable de la confidentialité de votre mot de passe et de l'activité de votre compte.</li>
  </ul>

  <h2>4. Règles pour les locataires</h2>
  <ul>
    <li>Un dossier d'identité complet (pièce, date de naissance majeure) est nécessaire avant de réserver.</li>
    <li>Vous pouvez envoyer au maximum <strong>3 demandes de réservation par jour</strong>.</li>
    <li>Une demande sans réponse du propriétaire expire automatiquement au bout de <strong>48 heures</strong>.</li>
    <li>Une demande n'est une réservation qu'une fois <strong>confirmée par le propriétaire</strong> ; le reçu avec code QR n'est alors délivré. La disponibilité affichée est indicative : le propriétaire reste seul juge.</li>
    <li>Respectez la résidence, le voisinage et les règles du propriétaire.</li>
  </ul>

  <h2>5. Règles pour les propriétaires</h2>
  <ul>
    <li>Votre identité doit être certifiée par l'administration REM-CI avant la publication de vos annonces.</li>
    <li>Vous garantissez être le propriétaire ou être autorisé à proposer la résidence, et que l'annonce (photos, description, équipements, prix) est exacte.</li>
    <li>Vous tenez à jour la disponibilité de la résidence dans l'application.</li>
    <li>Une fois l'annonce publiée, le titre, le prix, la capacité et l'adresse ne se modifient plus ; seuls la description et les équipements peuvent être mis à jour. Chaque modification est signalée à l'administration.</li>
    <li>Répondez aux demandes dans un délai raisonnable.</li>
  </ul>

  <h2>6. Contenus interdits</h2>
  <p>Sont interdits dans les annonces, descriptions, noms et photos : les propos obscènes, sexuels, injurieux ou discriminatoires ; la sollicitation de services sexuels ; les numéros de téléphone, e-mails, liens ou réseaux sociaux dans les textes d'annonce ; les demandes de paiement hors du cadre convenu ; les informations fausses ou trompeuses ; les photos ne représentant pas la résidence ; toute activité illégale. REM-CI utilise un contrôle automatique et humain et peut refuser, masquer, corriger ou supprimer tout contenu.</p>

  <h2>7. Suspension et suppression</h2>
  <p>REM-CI peut suspendre ou supprimer un compte ou une annonce en cas de fraude, d'usurpation d'identité, de contenu interdit ou de non-respect des présentes conditions. Vous pouvez supprimer votre compte à tout moment depuis l'application (<em>Profil &gt; Paramètres</em>) ou via la page <a href="{{ route('legal.deletion') }}">Supprimer mon compte</a>, sauf réservation en cours ou à venir.</p>

  <h2>8. Responsabilité</h2>
  <p>REM-CI s'efforce de vérifier l'identité des propriétaires et de modérer les contenus, mais ne peut garantir l'exactitude de toutes les annonces ni le comportement des utilisateurs. REM-CI n'est pas responsable des litiges, dommages, pertes ou paiements intervenant entre locataires et propriétaires, ni d'une indisponibilité temporaire du service. Cela n'exclut pas la responsabilité qui ne peut légalement être exclue.</p>

  <h2>9. Données personnelles</h2>
  <p>Le traitement de vos données est décrit dans la <a href="{{ route('legal.privacy') }}">politique de confidentialité</a>.</p>

  <h2>10. Propriété intellectuelle</h2>
  <p>La marque REM-CI, le logo, l'application et son contenu éditorial appartiennent à {{ config('remci.company') }}. Vous gardez vos droits sur vos photos et textes et nous accordez le droit de les afficher dans le service.</p>

  <h2>11. Droit applicable et modification</h2>
  <p>Les présentes conditions sont soumises au droit ivoirien. Elles peuvent évoluer ; la date de mise à jour figure en haut de la page et l'usage continu du service vaut acceptation.</p>

  <h2>12. Contact</h2>
  <p><a href="mailto:{{ config('remci.contact_email') }}">{{ config('remci.contact_email') }}</a> · {{ implode(' / ', config('remci.admin_phones')) }}</p>
@endsection
