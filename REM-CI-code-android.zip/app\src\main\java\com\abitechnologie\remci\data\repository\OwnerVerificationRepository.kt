package com.abitechnologie.remci.data.repository

import com.abitechnologie.remci.data.ImageCompressor
import com.abitechnologie.remci.data.network.RetrofitClient
import com.abitechnologie.remci.data.network.UserDto
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

/**
 * Dossier d'identité du propriétaire (nom, téléphone, adresse, photos recto + verso de
 * la pièce d'identité prises avec l'appareil photo, et éventuellement le nom/numéro de
 * CNI détectés automatiquement sur le téléphone) — à soumettre avant de pouvoir publier
 * une résidence. La certification elle-même est faite manuellement par l'administrateur.
 */
class OwnerVerificationRepository {
    private val api = RetrofitClient.api

    suspend fun status(): ApiResult<UserDto> = try {
        val response = api.getOwnerVerification()
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error("Impossible de récupérer le statut de vérification")
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }

    suspend fun submit(
        name: String,
        phone: String,
        address: String,
        idDocumentRecto: File,
        idDocumentVerso: File,
        detectedName: String?,
        detectedIdNumber: String?
    ): ApiResult<UserDto> = try {
        fun text(value: String): RequestBody = value.toRequestBody("text/plain".toMediaTypeOrNull())
        fun photoPart(key: String, file: File): MultipartBody.Part {
            val body = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
            return MultipartBody.Part.createFormData(key, file.name, body)
        }

        // Photos allégées avant envoi (envoi rapide, pas de refus PHP > 2 Mo)
        val recto = ImageCompressor.compressForUpload(idDocumentRecto, maxSide = 1800, quality = 85)
        val verso = ImageCompressor.compressForUpload(idDocumentVerso, maxSide = 1800, quality = 85)

        val response = api.submitOwnerVerification(
            name = text(name),
            phone = text(phone),
            address = text(address),
            detectedName = detectedName?.let { text(it) },
            detectedIdNumber = detectedIdNumber?.let { text(it) },
            idDocumentRecto = photoPart("id_document_recto", recto),
            idDocumentVerso = photoPart("id_document_verso", verso)
        )
        if (response.isSuccessful && response.body() != null) ApiResult.Success(response.body()!!.data)
        else ApiResult.Error(errorMessage(response.errorBody()?.string(), "Impossible d'envoyer ton dossier"))
    } catch (e: Exception) {
        ApiResult.Error(networkErrorMessage(e))
    }
}
