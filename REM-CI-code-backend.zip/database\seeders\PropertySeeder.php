<?php

namespace Database\Seeders;

use App\Models\Amenity;
use App\Models\City;
use App\Models\Property;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class PropertySeeder extends Seeder
{
    public function run(): void
    {
        $owner = User::firstOrCreate(
            ['phone' => '+2250700000001'],
            [
                'name' => 'Hébergeur REM-CI Demo',
                'email' => 'proprietaire@remci.ci',
                'password' => Hash::make('password'),
                'role' => 'proprietaire',
                'is_verified' => true,
            ]
        );

        $amenityIds = Amenity::pluck('id')->toArray();

        $listings = [
            ['title' => 'Studio Cocody Riviera', 'city' => 'Abidjan', 'price' => 25000, 'tag' => 'Populaire', 'beds' => 1, 'rating' => 4.8, 'reviews' => 132],
            ['title' => 'Appart Duplex Marcory', 'city' => 'Abidjan', 'price' => 38000, 'tag' => 'Coup de cœur', 'beds' => 2, 'rating' => 4.9, 'reviews' => 87],
            ['title' => 'Villa Piscine Assinie', 'city' => 'Assinie', 'price' => 95000, 'tag' => 'Promo -15%', 'beds' => 4, 'rating' => 5.0, 'reviews' => 54],
            ['title' => 'Studio Standing Plateau', 'city' => 'Abidjan', 'price' => 30000, 'tag' => 'Nouveau', 'beds' => 1, 'rating' => 4.6, 'reviews' => 61],
            ['title' => 'Résidence Fondation Bouaké', 'city' => 'Bouaké', 'price' => 20000, 'tag' => 'Populaire', 'beds' => 2, 'rating' => 4.5, 'reviews' => 29],
            ['title' => 'Suite Vue Lac Yamoussoukro', 'city' => 'Yamoussoukro', 'price' => 27000, 'tag' => 'Nouveau', 'beds' => 1, 'rating' => 4.7, 'reviews' => 40],
            ['title' => 'Loft Bord de Mer San-Pédro', 'city' => 'San-Pédro', 'price' => 33000, 'tag' => 'Coup de cœur', 'beds' => 2, 'rating' => 4.8, 'reviews' => 22],
            ['title' => 'Appart Cosy Grand-Bassam', 'city' => 'Grand-Bassam', 'price' => 28000, 'tag' => 'Promo -10%', 'beds' => 2, 'rating' => 4.6, 'reviews' => 48],
        ];

        foreach ($listings as $l) {
            $city = City::where('name', $l['city'])->first();
            if (! $city) continue;

            $property = Property::updateOrCreate(
                ['slug' => Str::slug($l['title'])],
                [
                    'owner_id' => $owner->id,
                    'city_id' => $city->id,
                    'title' => $l['title'],
                    'description' => "Résidence meublée entièrement équipée, idéale pour un séjour à {$l['city']}. Quartier calme et sécurisé, proche des commodités.",
                    'price_per_night' => $l['price'],
                    'beds' => $l['beds'],
                    'bathrooms' => 1,
                    'capacity' => $l['beds'] * 2,
                    'address' => "{$l['city']}, Côte d'Ivoire",
                    'status' => 'active',
                    'tag' => $l['tag'],
                    'is_featured' => in_array($l['tag'], ['Populaire', 'Coup de cœur']),
                    'rating' => $l['rating'],
                    'reviews_count' => $l['reviews'],
                ]
            );

            $property->amenities()->sync(collect($amenityIds)->random(min(6, count($amenityIds)))->toArray());
        }
    }
}
