package com.abitechnologie.remci.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.OwnerVerificationRepository
import com.abitechnologie.remci.ui.components.LogoMark
import com.abitechnologie.remci.ui.components.clickableNoRipple
import com.abitechnologie.remci.ui.components.recognizeIdDocument
import com.abitechnologie.remci.ui.components.rememberCameraCapture
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File

/**
 * Dossier d'identité du propriétaire — obligatoire avant de pouvoir publier une
 * résidence. La CNI ivoirienne porte des informations recto ET verso, donc les deux
 * photos sont prises séparément (toujours avec l'appareil photo, jamais la galerie).
 * Une fois les deux photos prises, une lecture automatique du texte (ML Kit, sur le
 * téléphone, gratuite) essaie de pré-remplir le nom et le numéro de CNI — l'utilisateur
 * garde la main pour corriger. Le dossier est ensuite certifié manuellement par
 * l'administrateur REM-CI (pas de bouton "valider" ici : juste l'attente après envoi).
 */
@Composable
fun OwnerVerificationScreen(
    initialName: String,
    initialPhone: String,
    onSubmitted: () -> Unit
) {
    val repository = remember { OwnerVerificationRepository() }
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf(initialName) }
    var phone by remember { mutableStateOf(initialPhone) }
    var address by remember { mutableStateOf("") }
    var idNumber by remember { mutableStateOf("") }
    var nameAutoFilled by remember { mutableStateOf(false) }
    var idNumberAutoFilled by remember { mutableStateOf(false) }

    var rectoFile by remember { mutableStateOf<File?>(null) }
    var versoFile by remember { mutableStateOf<File?>(null) }
    var scanning by remember { mutableStateOf(false) }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var trigger by remember { mutableStateOf(false) }

    fun runOcrIfReady() {
        val recto = rectoFile
        val verso = versoFile
        if (recto == null || verso == null) return
        scanning = true
        scope.launch {
            val fromRecto = recognizeIdDocument(recto)
            val fromVerso = recognizeIdDocument(verso)
            val detectedName = fromRecto.name ?: fromVerso.name
            val detectedNumber = fromRecto.idNumber ?: fromVerso.idNumber
            if (detectedName != null && name.isBlank()) {
                name = detectedName
                nameAutoFilled = true
            }
            if (detectedNumber != null) {
                idNumber = detectedNumber
                idNumberAutoFilled = true
            }
            scanning = false
        }
    }

    val captureRecto = rememberCameraCapture { file -> rectoFile = file; runOcrIfReady() }
    val captureVerso = rememberCameraCapture { file -> versoFile = file; runOcrIfReady() }

    LaunchedEffect(trigger) {
        if (!trigger) return@LaunchedEffect
        val recto = rectoFile
        val verso = versoFile
        if (recto == null || verso == null) {
            error = "Merci de prendre les photos recto et verso de ta pièce d'identité"
            loading = false
            trigger = false
            return@LaunchedEffect
        }
        val result = repository.submit(
            name = name.trim(),
            phone = phone.trim(),
            address = address.trim(),
            idDocumentRecto = recto,
            idDocumentVerso = verso,
            detectedName = if (nameAutoFilled) name.trim() else null,
            detectedIdNumber = idNumber.trim().ifBlank { null }
        )
        loading = false
        trigger = false
        when (result) {
            is ApiResult.Success -> onSubmitted()
            is ApiResult.Error -> error = result.message
        }
    }

    fun validate(): Boolean {
        if (name.isBlank() || phone.isBlank() || address.isBlank()) {
            error = "Merci de remplir le nom, le téléphone et l'adresse"
            return false
        }
        if (rectoFile == null || versoFile == null) {
            error = "Merci de prendre les photos recto et verso de ta pièce d'identité"
            return false
        }
        error = null
        return true
    }

    Column(modifier = Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())) {
        // En-tête
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(GreenDeep, Navy)))
                .statusBarsPadding()
                .padding(top = 30.dp, bottom = 26.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LogoMark(size = 100)
            Text("Vérification d'identité", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(
                "Étape obligatoire avant de publier une résidence. Ton dossier est examiné " +
                    "et certifié manuellement par l'équipe REM-CI.",
                fontSize = 12.sp, color = Color(0xFFC9D6CD), textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 6.dp)
            )
        }

        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {

            SectionCard(step = "1", title = "Tes informations") {
                FieldLabel2("Nom complet")
                OutlinedTextField(
                    value = name, onValueChange = { name = it; nameAutoFilled = false },
                    placeholder = { Text("Ex. Aya Kouadio") },
                    singleLine = true, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
                if (nameAutoFilled) HintRow("Détecté automatiquement sur la pièce — vérifie l'orthographe")

                Spacer(Modifier.height(12.dp))
                FieldLabel2("Téléphone")
                OutlinedTextField(
                    value = phone, onValueChange = { phone = it },
                    placeholder = { Text("+225 07 00 00 00 00") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(12.dp))
                FieldLabel2("Adresse de résidence")
                OutlinedTextField(
                    value = address, onValueChange = { address = it },
                    placeholder = { Text("Ex. Cocody Riviera 3, Abidjan") },
                    singleLine = true, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(12.dp))
                FieldLabel2("Numéro de CNI")
                OutlinedTextField(
                    value = idNumber, onValueChange = { idNumber = it; idNumberAutoFilled = false },
                    placeholder = { Text("Ex. CI0123456789") },
                    singleLine = true, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
                if (idNumberAutoFilled) HintRow("Détecté automatiquement — vérifie les chiffres")
            }

            SectionCard(step = "2", title = "Pièce d'identité — recto / verso") {
                Text(
                    "CNI, passeport ou attestation d'identité. Prends les deux faces avec l'appareil " +
                        "photo (jamais depuis la galerie) ; on essaie de lire automatiquement ton nom " +
                        "et ton numéro pour te faire gagner du temps.",
                    fontSize = 11.5.sp, color = Sub, lineHeight = 16.sp
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    IdPhotoTile("Recto", rectoFile, Modifier.weight(1f), onClick = captureRecto)
                    IdPhotoTile("Verso", versoFile, Modifier.weight(1f), onClick = captureVerso)
                }
                if (scanning) {
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(color = Orange, strokeWidth = 2.dp, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Lecture automatique de la pièce...", fontSize = 11.sp, color = Sub)
                    }
                }
            }

            if (error != null) {
                Text(error!!, color = OrangeDeep, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }

            Button(
                onClick = { if (validate()) { loading = true; error = null; trigger = true } },
                enabled = !loading,
                colors = ButtonDefaults.buttonColors(containerColor = Orange),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                } else {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Envoyer mon dossier", fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                }
            }
            Text(
                "Après l'envoi, contacte l'administrateur REM-CI au ${com.abitechnologie.remci.data.AppConfig.ADMIN_PHONES_TEXT} pour la validation de ton compte.",
                fontSize = 11.5.sp, color = Sub, lineHeight = 16.sp
            )
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
private fun SectionCard(step: String, title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(18.dp))
            .border(1.dp, Divider, RoundedCornerShape(18.dp))
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(24.dp).clip(RoundedCornerShape(8.dp)).background(Green),
                contentAlignment = Alignment.Center
            ) {
                Text(step, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Text(title, fontSize = 14.5.sp, fontWeight = FontWeight.Bold, color = Ink)
        }
        Spacer(Modifier.height(14.dp))
        content()
    }
}

@Composable
private fun IdPhotoTile(label: String, file: File?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(118.dp)
                .background(Bg, RoundedCornerShape(14.dp))
                .border(1.5.dp, if (file != null) Green else Divider, RoundedCornerShape(14.dp))
                .clickableNoRipple(onClick),
            contentAlignment = Alignment.Center
        ) {
            if (file != null) {
                AsyncImage(
                    model = file,
                    contentDescription = label,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp))
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(22.dp)
                        .background(Green, RoundedCornerShape(11.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Orange, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.height(4.dp))
                    Text("Prendre la photo", fontSize = 10.5.sp, color = Sub, textAlign = TextAlign.Center)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}

@Composable
private fun HintRow(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Blue, modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(4.dp))
        Text(text, fontSize = 10.5.sp, color = Blue, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun FieldLabel2(text: String) {
    Text(text, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = Sub)
}
