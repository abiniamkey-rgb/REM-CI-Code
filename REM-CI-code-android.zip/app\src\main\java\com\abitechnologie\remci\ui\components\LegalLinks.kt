package com.abitechnologie.remci.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.data.AppConfig
import com.abitechnologie.remci.ui.theme.Green
import com.abitechnologie.remci.ui.theme.Sub

/** Ouvre une page web dans le navigateur du téléphone. */
fun openWebPage(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        Toast.makeText(context, "Impossible d'ouvrir la page. Vérifie ta connexion.", Toast.LENGTH_SHORT).show()
    }
}

/** « Conditions d'utilisation · Confidentialité » : liens vers les pages légales du site REM-CI. */
@Composable
fun LegalLinksRow(modifier: Modifier = Modifier, fontSize: TextUnit = 11.sp) {
    val context = LocalContext.current
    Row(modifier = modifier, horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Text(
            "Conditions d'utilisation",
            fontSize = fontSize, color = Green, fontWeight = FontWeight.SemiBold, textDecoration = TextDecoration.Underline,
            modifier = Modifier.clickableNoRipple { openWebPage(context, AppConfig.TERMS_URL) }.padding(horizontal = 4.dp, vertical = 4.dp)
        )
        Text("·", fontSize = fontSize, color = Sub)
        Text(
            "Confidentialité",
            fontSize = fontSize, color = Green, fontWeight = FontWeight.SemiBold, textDecoration = TextDecoration.Underline,
            modifier = Modifier.clickableNoRipple { openWebPage(context, AppConfig.PRIVACY_URL) }.padding(horizontal = 4.dp, vertical = 4.dp)
        )
    }
}
