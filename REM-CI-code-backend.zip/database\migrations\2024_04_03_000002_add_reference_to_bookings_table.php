<?php

use App\Models\Booking;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            // Numéro du reçu de réservation (encodé dans le code QR) + date de confirmation.
            $table->string('reference', 20)->nullable()->unique()->after('id');
            $table->timestamp('confirmed_at')->nullable()->after('expired_at');
        });

        // Les réservations déjà enregistrées reçoivent aussi un numéro.
        DB::table('bookings')->whereNull('reference')->orderBy('id')->pluck('id')->each(function ($id) {
            DB::table('bookings')->where('id', $id)->update(['reference' => Booking::makeReference()]);
        });

        // Réservations déjà confirmées : la date de confirmation est celle de la dernière mise à jour.
        DB::table('bookings')->whereIn('status', ['confirmed', 'completed'])->whereNull('confirmed_at')
            ->update(['confirmed_at' => DB::raw('updated_at')]);
    }

    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropUnique(['reference']);
            $table->dropColumn(['reference', 'confirmed_at']);
        });
    }
};
