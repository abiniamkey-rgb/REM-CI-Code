<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Support\Str;

/**
 * Page publique ouverte par le code QR d'un reçu de réservation : elle confirme que le reçu
 * est authentique et affiche l'essentiel, sans donnée sensible (pas de téléphone, d'adresse
 * personnelle ni de pièce d'identité ; le nom du locataire est abrégé).
 */
class ReceiptVerificationController extends Controller
{
    public function show(string $reference)
    {
        Booking::expireStale();

        $booking = Booking::with(['user', 'property.city'])->where('reference', $reference)->first();

        if (! $booking) {
            return response()->view('verify', ['booking' => null, 'state' => 'unknown'], 404);
        }

        $today = now()->startOfDay();
        $state = match (true) {
            $booking->display_status === 'completed' => 'completed',
            $booking->display_status === 'confirmed' && $booking->check_out->lt($today) => 'completed',
            $booking->display_status === 'confirmed' && $booking->check_in->gt($today) => 'upcoming',
            $booking->display_status === 'confirmed' => 'valid',
            $booking->display_status === 'pending' => 'pending',
            default => 'invalid', // annulée, refusée ou expirée
        };

        return view('verify', [
            'booking' => $booking,
            'state' => $state,
            'tenant' => $this->shortName($booking->user?->name),
        ]);
    }

    /** « Kouassi Aya Marie » → « Kouassi A. » */
    private function shortName(?string $name): string
    {
        $parts = preg_split('/\s+/', trim((string) $name)) ?: [];
        if (count($parts) < 2) {
            return $parts[0] ?? '—';
        }

        return $parts[0].' '.Str::upper(Str::substr($parts[1], 0, 1)).'.';
    }
}
