package com.abitechnologie.remci.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abitechnologie.remci.data.Property
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.BookingRepository
import com.abitechnologie.remci.ui.components.CircleIconButton
import com.abitechnologie.remci.ui.components.dialNumber
import com.abitechnologie.remci.data.network.BookedRangeDto
import com.abitechnologie.remci.ui.components.formatFcfa
import com.abitechnologie.remci.ui.components.formatIsoDate
import com.abitechnologie.remci.ui.components.formatMillisDate
import com.abitechnologie.remci.ui.components.openWhatsAppTo
import com.abitechnologie.remci.ui.components.TopBar
import com.abitechnologie.remci.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

private const val DAY_MS = 24L * 60 * 60 * 1000

/** Minuit UTC du jour actuel : le sélecteur de dates de Material 3 travaille en UTC. */
private fun todayUtcMillis(): Long {
    val local = Calendar.getInstance()
    return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        clear()
        set(local.get(Calendar.YEAR), local.get(Calendar.MONTH), local.get(Calendar.DAY_OF_MONTH))
    }.timeInMillis
}

/** "yyyy-MM-dd" (API) → millisecondes UTC. */
private fun isoToMillis(iso: String): Long? = try {
    SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(iso.take(10))?.time
} catch (_: Exception) {
    null
}

/** "yyyy-MM-dd" — format attendu par l'API. */
private fun isoFromMillis(utcMillis: Long): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(utcMillis))

/**
 * Plus de paiement en ligne : on enregistre la demande de réservation (dates, invités)
 * puis on redirige le locataire vers WhatsApp (ou l'appel direct) du propriétaire pour
 * finaliser avec lui.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingScreen(
    property: Property,
    /** Demandes déjà envoyées aujourd'hui avec ce compte, et limite quotidienne (3). */
    bookingsToday: Int,
    dailyLimit: Int,
    onBack: () -> Unit,
    /** Appelé quand le serveur dit que le dossier locataire est incomplet. */
    onNeedProfile: () -> Unit,
    onConfirm: (bookingId: Int, reference: String?) -> Unit
) {
    val context = LocalContext.current
    val repository = remember { BookingRepository() }
    var bookedRanges by remember { mutableStateOf<List<BookedRangeDto>>(emptyList()) }
    LaunchedEffect(property.id) { bookedRanges = repository.getAvailability(property.id) }

    var nights by remember { mutableStateOf(2) }
    var guests by remember { mutableStateOf(1) }
    var arrivalMillis by remember { mutableStateOf(todayUtcMillis()) }
    var showPicker by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var trigger by remember { mutableStateOf(false) }
    // Les deux boutons enregistrent d'abord la demande en base, seule l'action qui suit
    // diffère : ouvrir WhatsApp ou composer directement le numéro.
    var pendingAction by remember { mutableStateOf("whatsapp") }

    val total = property.price * nights
    val hasOwnerPhone = !property.ownerPhone.isNullOrBlank()
    val limit = if (dailyLimit > 0) dailyLimit else 3
    val limitReached = bookingsToday >= limit

    // Dates déjà prises ? (comparaison en UTC, départ exclu)
    val selStart = arrivalMillis
    val selEnd = arrivalMillis + nights * DAY_MS
    val conflict = bookedRanges.firstOrNull { r ->
        val s = isoToMillis(r.checkIn)
        val e = isoToMillis(r.checkOut)
        s != null && e != null && s < selEnd && e > selStart
    }
    val canSubmit = !loading && !limitReached && conflict == null

    // Si les dates choisies par défaut sont déjà prises, on saute à la première date libre.
    var autoPicked by remember { mutableStateOf(false) }
    LaunchedEffect(bookedRanges) {
        if (autoPicked || bookedRanges.isEmpty()) return@LaunchedEffect
        autoPicked = true
        var start = arrivalMillis
        repeat(60) {
            val end = start + nights * DAY_MS
            val hit = bookedRanges.firstOrNull { r ->
                val a = isoToMillis(r.checkIn); val b = isoToMillis(r.checkOut)
                a != null && b != null && a < end && b > start
            } ?: return@LaunchedEffect run { arrivalMillis = start }
            start = isoToMillis(hit.checkOut) ?: (start + DAY_MS)
        }
    }

    fun callOwner() {
        dialNumber(context, property.ownerPhone!!)
    }

    fun openWhatsApp() {
        openWhatsAppTo(
            context, property.ownerPhone!!,
            "Bonjour, je suis intéressé(e) par votre résidence \"${property.title}\" sur REM-CI, " +
                "du ${formatMillisDate(arrivalMillis, "d MMM")} au ${formatMillisDate(arrivalMillis + nights * DAY_MS, "d MMM yyyy")} " +
                "($nights nuit(s), $guests voyageur(s)). Est-elle disponible ?"
        )
    }

    LaunchedEffect(trigger) {
        if (!trigger) return@LaunchedEffect
        val result = repository.createBooking(
            propertyId = property.id,
            checkIn = isoFromMillis(arrivalMillis),
            checkOut = isoFromMillis(arrivalMillis + nights * DAY_MS),
            guests = guests
        )
        loading = false
        trigger = false
        when (result) {
            is ApiResult.Success -> {
                if (hasOwnerPhone) {
                    if (pendingAction == "call") callOwner() else if (pendingAction == "whatsapp") openWhatsApp()
                }
                onConfirm(result.data.id, result.data.reference)
            }
            is ApiResult.Error -> {
                if (result.code == "profile_incomplete") onNeedProfile() else error = result.message
            }
        }
    }

    if (showPicker) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = arrivalMillis,
            selectableDates = object : SelectableDates {
                // Impossible de réserver dans le passé
                override fun isSelectableDate(utcTimeMillis: Long) = utcTimeMillis >= todayUtcMillis()
            }
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { arrivalMillis = it }
                    showPicker = false
                }) { Text("Valider", color = Green, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Annuler", color = Sub) } }
        ) {
            DatePicker(state = pickerState)
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Bg)) {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(bottom = 140.dp)) {
            TopBar("Demande de réservation", onBack)

            Column(modifier = Modifier.padding(horizontal = 18.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardBg, RoundedCornerShape(16.dp))
                        .border(1.dp, Divider, RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Box(modifier = Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(Green)) {
                        property.photos.firstOrNull()?.let {
                            AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(property.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("${property.city}, Côte d'Ivoire", fontSize = 11.sp, color = Sub)
                        Text("${formatFcfa(property.price)} FCFA / nuit", fontSize = 11.sp, color = Green, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(Modifier.height(18.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardBg, RoundedCornerShape(16.dp))
                        .border(1.dp, Divider, RoundedCornerShape(16.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { showPicker = true },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Event, contentDescription = null, tint = Green, modifier = Modifier.size(16.dp))
                            Text("  Arrivée", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                        }
                        Text(
                            formatMillisDate(arrivalMillis), fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = Green,
                            modifier = Modifier
                                .background(Green.copy(alpha = 0.10f), RoundedCornerShape(10.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider(color = Divider)
                    Spacer(Modifier.height(12.dp))
                    StepperRow(Icons.Default.CalendarMonth, "Nuits", nights) { if (it in 1..30) nights = it }
                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider(color = Divider)
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.EventAvailable, contentDescription = null, tint = Green, modifier = Modifier.size(16.dp))
                            Text("  Départ", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                        }
                        Text(formatMillisDate(arrivalMillis + nights * DAY_MS), fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                    }
                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider(color = Divider)
                    Spacer(Modifier.height(12.dp))
                    val maxGuests = property.capacity.coerceAtLeast(1)
                    StepperRow(Icons.Default.People, "Voyageurs (max $maxGuests)", guests) { if (it in 1..maxGuests) guests = it }
                }

                if (conflict != null) {
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().background(OrangeDeep.copy(alpha = 0.10f), RoundedCornerShape(14.dp)).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.EventBusy, contentDescription = null, tint = OrangeDeep, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Indisponible du ${formatIsoDate(conflict.checkIn, "d MMM")} au ${formatIsoDate(conflict.checkOut, "d MMM")}. Change les dates.",
                            fontSize = 11.5.sp, color = Ink, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (limitReached) {
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().background(OrangeDeep.copy(alpha = 0.10f), RoundedCornerShape(14.dp)).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = OrangeDeep, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Limite de $limit demandes par jour atteinte. Réessaie demain.",
                            fontSize = 11.5.sp, color = Ink, fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardBg, RoundedCornerShape(16.dp))
                        .border(1.dp, Divider, RoundedCornerShape(16.dp))
                        .padding(16.dp)
                ) {
                    PriceRow("${formatFcfa(property.price)} FCFA x $nights nuit(s)", "${formatFcfa(total)} FCFA")
                    HorizontalDivider(color = Divider, modifier = Modifier.padding(vertical = 8.dp))
                    PriceRow("Total estimé", "${formatFcfa(total)} FCFA", bold = true)
                }

                if (error != null) {
                    Spacer(Modifier.height(10.dp))
                    Text(error!!, color = OrangeDeep, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(CardBg)
                .navigationBarsPadding()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { pendingAction = if (hasOwnerPhone) "whatsapp" else "none"; loading = true; error = null; trigger = true },
                enabled = canSubmit,
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(color = androidx.compose.ui.graphics.Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                } else if (hasOwnerPhone) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Réserver via WhatsApp", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                } else {
                    Text("Envoyer la demande", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
            if (hasOwnerPhone) {
                OutlinedButton(
                    onClick = { pendingAction = "call"; loading = true; error = null; trigger = true },
                    enabled = canSubmit,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Réserver et appeler", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                }
            }
        }
    }
}

@Composable
private fun StepperRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: Int, onChange: (Int) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Green, modifier = Modifier.size(16.dp))
            Text("  $label", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CircleIconButton(Icons.Default.Remove, onClick = { onChange(value - 1) })
            Text("$value", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            CircleIconButton(Icons.Default.Add, onClick = { onChange(value + 1) })
        }
    }
}

@Composable
private fun PriceRow(label: String, value: String, bold: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = if (bold) 13.sp else 12.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, color = if (bold) Ink else Sub)
        Text(value, fontSize = if (bold) 14.sp else 12.5.sp, fontWeight = if (bold) FontWeight.ExtraBold else FontWeight.SemiBold, color = if (bold) Green else Ink)
    }
}
