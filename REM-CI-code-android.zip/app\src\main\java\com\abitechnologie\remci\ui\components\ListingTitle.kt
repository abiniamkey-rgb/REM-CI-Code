package com.abitechnologie.remci.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.withStyle

/**
 * Titres d'annonce : toujours « Résidence meublée <nom> ».
 * Le propriétaire ne saisit que le nom ; le préfixe est intégré au champ (non modifiable)
 * et le serveur l'impose de toute façon.
 */
object ListingTitle {
    const val PREFIX = "Résidence meublée"

    private val prefixRegex = Regex(
        "^(?:la\\s+|une\\s+)?r[eéèê]sidences?[\\s\\-]+meubl[eéèê]e?s?(?=[\\s:\\-–—,.]|$)\\s*[:\\-–—,.]?\\s*",
        RegexOption.IGNORE_CASE
    )

    /** Nom libre, sans le préfixe (même s'il a été saisi en double). */
    fun nameOf(title: String): String {
        var name = title.trim().replace(Regex("\\s+"), " ")
        repeat(3) { name = prefixRegex.replaceFirst(name, "").trim() }
        return name
    }

    /** Titre complet à envoyer au serveur ("" si aucun nom). */
    fun compose(name: String): String {
        val n = nameOf(name)
        return if (n.isEmpty()) "" else "$PREFIX $n"
    }
}

/** Affiche « Résidence meublée » devant le texte saisi, comme une partie fixe du champ. */
class TitlePrefixTransformation(private val color: Color) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val prefix = ListingTitle.PREFIX + " "
        val out = buildAnnotatedString {
            withStyle(SpanStyle(color = color, fontWeight = FontWeight.SemiBold)) { append(prefix) }
            append(text)
        }
        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int = offset + prefix.length
            override fun transformedToOriginal(offset: Int): Int = (offset - prefix.length).coerceIn(0, text.length)
        }
        return TransformedText(out, mapping)
    }
}
