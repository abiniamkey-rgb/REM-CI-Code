<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Dossier locataire : exigé avant la première demande de réservation.
            // (nom, téléphone, adresse existent déjà ; la pièce d'identité réutilise
            // id_document_url / id_document_verso_url, stockées sur le disque privé.)
            $table->date('birth_date')->nullable();
            $table->string('identity_type', 20)->nullable();      // cni | passeport | attestation | permis
            $table->string('identity_number', 50)->nullable();
            // not_submitted | submitted | verified | rejected
            $table->string('identity_status', 20)->default('not_submitted');
            $table->string('identity_note', 300)->nullable();     // motif d'un refus
            $table->timestamp('identity_verified_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'birth_date', 'identity_type', 'identity_number',
                'identity_status', 'identity_note', 'identity_verified_at',
            ]);
        });
    }
};
