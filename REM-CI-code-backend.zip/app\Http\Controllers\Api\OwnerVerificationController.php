<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\UserNotification;
use Illuminate\Http\Request;

class OwnerVerificationController extends Controller
{
    /**
     * GET /api/owner/verification — statut actuel du dossier du propriétaire connecté.
     */
    public function show(Request $request)
    {
        if (! $request->user()->isOwner()) {
            return response()->json(['message' => 'Réservé aux propriétaires'], 403);
        }

        return new UserResource($request->user());
    }

    /**
     * POST /api/owner/verification — soumission (ou nouvelle soumission après refus)
     * du dossier d'identité du propriétaire : nom, téléphone, adresse, photo recto +
     * verso de la pièce d'identité (la CNI ivoirienne porte des informations des deux
     * côtés). `detected_name`/`detected_id_number` viennent de la reconnaissance de
     * texte faite sur le téléphone (ML Kit) — ce ne sont que des suggestions saisies
     * par l'utilisateur, jamais une validation automatique : le compte passe en
     * "pending" et c'est l'administrateur qui certifie manuellement (phpMyAdmin) en
     * le passant à "verified", après avoir comparé avec les photos.
     */
    public function store(Request $request)
    {
        $user = $request->user();

        if (! $user->isOwner()) {
            return response()->json(['message' => 'Réservé aux propriétaires'], 403);
        }

        // Sécurité : un propriétaire CERTIFIÉ ne peut pas renvoyer un dossier pour changer de nom ou
        // de numéro (ses annonces publiées garderaient la certification). Cela passe par l'administrateur.
        if ($user->owner_verification_status === 'verified') {
            return response()->json([
                'message' => 'Ton identité est déjà certifiée. Pour modifier ton dossier, contacte l\'administrateur REM-CI au '
                    .UserNotification::adminContacts().'.',
                'code' => 'already_verified',
            ], 422);
        }

        $request->merge(['phone' => preg_replace('/[\s.\-()]+/', '', trim((string) $request->phone))]);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'regex:/^\+?[0-9]{8,15}$/', \Illuminate\Validation\Rule::unique('users', 'phone')->ignore($user->id)],
            'address' => ['required', 'string', 'max:255'],
            'id_document_recto' => ['required', 'image', 'max:8192'],
            'id_document_verso' => ['required', 'image', 'max:8192'],
        ], [
            'phone.regex' => 'Numéro de téléphone invalide.',
            'phone.unique' => 'Ce numéro est déjà utilisé par un autre compte.',
            'detected_name' => ['nullable', 'string', 'max:255'],
            'detected_id_number' => ['nullable', 'string', 'max:50'],
        ]);

        // Disque PRIVÉ (storage/app/private) : une pièce d'identité ne doit jamais être
        // accessible par une URL publique. Seul le panneau /admin peut l'afficher.
        // Anciennes photos (dossier renvoyé après un refus) : supprimées, on ne garde que la dernière version.
        foreach ([$user->id_document_url, $user->id_document_verso_url] as $old) {
            if ($old) {
                foreach (['local', 'public'] as $disk) {
                    \Illuminate\Support\Facades\Storage::disk($disk)->delete($old);
                }
            }
        }

        $rectoPath = $request->file('id_document_recto')->store('owner_documents', 'local');
        $versoPath = $request->file('id_document_verso')->store('owner_documents', 'local');

        $user->update([
            'name' => $data['name'],
            'phone' => $data['phone'],
            'address' => $data['address'],
            'id_document_url' => $rectoPath,
            'id_document_verso_url' => $versoPath,
            'detected_name' => $data['detected_name'] ?? null,
            'detected_id_number' => $data['detected_id_number'] ?? null,
            'owner_verification_status' => 'pending',
        ]);

        UserNotification::notify(
            $user, 'verification', 'Dossier reçu',
            "Ton dossier d'identité a bien été envoyé. Pour accélérer sa validation, contacte l'administrateur REM-CI au ".UserNotification::adminContacts().'.'
        );

        return new UserResource($user->fresh());
    }
}
