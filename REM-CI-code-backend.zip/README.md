# Backend REM-CI — Laravel API

Ce dossier contient **uniquement les fichiers métier** (migrations, modèles, contrôleurs, routes, seeders) à déposer dans une installation Laravel fraîche. Comme je n'ai pas d'accès réseau/PHP ici pour exécuter Composer, voici la marche à suivre exacte.

## 1. Créer le projet Laravel (chez toi, en local)

```bash
composer create-project laravel/laravel remci-backend
cd remci-backend
composer require laravel/sanctum
php artisan install:api
```

`php artisan install:api` crée automatiquement `routes/api.php` et configure Sanctum (l'auth par token utilisée par l'app mobile).

## 2. Copier les fichiers de ce dossier

Copie-colle (en écrasant si demandé) :
- `database/migrations/*` → `remci-backend/database/migrations/`
- `database/seeders/*` → `remci-backend/database/seeders/`
- `app/Models/*` → `remci-backend/app/Models/`
- `app/Http/Controllers/Api/*` → `remci-backend/app/Http/Controllers/Api/`
- `app/Http/Resources/*` → `remci-backend/app/Http/Resources/`
- `routes/api.php` → remplace celui généré par `install:api`

## 3. Configurer la base de données

Dans `.env` :
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=remci
DB_USERNAME=root
DB_PASSWORD=
```
(MySQL/MariaDB recommandé ; SQLite fonctionne aussi pour tester vite : `DB_CONNECTION=sqlite` + créer `database/database.sqlite`)

## 4. Migrer et peupler la base

```bash
php artisan migrate
php artisan db:seed
```

Ça crée : les 10 villes, les équipements, les 8 résidences de démo (identiques au prototype), les 3 publicités du carrousel, un compte propriétaire et un compte locataire de test :

| Rôle | Téléphone | Mot de passe |
|---|---|---|
| Locataire | `+2250700000000` | `password` |
| Propriétaire | `+2250700000001` | `password` |

## 5. Lancer le serveur

```bash
php artisan serve
```
L'API est disponible sur `http://127.0.0.1:8000/api`.
Pour tester depuis un vrai téléphone/émulateur Android, utilise plutôt :
```bash
php artisan serve --host=0.0.0.0 --port=8000
```
et l'IP locale de ta machine (ex. `http://192.168.1.20:8000/api`) — `localhost` ne fonctionne pas depuis un appareil physique. Sur l'émulateur Android Studio, l'IP spéciale `http://10.0.2.2:8000/api` pointe vers ta machine hôte.

## 6. Tester les routes (Postman / curl)

```bash
# Connexion
curl -X POST http://127.0.0.1:8000/api/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"+2250700000000","password":"password"}'

# Liste des résidences
curl http://127.0.0.1:8000/api/properties

# Résidences filtrées par ville
curl "http://127.0.0.1:8000/api/properties?city=abidjan"

# Route protégée (remplace TOKEN par celui reçu au login)
curl http://127.0.0.1:8000/api/me -H "Authorization: Bearer TOKEN"
```

## Récapitulatif des routes

| Méthode | Route | Auth | Description |
|---|---|---|---|
| POST | `/api/register` | non | Créer un compte |
| POST | `/api/login` | non | Connexion (téléphone + mot de passe) |
| POST | `/api/logout` | oui | Déconnexion |
| GET | `/api/me` | oui | Profil connecté |
| GET | `/api/cities` | non | Liste des villes |
| GET | `/api/ads` | non | Publicités du carrousel accueil |
| GET | `/api/properties` | non | Résidences **publiées et payées** (filtres: `city`, `search`, `min_price`, `max_price`, `featured`) |
| GET | `/api/properties/{id}` | non | Détail d'une résidence |
| POST | `/api/properties` | oui (propriétaire) | Créer une annonce (reste invisible tant que non payée) |
| PATCH | `/api/properties/{id}` | oui (propriétaire) | Modifier une annonce |
| GET | `/api/my-properties` | oui (propriétaire) | **Toutes** mes résidences, y compris non payées |
| POST | `/api/properties/{id}/pay-listing` | oui (propriétaire) | **Payer les 10 000 FCFA de publication** → rend la résidence visible |
| GET | `/api/bookings` | oui | Mes réservations |
| POST | `/api/bookings` | oui | Créer une réservation (commission REM-CI : 1 000 FCFA incluse dans `service_fee`) |
| PATCH | `/api/bookings/{id}/cancel` | oui | Annuler |
| POST | `/api/bookings/{id}/pay` | oui | Payer (Orange/Moov/MTN/Wave/carte — actuellement simulé) |
| GET | `/api/favorites` | oui | Mes favoris |
| POST | `/api/favorites/{property}` | oui | Ajouter/retirer un favori |

## Modèle économique — comment ça marche maintenant

1. **Un propriétaire crée une résidence** via `POST /api/properties` → elle est enregistrée mais **invisible** aux locataires (`listing_fee_status = unpaid`)
2. **Il paie 10 000 FCFA** via `POST /api/properties/{id}/pay-listing` → la résidence devient visible immédiatement dans `/api/properties`
3. **Un locataire réserve** → chaque réservation inclut automatiquement 1 000 FCFA de commission REM-CI (`service_fee` dans la réponse de `/api/bookings`)

⚠️ Ces paiements sont **simulés** pour l'instant (comme le paiement de réservation) — l'argent ne bouge pas réellement tant qu'un vrai prestataire (CinetPay/PayDunya) n'est pas branché.

## Mettre à jour un projet déjà installé

Si tu as déjà un projet `remci-backend` fonctionnel, copie simplement les fichiers modifiés de ce zip par-dessus (écrase), puis lance dans PowerShell :
```
cd remci-backend
php artisan migrate
```
(Pas besoin de refaire `composer create-project` ni `db:seed` — la nouvelle migration s'ajoute simplement aux tables existantes.)

## Prochaine étape : brancher l'app Android

Dans le projet `RemCiAndroid`, il faudra ajouter Retrofit + un intercepteur qui joint `Authorization: Bearer <token>` (stocké après login via `EncryptedSharedPreferences` ou DataStore) à chaque appel. Dis-moi quand tu veux t'y attaquer et je génère les fichiers Kotlin (`ApiService.kt`, `RetrofitClient.kt`, `AuthRepository.kt`) qui consomment exactement ces routes.

## Paiement mobile money — important

Le endpoint `/api/bookings/{id}/pay` simule actuellement un paiement réussi pour que tu puisses tester le flux complet de l'app. Les vraies intégrations demandent chacune un compte marchand :
- **Orange Money** : Orange Developer Portal (API Web Payment)
- **MTN MoMo** : MTN MoMo Developer Portal (Collection API)
- **Moov Money** : partenariat direct avec Moov Africa Côte d'Ivoire
- **Wave** : Wave Business (Checkout API)

Le plus simple en pratique : passer par un **agrégateur ivoirien** comme **CinetPay** ou **PayDunya**, qui unifient déjà Orange/MTN/Moov/Wave/carte derrière une seule API — ça évite 4 intégrations séparées. Dis-moi si tu veux qu'on branche l'un d'eux.

## Panneau d'administration web (/admin)

1. Copier `app`, `resources`, `routes`, `database`, `config` dans le projet Laravel (en écrasant).
2. `php artisan migrate` (crée aussi la table `sessions` si elle manque) puis `php artisan config:clear` et `php artisan route:clear`.
3. Créer le compte admin : `php artisan remci:create-admin`
4. (Une fois) mettre les anciennes pièces d'identité à l'abri : `php artisan remci:secure-documents`
5. Ouvrir `http://127.0.0.1:8000/admin` (ou `https://<ngrok>/admin`) et se connecter avec le téléphone + mot de passe de l'admin.


## Règles côté locataire

- **Dossier locataire obligatoire avant la 1re réservation** (`POST /api/tenant/profile`, multipart) : nom, téléphone (10 chiffres), adresse, date de naissance, type + numéro de pièce d'identité (CNI, passeport, attestation d'identité ou permis) et photos (recto ; verso aussi pour la CNI). Les photos sont stockées sur le disque **privé** et visibles uniquement dans l'admin (`/admin/locataires/{id}`).
- **18 ans minimum** : refusé côté serveur à l'envoi du dossier et à chaque réservation.
- **3 demandes de réservation maximum par jour et par compte** (les demandes annulées comptent aussi). Constante : `Booking::DAILY_LIMIT`.
- Autres contrôles à la réservation : compte locataire uniquement, résidence publiée, pas sa propre résidence, capacité respectée, séjour de 30 nuits maximum, arrivée dans l'année, pas de doublon en cours sur la même résidence, pas de chevauchement de dates.
- `GET /api/properties/{id}/availability` : périodes déjà prises (pour avertir avant l'envoi).
- Les invités (sans token) ne reçoivent plus l'adresse exacte, la position GPS ni les coordonnées du propriétaire.
- Admin : un dossier « à examiner » permet de réserver ; **Refuser** bloque les nouvelles réservations jusqu'à correction (le locataire est notifié).

Après mise à jour : `php artisan migrate` (nouvelle migration `2024_04_01_000001`).
