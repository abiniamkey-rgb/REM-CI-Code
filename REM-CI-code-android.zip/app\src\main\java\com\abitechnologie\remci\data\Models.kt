package com.abitechnologie.remci.data

import androidx.compose.ui.graphics.Color
import com.abitechnologie.remci.ui.theme.Blue
import com.abitechnologie.remci.ui.theme.Gold
import com.abitechnologie.remci.ui.theme.Green
import com.abitechnologie.remci.ui.theme.Orange
import com.abitechnologie.remci.ui.theme.OrangeDeep

data class City(val name: String, val count: Int, val tone: Color)

data class Property(
    val id: Int,
    val title: String,
    val city: String,
    val price: Int,
    val rating: Double,
    val reviews: Int,
    val tag: String,
    val tagColor: Color,
    val beds: Int,
    // Nécessaires pour le flux "contacter le propriétaire" (WhatsApp/appel) qui remplace
    // le paiement en ligne. Ajoutés en fin de liste avec une valeur par défaut pour ne
    // pas casser les appels positionnels existants (ex. SampleProperties ci-dessous).
    val ownerName: String? = null,
    val ownerPhone: String? = null,
    // Données réelles de l'annonce (photos prises par le propriétaire, commodités cochées,
    // description, position GPS) — affichées dans les cartes et la fiche détail.
    val photos: List<String> = emptyList(),
    val description: String? = null,
    val amenities: List<String> = emptyList(),
    val address: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val bathrooms: Int = 1,
    val capacity: Int = 2,
    // Propriétaire dont l'identité a été certifiée par l'équipe REM-CI
    val ownerVerified: Boolean = false,
    // Déclarée par le propriétaire : true = disponible (icône bleue), false = occupée (icône rouge)
    val available: Boolean = true
)

data class Ad(
    val title: String,
    val sub: String,
    val colorA: Color,
    val colorB: Color,
    val imageUrl: String? = null,
    val badge: String? = null,
    val propertyId: Int? = null
)
