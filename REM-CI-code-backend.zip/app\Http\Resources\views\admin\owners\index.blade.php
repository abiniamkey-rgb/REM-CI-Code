@extends('admin.layout')
@section('title', 'Propriétaires')
@section('content')
  <h1>Propriétaires</h1>
  <div class="sub">Dossiers d'identité à certifier ou à refuser.</div>

  <div class="tabs">
    @foreach($statuses as $key => $label)
      <a class="{{ $status === $key ? 'on' : '' }}" href="{{ route('admin.owners.index', ['statut' => $key, 'q' => $search ?: null]) }}">{{ $label }}<small>{{ $counts[$key] ?? 0 }}</small></a>
    @endforeach
    <a class="{{ $status === 'all' ? 'on' : '' }}" href="{{ route('admin.owners.index', ['statut' => 'all', 'q' => $search ?: null]) }}">Tous</a>
  </div>
  <form class="search" method="GET" action="{{ route('admin.owners.index') }}">
    <input type="hidden" name="statut" value="{{ $status }}">
    <input type="text" name="q" value="{{ $search }}" placeholder="Rechercher un nom, un téléphone, un e-mail…">
    <button class="btn" type="submit">Rechercher</button>
  </form>

  <div class="card tablewrap" style="margin-top:12px">
    <table>
      <thead><tr><th>Propriétaire</th><th>Téléphone</th><th>Statut</th><th>Résidences</th><th>Mis à jour</th><th></th></tr></thead>
      <tbody>
      @forelse($owners as $o)
        <tr>
          <td><strong>{{ $o->name }}</strong><div class="sub">{{ $o->email }}</div></td>
          <td>{{ $o->phone }}</td>
          <td>@include('admin._badge', ['status' => $o->owner_verification_status])</td>
          <td>{{ $o->properties_count }}</td>
          <td class="sub">{{ $o->updated_at?->diffForHumans() }}</td>
          <td><a class="btn ghost" href="{{ route('admin.owners.show', $o) }}">Ouvrir</a></td>
        </tr>
      @empty
        <tr><td colspan="6" class="empty">Aucun propriétaire dans cette liste.</td></tr>
      @endforelse
      </tbody>
    </table>
  </div>
  @include('admin._pager', ['items' => $owners])
@endsection
