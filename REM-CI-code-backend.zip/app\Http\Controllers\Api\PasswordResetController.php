<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

/**
 * Mot de passe oublié — sans intervention de l'administrateur :
 *   1) POST /api/password/forgot { identifier }  → code à 6 chiffres envoyé par e-mail
 *   2) POST /api/password/reset  { identifier, code, password, password_confirmation }
 *
 * `identifier` = numéro de téléphone OU adresse e-mail du compte.
 */
class PasswordResetController extends Controller
{
    private const CODE_TTL_MINUTES = 15;
    private const RESEND_COOLDOWN_SECONDS = 60;
    private const MAX_ATTEMPTS = 5;

    public function forgot(Request $request)
    {
        $request->validate(['identifier' => ['required', 'string', 'max:255']]);

        $user = $this->findUser((string) $request->identifier);

        // Réponse volontairement neutre si aucun compte ne correspond.
        if (! $user) {
            return response()->json(['message' => 'Si un compte correspond, un code vient de lui être envoyé.', 'email_hint' => null]);
        }

        if (! $user->email) {
            return response()->json([
                'message' => "Aucune adresse e-mail n'est enregistrée pour ce compte. Crée un nouveau compte avec ton e-mail, ou connecte-toi avec Google.",
            ], 422);
        }

        $last = DB::table('password_reset_codes')->where('user_id', $user->id)->latest('created_at')->first();
        if ($last && Carbon::parse($last->created_at)->diffInSeconds(now(), true) < self::RESEND_COOLDOWN_SECONDS) {
            return response()->json(['message' => 'Patiente une minute avant de redemander un code.'], 429);
        }

        $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        DB::table('password_reset_codes')->where('user_id', $user->id)->delete();
        $id = DB::table('password_reset_codes')->insertGetId([
            'user_id' => $user->id,
            'code_hash' => $this->hash($code),
            'attempts' => 0,
            'expires_at' => now()->addMinutes(self::CODE_TTL_MINUTES),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        try {
            Mail::html($this->emailBody($user->name, $code), function ($message) use ($user) {
                $message->to($user->email)->subject('Ton code de vérification REM-CI');
            });
        } catch (\Throwable $e) {
            Log::error('Envoi du code de récupération impossible : '.$e->getMessage());
            DB::table('password_reset_codes')->where('id', $id)->delete();

            return response()->json(['message' => "Impossible d'envoyer l'e-mail pour le moment. Réessaie dans quelques minutes."], 500);
        }

        return response()->json([
            'message' => 'Un code à 6 chiffres vient d\'être envoyé par e-mail.',
            'email_hint' => $this->maskEmail($user->email),
        ]);
    }

    public function reset(Request $request)
    {
        $request->validate([
            'identifier' => ['required', 'string', 'max:255'],
            'code' => ['required', 'digits:6'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
        ], [
            'code.digits' => 'Le code contient 6 chiffres.',
            'password.min' => 'Le mot de passe doit contenir au moins 6 caractères.',
            'password.confirmed' => 'Les deux mots de passe ne sont pas identiques.',
        ]);

        $invalid = response()->json(['message' => 'Code invalide ou expiré. Demande un nouveau code.'], 422);

        $user = $this->findUser((string) $request->identifier);
        if (! $user) {
            return $invalid;
        }

        $record = DB::table('password_reset_codes')->where('user_id', $user->id)->latest('id')->first();
        if (! $record || now()->greaterThan($record->expires_at) || $record->attempts >= self::MAX_ATTEMPTS) {
            if ($record) {
                DB::table('password_reset_codes')->where('user_id', $user->id)->delete();
            }

            return $invalid;
        }

        if (! hash_equals($record->code_hash, $this->hash((string) $request->code))) {
            DB::table('password_reset_codes')->where('id', $record->id)->increment('attempts');
            $left = self::MAX_ATTEMPTS - ($record->attempts + 1);

            return response()->json([
                'message' => $left > 0 ? "Code incorrect. Il te reste {$left} essai(s)." : 'Trop d\'essais. Demande un nouveau code.',
            ], 422);
        }

        // Le code a été reçu par e-mail : l'adresse est donc prouvée.
        $user->forceFill([
            'password' => $request->password,
            'email_verified_at' => $user->email_verified_at ?? now(),
        ])->save();
        DB::table('password_reset_codes')->where('user_id', $user->id)->delete();
        // Sécurité : toutes les sessions ouvertes avec l'ancien mot de passe sont fermées.
        $user->tokens()->delete();

        return response()->json(['message' => 'Mot de passe modifié. Tu peux maintenant te connecter.']);
    }

    private function findUser(string $identifier): ?User
    {
        $identifier = trim($identifier);

        if (str_contains($identifier, '@')) {
            return User::where('email', strtolower($identifier))->first();
        }

        $normalized = preg_replace('/[\s.\-()]+/', '', $identifier) ?? $identifier;

        return User::whereIn('phone', array_unique([$normalized, $identifier]))->first();
    }

    private function hash(string $code): string
    {
        return hash_hmac('sha256', $code, (string) config('app.key'));
    }

    private function maskEmail(string $email): string
    {
        [$local, $domain] = array_pad(explode('@', $email, 2), 2, '');

        return mb_substr($local, 0, 1).str_repeat('*', max(2, min(6, mb_strlen($local) - 1))).'@'.$domain;
    }

    private function emailBody(string $name, string $code): string
    {
        $name = e(explode(' ', trim($name))[0] ?: 'à toi');
        $ttl = self::CODE_TTL_MINUTES;

        return <<<HTML
<div style="font-family:Arial,Helvetica,sans-serif;max-width:480px;margin:auto;padding:24px;color:#1B231F">
  <h2 style="margin:0 0 4px;color:#0A6C3B">REM<span style="color:#1B231F">-</span><span style="color:#F77F00">CI</span></h2>
  <p style="color:#6B756E;margin:0 0 20px;font-size:13px">Résidences meublées en Côte d'Ivoire</p>
  <p>Bonjour {$name},</p>
  <p>Voici ton code pour choisir un nouveau mot de passe :</p>
  <p style="font-size:34px;letter-spacing:10px;font-weight:bold;background:#FAF7F0;border-radius:12px;padding:16px;text-align:center;margin:20px 0">{$code}</p>
  <p style="font-size:13px;color:#6B756E">Ce code est valable {$ttl} minutes. Si tu n'as rien demandé, ignore ce message : ton mot de passe reste inchangé.</p>
  <p style="font-size:11px;color:#B8B0A0;margin-top:24px">Une technologie ABITECHNOLOGIE</p>
</div>
HTML;
    }
}
