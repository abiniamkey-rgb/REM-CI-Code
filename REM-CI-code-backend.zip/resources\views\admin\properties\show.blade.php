@extends('admin.layout')
@section('title', $property->title)
@section('content')
  <a href="{{ route('admin.properties.index') }}" class="sub">← Retour aux résidences</a>
  <h1 style="margin-top:8px">{{ $property->title }} @include('admin._badge', ['status' => $property->status])</h1>

  <div class="grid two" style="margin-top:14px">
    <div class="card">
      <h2>Détails</h2>
      <dl>
        <dt>Ville</dt><dd>{{ $property->city?->name }}</dd>
        <dt>Adresse</dt><dd>{{ $property->address ?: '—' }}</dd>
        <dt>Prix / nuit</dt><dd>{{ number_format($property->price_per_night, 0, ',', ' ') }} FCFA</dd>
        <dt>Chambres / SdB</dt><dd>{{ $property->beds }} / {{ $property->bathrooms }}</dd>
        <dt>Voyageurs max</dt><dd>{{ $property->capacity }}</dd>
        <dt>Équipements</dt><dd>{{ $property->amenities->pluck('name')->join(', ') ?: '—' }}</dd>
        <dt>Position GPS</dt><dd>@if($property->latitude && $property->longitude)<a target="_blank" rel="noopener" href="https://www.google.com/maps?q={{ $property->latitude }},{{ $property->longitude }}">Voir sur la carte</a>@else — @endif</dd>
        <dt>Créée</dt><dd>{{ $property->created_at?->format('d/m/Y H:i') }}</dd>
      </dl>
      @if($property->description)<p style="margin:14px 0 0">{{ $property->description }}</p>@endif
    </div>

    <div class="card">
      <h2>Propriétaire</h2>
      @if($property->owner)
        <dl>
          <dt>Nom</dt><dd><a href="{{ route('admin.owners.show', $property->owner) }}">{{ $property->owner->name }}</a></dd>
          <dt>Téléphone</dt><dd>{{ $property->owner->phone }}</dd>
          <dt>Dossier</dt><dd>@include('admin._badge', ['status' => $property->owner->owner_verification_status])</dd>
        </dl>
      @endif

      <h2 style="margin-top:20px">Décision</h2>
      @if($property->review_flags)
        <div class="flash err" style="margin-top:0;background:#FFF6EA;color:#8A4B00;border-color:#F5D3A6">
          ⚠ Points à vérifier avant publication : {{ $property->review_flags }}<br>
          <span style="font-weight:500">REM-CI accepte uniquement les résidences meublées de particuliers. Vérifie les photos, la description et appelle le propriétaire avant de publier.</span>
        </div>
      @endif
      @if($property->owner && $property->owner->owner_verification_status !== 'verified')
        <div class="flash err" style="margin-top:0">Le propriétaire n'est pas certifié : la publication est bloquée. <a href="{{ route('admin.owners.show', $property->owner) }}">Examiner son dossier</a></div>
      @endif
      @if($property->photos->count() < \App\Http\Controllers\Admin\PropertyController::MIN_PHOTOS)
        <div class="flash err" style="margin-top:0">Seulement {{ $property->photos->count() }} photo(s) : il en faut au moins {{ \App\Http\Controllers\Admin\PropertyController::MIN_PHOTOS }} pour publier.</div>
      @endif
      <div class="actions">
        @if($property->status !== 'active')
          <form method="POST" action="{{ route('admin.properties.status', $property) }}">@csrf<input type="hidden" name="statut" value="active"><button class="btn" type="submit">✓ Publier la résidence</button></form>
        @endif
        @if($property->status === 'active')
          <form method="POST" action="{{ route('admin.properties.status', $property) }}" onsubmit="return confirm('Retirer cette résidence de la publication ?')">@csrf<input type="hidden" name="statut" value="inactive"><button class="btn red" type="submit">Retirer de la publication</button></form>
        @endif
        @if($property->status === 'inactive')
          <form method="POST" action="{{ route('admin.properties.status', $property) }}">@csrf<input type="hidden" name="statut" value="pending"><button class="btn ghost" type="submit">Remettre en attente</button></form>
        @endif
      </div>
      <div class="sub" style="margin-top:12px">Le propriétaire reçoit automatiquement une notification dans l'application.</div>
    </div>
  </div>

  <div class="card" style="margin-top:14px">
    <h2>Modifier les informations</h2>
    <div class="sub" style="margin-bottom:10px">Le propriétaire ne peut plus changer ces champs une fois la résidence publiée : c'est à toi de le faire s'il te le demande.</div>
    <form method="POST" action="{{ route('admin.properties.details', $property) }}">
      @csrf
      <label for="f_title" style="font-weight:700;font-size:13px">Titre</label>
      <input id="f_title" type="text" name="title" value="{{ old('title', $property->title) }}" required>
      <div class="grid two" style="margin-top:10px">
        <div><label for="f_price" style="font-weight:700;font-size:13px">Prix par nuit (FCFA)</label><input id="f_price" type="text" name="price_per_night" value="{{ old('price_per_night', $property->price_per_night) }}" required></div>
        <div><label for="f_addr" style="font-weight:700;font-size:13px">Adresse / quartier</label><input id="f_addr" type="text" name="address" value="{{ old('address', $property->address) }}"></div>
      </div>
      <div class="grid two" style="margin-top:10px">
        <div><label for="f_beds" style="font-weight:700;font-size:13px">Pièces</label><input id="f_beds" type="text" name="beds" value="{{ old('beds', $property->beds) }}" required></div>
        <div><label for="f_bath" style="font-weight:700;font-size:13px">Salles de bain</label><input id="f_bath" type="text" name="bathrooms" value="{{ old('bathrooms', $property->bathrooms) }}" required></div>
      </div>
      <div style="margin-top:10px"><label for="f_cap" style="font-weight:700;font-size:13px">Voyageurs max</label><input id="f_cap" type="text" name="capacity" value="{{ old('capacity', $property->capacity) }}" required></div>
      <div style="margin-top:10px"><label for="f_desc" style="font-weight:700;font-size:13px">Description</label><textarea id="f_desc" name="description" rows="4">{{ old('description', $property->description) }}</textarea></div>
      <button class="btn" type="submit" style="margin-top:14px">Enregistrer</button>
    </form>
  </div>

  <div class="card" style="margin-top:14px">
    <h2>Photos ({{ $property->photos->count() }})</h2>
    @if($property->photos->isEmpty())
      <div class="sub">Aucune photo.</div>
    @else
      <div class="photos">
        @foreach($property->photos as $photo)
          @if(in_array($photo->id, $missingPhotos))
            <div class="sub" style="background:#FDECEC;border-radius:12px;padding:12px;aspect-ratio:4/3;display:flex;align-items:center;text-align:center">Fichier introuvable sur le serveur<br>({{ $photo->url }})</div>
          @else
            <a href="{{ route('admin.properties.photo', $photo) }}" target="_blank"><img loading="lazy" src="{{ route('admin.properties.photo', $photo) }}" alt="Photo {{ $loop->iteration }}"></a>
          @endif
        @endforeach
      </div>
    @endif
  </div>
@endsection
