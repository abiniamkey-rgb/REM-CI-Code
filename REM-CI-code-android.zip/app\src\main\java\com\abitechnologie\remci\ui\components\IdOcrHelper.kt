package com.abitechnologie.remci.ui.components

import android.graphics.BitmapFactory
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume

/** Ce que la reconnaissance de texte a pu lire sur la photo de la pièce d'identité. */
data class DetectedIdInfo(
    val name: String? = null,
    val idNumber: String? = null
)

// Numéro de la CNI ivoirienne : commence par "CI" suivi de chiffres. On reste tolérant
// aux confusions fréquentes de l'OCR (O/0, I/1) plutôt que de rater une vraie lecture.
private val idNumberRegex = Regex("C[I1][\\s-]?0?\\d{6,9}", RegexOption.IGNORE_CASE)

/**
 * Lit le texte visible sur une photo de pièce d'identité (recto ou verso) avec ML Kit
 * (100% sur le téléphone, gratuit, pas d'appel réseau) et tente d'en extraire le nom,
 * le prénom et le numéro de CNI. Résultat purement indicatif : l'utilisateur reste libre
 * de corriger les champs, et seul l'administrateur certifie le dossier au final.
 */
suspend fun recognizeIdDocument(file: File): DetectedIdInfo = suspendCancellableCoroutine { cont ->
    try {
        val bitmap = BitmapFactory.decodeFile(file.absolutePath)
        if (bitmap == null) {
            cont.resume(DetectedIdInfo())
            return@suspendCancellableCoroutine
        }
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val rawLines = result.textBlocks.flatMap { it.lines }.map { it.text.trim() }

                val idNumber = idNumberRegex.find(result.text)?.value
                    ?.uppercase()
                    ?.replace(" ", "")
                    ?.replace("-", "")
                    ?.replace("O", "0") // confusions OCR courantes dans le bloc de chiffres
                    ?.let { raw ->
                        // On corrige seulement le préfixe "CI", pas les chiffres légitimes.
                        if (raw.startsWith("CI")) raw else "CI" + raw.drop(2)
                    }

                var detectedName: String? = null
                for (i in rawLines.indices) {
                    val line = rawLines[i].uppercase()
                    if (line.contains("NOM") && !line.contains("PRENOM")) {
                        detectedName = extractAfterLabel(rawLines[i], rawLines.getOrNull(i + 1))
                    }
                }
                var detectedFirstName: String? = null
                for (i in rawLines.indices) {
                    val line = rawLines[i].uppercase()
                    if (line.contains("PRENOM")) {
                        detectedFirstName = extractAfterLabel(rawLines[i], rawLines.getOrNull(i + 1))
                    }
                }

                val fullName = listOfNotNull(detectedName, detectedFirstName)
                    .joinToString(" ")
                    .ifBlank { null }

                cont.resume(DetectedIdInfo(name = fullName, idNumber = idNumber))
            }
            .addOnFailureListener {
                cont.resume(DetectedIdInfo())
            }
    } catch (e: Exception) {
        cont.resume(DetectedIdInfo())
    }
}

/** "NOM: KOUADIO" -> "KOUADIO" ; si rien après les ":", on prend la ligne suivante. */
private fun extractAfterLabel(line: String, nextLine: String?): String? {
    val afterColon = line.substringAfter(":", "").trim()
    val value = afterColon.ifBlank { nextLine?.trim().orEmpty() }
    return value
        .filter { it.isLetter() || it.isWhitespace() || it == '-' }
        .trim()
        .takeIf { it.length in 2..40 }
        ?.split(" ")
        ?.joinToString(" ") { word -> word.lowercase().replaceFirstChar { c -> c.uppercase() } }
}
