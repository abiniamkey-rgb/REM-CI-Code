<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserNotification extends Model
{
    protected $fillable = ['user_id', 'type', 'title', 'body', 'data', 'read_at'];

    protected $casts = [
        'data' => 'array',
        'read_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /** Crée une notification sans jamais faire échouer l'action qui l'a déclenchée. */
    public static function notify(?User $user, string $type, string $title, string $body, array $data = []): void
    {
        if (! $user) {
            return;
        }

        try {
            static::create([
                'user_id' => $user->id,
                'type' => $type,
                'title' => $title,
                'body' => $body,
                'data' => $data ?: null,
            ]);
        } catch (\Throwable $e) {
            report($e);
        }
    }

    /** "07 07 98 28 02 / 01 70 69 26 33" */
    public static function adminContacts(): string
    {
        return implode(' / ', config('remci.admin_phones', ['07 07 98 28 02']));
    }
}
