@extends('admin.layout')
@section('title', 'Publicités')
@section('content')
  <style>
    .adgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:16px;margin-top:14px}
    .ad{padding:0;overflow:hidden}
    .ad .pic{position:relative;aspect-ratio:2/1;background:linear-gradient(135deg,var(--green),var(--green-deep))}
    .ad .pic img{width:100%;height:100%;object-fit:cover;display:block}
    .ad .pic .shade{position:absolute;inset:0;background:linear-gradient(0deg,rgba(0,0,0,.72),rgba(0,0,0,.05) 62%)}
    .ad .pic .txt{position:absolute;left:14px;right:14px;bottom:12px;color:#fff}
    .ad .pic .txt b{display:block;font-size:17px;line-height:1.2} .ad .pic .txt span{font-size:12px;opacity:.92}
    .ad .pic .chip{position:absolute;top:10px;left:10px;background:var(--orange);color:#fff;font-weight:800;font-size:12px;border-radius:20px;padding:3px 11px}
    .ad .pic .off{position:absolute;inset:0;background:rgba(250,247,240,.62);display:flex;align-items:center;justify-content:center;font-weight:800;color:var(--ink);letter-spacing:.4px}
    .ad .body{padding:12px 14px}
    .ad .meta{display:flex;flex-wrap:wrap;gap:6px 14px;font-size:12.5px;color:var(--sub);margin-bottom:10px}
    .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
    .form label{display:block;font-weight:700;margin:10px 0 5px;font-size:12.5px}
    .form .two-col{display:grid;grid-template-columns:1fr 1fr;gap:10px}
    .form input[type=file]{padding:8px;border:1px dashed #C9C2AD;border-radius:12px;width:100%;background:#fff}
    .form input[type=date],.form input[type=number]{width:100%;padding:10px 12px;border:1px solid #DDD6C3;border-radius:12px;font:inherit;background:#fff}
    details summary{cursor:pointer;font-weight:700;color:var(--green);margin-top:4px}
    .hint{font-size:12px;color:var(--sub);margin-top:4px}
    .counter{display:inline-block;background:{{ $liveCount >= $max ? 'var(--orange)' : 'var(--green)' }};color:#fff;border-radius:20px;padding:2px 12px;font-weight:800;font-size:13px}
  </style>

  <h1>Publicités <span class="counter">{{ $liveCount }} / {{ $max }} affichées</span></h1>
  <div class="sub">Visuels affichés en haut de l'accueil de l'application, pour les locataires comme pour les visiteurs sans compte. Quatre au maximum à la fois, qui défilent automatiquement.</div>

  <div class="card form" style="margin-top:16px">
    <h2>Ajouter une publicité</h2>
    <form method="POST" action="{{ route('admin.ads.store') }}" enctype="multipart/form-data">
      @csrf
      <label>Image (JPG, PNG ou WebP)</label>
      <input type="file" name="image" accept="image/jpeg,image/png,image/webp" required>
      <div class="hint">Format idéal : <strong>1200 × 600 px</strong> (rapport 2:1). L'image est recadrée au centre automatiquement. Évite d'y mettre du texte important sur les bords : le titre ci-dessous s'affiche en bas de l'image.</div>

      <div class="two-col">
        <div><label>Titre (facultatif)</label><input type="text" name="title" maxlength="60" value="{{ old('title') }}" placeholder="Ex. Week-end à Assinie"></div>
        <div><label>Étiquette promo (facultatif)</label><input type="text" name="badge" maxlength="20" value="{{ old('badge') }}" placeholder="Ex. -20 %"></div>
      </div>
      <label>Sous-titre (facultatif)</label>
      <input type="text" name="subtitle" maxlength="90" value="{{ old('subtitle') }}" placeholder="Ex. Villas avec piscine dès 65 000 FCFA / nuit">

      <div class="two-col">
        <div>
          <label>Résidence mise en avant (facultatif)</label>
          <select name="property_id">
            <option value="">— Aucune —</option>
            @foreach($properties as $p)
              <option value="{{ $p->id }}" @selected(old('property_id') == $p->id)>{{ $p->title }}</option>
            @endforeach
          </select>
          <div class="hint">En touchant la bannière, le visiteur ouvre cette résidence.</div>
        </div>
        <div>
          <label>Afficher jusqu'au (facultatif)</label>
          <input type="date" name="ends_at" value="{{ old('ends_at') }}" min="{{ now()->toDateString() }}">
          <div class="hint">La publicité disparaît toute seule après cette date.</div>
        </div>
      </div>

      <label style="display:flex;gap:8px;align-items:center;font-weight:600"><input type="checkbox" name="active" value="1" checked style="width:auto"> Afficher tout de suite dans l'application</label>
      <div style="margin-top:12px"><button class="btn" type="submit">Ajouter la publicité</button></div>
    </form>
  </div>

  <div class="adgrid">
    @forelse($ads as $ad)
      @php $live = $ad->isLive(); @endphp
      <div class="card ad">
        <div class="pic">
          @if($ad->image_path)<img src="{{ route('media.ad', basename($ad->image_path)) }}" alt="">@endif
          <div class="shade"></div>
          @if($ad->badge)<div class="chip">{{ $ad->badge }}</div>@endif
          @if($ad->title || $ad->subtitle)
            <div class="txt">@if($ad->title)<b>{{ $ad->title }}</b>@endif @if($ad->subtitle)<span>{{ $ad->subtitle }}</span>@endif</div>
          @endif
          @unless($live)<div class="off">{{ $ad->isExpired() ? 'EXPIRÉE' : 'MASQUÉE' }}</div>@endunless
        </div>
        <div class="body">
          <div class="meta">
            <span>{!! $live ? '<strong style="color:var(--green)">● Affichée</strong>' : '○ Non affichée' !!}</span>
            <span>Résidence : {{ $ad->property?->title ?? '—' }}</span>
            <span>Fin : {{ $ad->ends_at ? $ad->ends_at->format('d/m/Y') : 'sans limite' }}</span>
            @unless($ad->image_path)<span style="color:var(--red)">Sans image (ancien format) — ajoute une image</span>@endunless
          </div>
          <div class="row">
            <form method="POST" action="{{ route('admin.ads.toggle', $ad) }}">@csrf
              <button class="btn {{ $ad->active ? 'ghost' : '' }}" type="submit">{{ $ad->active ? 'Masquer' : 'Afficher' }}</button>
            </form>
            <form method="POST" action="{{ route('admin.ads.destroy', $ad) }}" onsubmit="return confirm('Supprimer définitivement cette publicité ?')">@csrf
              <button class="btn red" type="submit">Supprimer</button>
            </form>
          </div>
          <details class="form">
            <summary>Modifier</summary>
            <form method="POST" action="{{ route('admin.ads.update', $ad) }}" enctype="multipart/form-data">
              @csrf
              <label>Remplacer l'image (1200 × 600 px idéal)</label>
              <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
              <div class="two-col">
                <div><label>Titre</label><input type="text" name="title" maxlength="60" value="{{ $ad->title }}"></div>
                <div><label>Étiquette promo</label><input type="text" name="badge" maxlength="20" value="{{ $ad->badge }}"></div>
              </div>
              <label>Sous-titre</label>
              <input type="text" name="subtitle" maxlength="90" value="{{ $ad->subtitle }}">
              <label>Résidence mise en avant</label>
              <select name="property_id">
                <option value="">— Aucune —</option>
                @foreach($properties as $p)
                  <option value="{{ $p->id }}" @selected($ad->property_id == $p->id)>{{ $p->title }}</option>
                @endforeach
              </select>
              <div class="two-col">
                <div><label>Afficher jusqu'au</label><input type="date" name="ends_at" value="{{ $ad->ends_at?->toDateString() }}"></div>
                <div><label>Ordre (0 = premier)</label><input type="number" name="position" min="0" max="99" value="{{ $ad->position }}"></div>
              </div>
              <div style="margin-top:12px"><button class="btn orange" type="submit">Enregistrer</button></div>
            </form>
          </details>
        </div>
      </div>
    @empty
      <div class="card empty" style="grid-column:1/-1">Aucune publicité pour le moment. Ajoute ta première image ci-dessus.</div>
    @endforelse
  </div>
@endsection
