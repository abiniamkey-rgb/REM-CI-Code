<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\CityResource;
use App\Models\City;

class CityController extends Controller
{
    /** GET /api/cities */
    public function index()
    {
        $cities = City::withCount(['properties' => fn ($q) => $q->where('status', 'active')])->get();

        return CityResource::collection($cities);
    }
}
