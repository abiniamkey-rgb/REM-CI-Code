<?php

use App\Support\ListingRules;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('properties', function (Blueprint $table) {
            // Points à vérifier par l'administrateur (signalements automatiques, usage interne)
            $table->text('review_flags')->nullable()->after('status');
        });

        // Annonces existantes : titre au format « Résidence meublée … » et signalements calculés.
        DB::table('properties')->orderBy('id')->each(function ($p) {
            $title = ListingRules::normalizeTitle($p->title) ?: $p->title;
            $flags = array_merge(
                ListingRules::screen($p->title, 'title')['flags'],
                ListingRules::screen($p->description, 'description')['flags']
            );
            DB::table('properties')->where('id', $p->id)->update([
                'title' => $title,
                'review_flags' => $flags ? implode(' ; ', array_unique($flags)) : null,
            ]);
        });
    }

    public function down(): void
    {
        Schema::table('properties', function (Blueprint $table) {
            $table->dropColumn('review_flags');
        });
    }
};
