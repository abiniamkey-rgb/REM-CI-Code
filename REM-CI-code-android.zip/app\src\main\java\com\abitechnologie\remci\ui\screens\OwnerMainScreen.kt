package com.abitechnologie.remci.ui.screens

import android.content.ActivityNotFoundException
import androidx.activity.compose.BackHandler
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import com.abitechnologie.remci.data.AppConfig
import com.abitechnologie.remci.data.network.BookingDto
import com.abitechnologie.remci.data.network.PropertyDto
import com.abitechnologie.remci.data.network.UserDto
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.BookingRepository
import com.abitechnologie.remci.data.repository.ProfileRepository
import com.abitechnologie.remci.data.repository.PropertyRepository
import com.abitechnologie.remci.ui.components.AdminContactBlock
import com.abitechnologie.remci.ui.components.dialNumber
import com.abitechnologie.remci.ui.components.formatFcfa
import com.abitechnologie.remci.ui.components.formatIsoDate
import com.abitechnologie.remci.ui.components.openWhatsAppTo
import com.abitechnologie.remci.ui.components.OwnerBottomTabs
import com.abitechnologie.remci.ui.components.RemCiBottomBar
import com.abitechnologie.remci.ui.components.Tab
import com.abitechnologie.remci.ui.components.clickableNoRipple
import com.abitechnologie.remci.ui.theme.*

/**
 * Espace propriétaire — tableau de bord distinct de celui du locataire : suivi des
 * résidences publiées / en attente, réservations reçues, profil et statut de vérification.
 */
@Composable
fun OwnerMainScreen(
    user: UserDto?,
    onAddProperty: () -> Unit,
    onLogout: () -> Unit,
    onUserUpdated: (UserDto) -> Unit = {},
    onOpenVerification: () -> Unit = {}
) {
    var currentTab by remember { mutableStateOf<Tab>(Tab.OwnerDashboard) }
    var showNotifications by remember { mutableStateOf(false) }
    var unread by remember { mutableStateOf(0) }
    // Résidence en cours de modification (écran plein par-dessus) + compteur pour recharger la liste
    var editing by remember { mutableStateOf<PropertyDto?>(null) }
    var propertiesRefresh by remember { mutableStateOf(0) }
    val profileRepository = remember { ProfileRepository() }

    BackHandler(enabled = editing != null) { editing = null }

    // Compteur de notifications non lues (pastille sur la cloche et dans le profil)
    LaunchedEffect(showNotifications, user?.id) {
        if (!showNotifications) {
            (profileRepository.notifications() as? ApiResult.Success)?.let { unread = it.data.unreadCount }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = { RemCiBottomBar(currentTab, OwnerBottomTabs) { currentTab = it } }
        ) { padding ->
            // Le tableau de bord et le profil ont un en-tête coloré qui passe sous la barre d'état
            val fullBleed = currentTab.route == Tab.OwnerDashboard.route || currentTab.route == Tab.Profile.route
            val topInset = if (fullBleed) Modifier else Modifier.statusBarsPadding()
            Box(modifier = Modifier.fillMaxSize().padding(bottom = padding.calculateBottomPadding()).then(topInset)) {
                when (currentTab.route) {
                    Tab.OwnerResidences.route -> OwnerPropertiesScreen(
                        onAddProperty = onAddProperty,
                        onEditProperty = { editing = it },
                        refreshKey = propertiesRefresh
                    )
                    Tab.OwnerBookings.route -> OwnerBookingsScreen()
                    Tab.Profile.route -> ProfileScreen(
                        role = "proprietaire",
                        user = user,
                        unreadCount = unread,
                        onUserUpdated = onUserUpdated,
                        onLogout = onLogout,
                        onMyProperties = { currentTab = Tab.OwnerResidences },
                        onOpenNotifications = { showNotifications = true },
                        onOpenVerification = onOpenVerification
                    )
                    else -> OwnerDashboardScreen(
                        user = user,
                        unreadCount = unread,
                        onAddProperty = onAddProperty,
                        onSeeBookings = { currentTab = Tab.OwnerBookings },
                        onOpenNotifications = { showNotifications = true }
                    )
                }
            }
        }

        editing?.let { property ->
            Box(modifier = Modifier.fillMaxSize().background(Bg)) {
                EditPropertyScreen(
                    property = property,
                    onBack = { editing = null },
                    onSaved = {
                        editing = null
                        propertiesRefresh++
                    }
                )
            }
        }

        if (showNotifications) {
            Box(modifier = Modifier.fillMaxSize().background(Bg)) {
                NotificationsScreen(
                    onBack = { showNotifications = false },
                    onAllRead = { unread = 0 }
                )
            }
        }
    }
}

@Composable
private fun OwnerDashboardScreen(
    user: UserDto?,
    unreadCount: Int,
    onAddProperty: () -> Unit,
    onSeeBookings: () -> Unit,
    onOpenNotifications: () -> Unit
) {
    val propertyRepository = remember { PropertyRepository() }
    val bookingRepository = remember { BookingRepository() }
    var properties by remember { mutableStateOf<List<PropertyDto>>(emptyList()) }
    var bookings by remember { mutableStateOf<List<BookingDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        (propertyRepository.getMyProperties() as? ApiResult.Success)?.let { properties = it.data }
        (bookingRepository.getOwnerBookings() as? ApiResult.Success)?.let { bookings = it.data }
        loading = false
    }

    val published = properties.count { it.status == "active" }
    val waiting = properties.count { it.status == "pending" }
    val newRequests = bookings.count { it.status == "pending" }
    val confirmed = bookings.count { it.status == "confirmed" }

    Column(modifier = Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())) {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val greeting = if (hour < 18) "Bonjour" else "Bonsoir"
        val ownerName = user?.name?.takeIf { it.isNotBlank() } ?: "Propriétaire"
        val initials = ownerName.trim().split(" ").filter { it.isNotBlank() }.take(2)
            .joinToString("") { it.first().uppercase() }.ifBlank { "?" }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(GreenDeep, Navy)))
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(54.dp).clip(CircleShape).background(Gold),
                contentAlignment = Alignment.Center
            ) {
                Text(initials, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                if (!user?.avatar.isNullOrBlank()) {
                    AsyncImage(
                        model = com.abitechnologie.remci.data.network.secureUrl(user?.avatar),
                        contentDescription = "Photo de profil",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("$greeting,", fontSize = 12.sp, color = Color(0xFFC9D6CD))
                Text(ownerName, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                if (!user?.phone.isNullOrBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = Color(0xFFC9D6CD), modifier = Modifier.size(12.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(user?.phone ?: "", fontSize = 12.sp, color = Color(0xFFC9D6CD))
                    }
                }
            }
            Box(modifier = Modifier.clickableNoRipple(onOpenNotifications).padding(6.dp)) {
                Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.White, modifier = Modifier.size(26.dp))
                if (unreadCount > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(11.dp)
                            .background(Orange, CircleShape)
                            .border(1.5.dp, Navy, CircleShape)
                    )
                }
            }
        }

        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            VerificationBanner(user?.ownerVerificationStatus)

            if (loading) {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Orange, modifier = Modifier.size(26.dp))
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("Publiées", published.toString(), Icons.Default.CheckCircle, Green, Modifier.weight(1f))
                    StatCard("En attente", waiting.toString(), Icons.Default.HourglassTop, OrangeDeep, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("Nouvelles demandes", newRequests.toString(), Icons.Default.NotificationsActive, Blue, Modifier.weight(1f))
                    StatCard("Confirmées", confirmed.toString(), Icons.Default.EventAvailable, Gold, Modifier.weight(1f))
                }
            }

            val usedSlots = properties.count { it.status == "pending" || it.status == "active" }
            val max = com.abitechnologie.remci.data.AppConfig.MAX_PROPERTIES_PER_OWNER
            val dashContext = LocalContext.current
            Button(
                onClick = {
                    if (!loading && usedSlots >= max) {
                        android.widget.Toast.makeText(
                            dashContext,
                            "Tu as atteint la limite de $max résidences par compte. Pour en ajouter une autre, contacte l'administrateur REM-CI au " +
                                com.abitechnologie.remci.data.AppConfig.ADMIN_PHONES_TEXT + ".",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    } else onAddProperty()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Orange),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    if (loading) "Ajouter une résidence" else "Ajouter une résidence ($usedSlots/$max)",
                    fontWeight = FontWeight.Bold, fontSize = 14.sp
                )
            }

            if (newRequests > 0) {
                OutlinedButton(
                    onClick = onSeeBookings,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Text("Voir les $newRequests demande(s) à traiter", fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun VerificationBanner(status: String?) {
    val (title, text, color, icon) = when (status) {
        "verified" -> Quad("Identité certifiée", "Tes résidences peuvent être publiées dès que l'administrateur les active.", Green, Icons.Default.VerifiedUser)
        "pending" -> Quad("Dossier en cours d'examen", "Pour la validation de ton compte et de tes résidences, contacte l'administrateur REM-CI au ${AppConfig.ADMIN_PHONES_TEXT}.", OrangeDeep, Icons.Default.HourglassTop)
        "rejected" -> Quad("Dossier refusé", "Contacte l'administrateur REM-CI au ${AppConfig.ADMIN_PHONES_TEXT} pour le corriger.", OrangeDeep, Icons.Default.ErrorOutline)
        else -> Quad("Vérification requise", "Soumets ton dossier d'identité (ajoute une résidence pour commencer), puis contacte l'administrateur REM-CI au ${AppConfig.ADMIN_PHONES_TEXT} pour la validation.", Blue, Icons.Default.Info)
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.10f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
                Text(text, fontSize = 11.5.sp, color = Ink, lineHeight = 16.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }
        if (status != "verified") {
            Spacer(Modifier.height(12.dp))
            AdminContactBlock(
                title = null,
                whatsappMessage = "Bonjour, je suis propriétaire sur REM-CI et je souhaite la validation de mon compte / de mes résidences."
            )
        }
    }
}

private data class Quad(val title: String, val text: String, val color: Color, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
private fun StatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(CardBg, RoundedCornerShape(16.dp))
            .border(1.dp, Divider, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(8.dp))
        Text(value, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text(label, fontSize = 11.sp, color = Sub)
    }
}

/** Réservations reçues sur les résidences du propriétaire — à confirmer, refuser ou recontacter. */
@Composable
fun OwnerBookingsScreen() {
    val repository = remember { BookingRepository() }
    val scope = rememberCoroutineScope()
    var bookings by remember { mutableStateOf<List<BookingDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var receipt by remember { mutableStateOf<com.abitechnologie.remci.ui.components.ReceiptData?>(null) }

    LaunchedEffect(Unit) {
        when (val r = repository.getOwnerBookings()) {
            is ApiResult.Success -> bookings = r.data
            is ApiResult.Error -> error = r.message
        }
        loading = false
    }

    fun update(id: Int, status: String) {
        scope.launch {
            when (val r = repository.setOwnerBookingStatus(id, status)) {
                is ApiResult.Success -> bookings = bookings.map { if (it.id == id) r.data else it }
                is ApiResult.Error -> error = r.message
            }
        }
    }

    receipt?.let { ReceiptDialog(it) { receipt = null } }

    Column(modifier = Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())) {
        Text(
            "Réservations reçues",
            fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)
        )
        when {
            loading -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Orange, modifier = Modifier.size(26.dp))
            }
            bookings.isEmpty() -> Column(
                modifier = Modifier.fillMaxWidth().padding(40.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.EventAvailable, contentDescription = null, tint = Sub, modifier = Modifier.size(30.dp))
                Spacer(Modifier.height(10.dp))
                Text(
                    error ?: "Aucune demande pour l'instant. Elles apparaîtront ici dès qu'un locataire réserve l'une de tes résidences.",
                    fontSize = 12.5.sp, color = Sub, textAlign = TextAlign.Center
                )
            }
            else -> Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                bookings.forEach { b ->
                    OwnerBookingCard(
                        b,
                        onConfirm = { update(b.id, "confirmed") },
                        onDecline = { update(b.id, "cancelled") },
                        onComplete = { update(b.id, "completed") },
                        onReceipt = {
                            val me = com.abitechnologie.remci.data.network.TokenManager.getCachedUser()
                            receipt = b.toReceiptData(ownerNameFallback = me?.name, ownerPhoneFallback = me?.phone)
                        }
                    )
                }
                if (error != null) Text(error!!, color = OrangeDeep, fontSize = 11.5.sp)
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun OwnerBookingCard(b: BookingDto, onConfirm: () -> Unit, onDecline: () -> Unit, onComplete: () -> Unit, onReceipt: () -> Unit) {
    val context = LocalContext.current
    val tenantPhone = b.tenant?.phone

    val (label, color) = when (b.status) {
        "pending" -> "À traiter" to Gold
        "confirmed" -> "Confirmée" to Green
        "completed" -> "Terminée" to Sub
        "cancelled" -> "Refusée / annulée" to OrangeDeep
        "expired" -> "Expirée (sans réponse)" to Sub
        else -> b.status to Sub
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(16.dp))
            .border(1.dp, Divider, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(b.property?.title ?: "Résidence", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("${formatIsoDate(b.checkIn)} → ${formatIsoDate(b.checkOut)} · ${b.nights} nuit(s) · ${b.guests} voyageur(s)", fontSize = 11.sp, color = Sub, modifier = Modifier.padding(top = 2.dp))
            }
            Text(
                label, color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.background(color, RoundedCornerShape(20.dp)).padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Person, contentDescription = null, tint = Green, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text(b.tenant?.name ?: "Locataire", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Spacer(Modifier.weight(1f))
            Text("${formatFcfa(b.totalPrice)} FCFA", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Green)
        }
        // Qui est le locataire : âge, commune et état de sa pièce d'identité (la pièce elle-même reste privée)
        b.tenant?.let { t ->
            val details = listOfNotNull(
                t.age?.let { "$it ans" },
                t.address?.takeIf { it.isNotBlank() }
            ).joinToString(" · ")
            if (details.isNotBlank()) {
                Text(details, fontSize = 10.5.sp, color = Sub, modifier = Modifier.padding(start = 20.dp, top = 2.dp))
            }
            Text(
                when {
                    t.identityVerified -> "✓ Identité vérifiée par REM-CI"
                    t.identityProvided -> "Pièce d'identité fournie (vérification en cours)"
                    else -> "Identité non renseignée"
                },
                fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold,
                color = if (t.identityVerified) Green else Sub,
                modifier = Modifier.padding(start = 20.dp, top = 2.dp)
            )
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            if (!tenantPhone.isNullOrBlank()) {
                OutlinedButton(
                    onClick = { dialNumber(context, tenantPhone) },
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Appeler", fontSize = 11.5.sp)
                }
                OutlinedButton(
                    onClick = {
                        openWhatsAppTo(
                            context, tenantPhone,
                            "Bonjour, je suis le propriétaire de « ${b.property?.title ?: "la résidence"} » (REM-CI). " +
                                "J'ai bien reçu votre demande de réservation du ${formatIsoDate(b.checkIn, "d MMM")} au ${formatIsoDate(b.checkOut, "d MMM yyyy")}."
                        )
                    },
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("WhatsApp", fontSize = 11.5.sp)
                }
            }
        }

        if (b.status == "pending") {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = Green),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) { Text("Confirmer", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                OutlinedButton(
                    onClick = onDecline,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = OrangeDeep),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) { Text("Refuser", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
        } else if (b.status == "confirmed") {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = onReceipt,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Voir le reçu du locataire", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = onComplete, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Text("Marquer comme terminée", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        } else if (b.status == "completed") {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onReceipt, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Voir le reçu", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
