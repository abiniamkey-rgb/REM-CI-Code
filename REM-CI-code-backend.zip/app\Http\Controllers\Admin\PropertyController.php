<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Property;
use App\Models\PropertyPhoto;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;

/** Résidences : consulter et activer / retirer la publication. */
class PropertyController extends Controller
{
    public const MIN_PHOTOS = 3;

    public const STATUSES = [
        'pending' => 'En attente',
        'active' => 'Publiées',
        'inactive' => 'Retirées',
    ];

    public function index(Request $request)
    {
        $status = $request->query('statut', 'pending');
        $search = trim((string) $request->query('q', ''));

        $properties = Property::with(['owner', 'city'])
            ->when(array_key_exists($status, self::STATUSES), fn ($q) => $q->where('status', $status))
            ->when($search !== '', fn ($q) => $q->where(fn ($w) => $w
                ->where('title', 'like', "%{$search}%")
                ->orWhere('address', 'like', "%{$search}%")
                ->orWhereHas('owner', fn ($o) => $o->where('name', 'like', "%{$search}%")->orWhere('phone', 'like', "%{$search}%"))))
            ->latest()
            ->paginate(15)
            ->withQueryString();

        $counts = Property::selectRaw('status as s, count(*) as c')->groupBy('status')->pluck('c', 's');

        return view('admin.properties.index', [
            'properties' => $properties,
            'status' => $status,
            'search' => $search,
            'counts' => $counts,
            'statuses' => self::STATUSES,
        ]);
    }

    public function show(Property $property)
    {
        $property->load(['owner', 'city', 'photos', 'amenities']);

        // Photos dont le fichier n'existe plus sur le serveur (pour l'afficher clairement)
        $missingPhotos = $property->photos
            ->filter(fn ($photo) => ! Storage::disk('public')->exists($photo->url))
            ->pluck('id')->all();

        return view('admin.properties.show', ['property' => $property, 'missingPhotos' => $missingPhotos]);
    }

    /** Sert une photo de résidence directement depuis le stockage (sans dépendre du lien public). */
    public function photo(PropertyPhoto $photo)
    {
        abort_unless(Storage::disk('public')->exists($photo->url), 404);

        return Storage::disk('public')->response($photo->url);
    }

    public function setStatus(Request $request, Property $property)
    {
        $data = $request->validate(['statut' => ['required', 'in:active,inactive,pending']]);
        $new = $data['statut'];

        // Règle REM-CI : 5 résidences (en attente + publiées) maximum par propriétaire.
        if (in_array($new, ['active', 'pending'], true) && $property->status === 'inactive'
            && \App\Models\Property::slotsUsedBy($property->owner_id, $property->id) >= \App\Models\Property::MAX_PER_OWNER) {
            return back()->with('erreur', 'Ce propriétaire a déjà '.\App\Models\Property::MAX_PER_OWNER.' résidences en attente ou publiées : retire-en une avant de réactiver celle-ci.');
        }

        // Règle REM-CI : une résidence n'est publiée que si son propriétaire est certifié.
        if ($new === 'active' && $property->owner?->owner_verification_status !== 'verified') {
            return back()->with('erreur', "Impossible de publier : le propriétaire n'est pas encore certifié. Certifie d'abord son dossier.");
        }

        // Règle REM-CI : au moins 3 photos pour publier une annonce.
        if ($new === 'active' && $property->photos()->count() < self::MIN_PHOTOS) {
            return back()->with('erreur', 'Impossible de publier : la résidence doit avoir au moins '.self::MIN_PHOTOS.' photos ('.$property->photos()->count().' actuellement).');
        }

        $property->update(['status' => $new]);

        $message = match ($new) {
            'active' => "« {$property->title} » est publiée. Le propriétaire a reçu une notification.",
            'inactive' => "« {$property->title} » est retirée de la publication.",
            default => "« {$property->title} » est remise en attente.",
        };

        return back()->with('ok', $message);
    }

    /** Modification par l'administrateur des champs verrouillés pour le propriétaire (titre, prix, capacité, adresse…). */
    public function updateDetails(Request $request, Property $property)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:5000'],
            'price_per_night' => ['required', 'integer', 'min:1000'],
            'beds' => ['required', 'integer', 'min:1', 'max:50'],
            'bathrooms' => ['required', 'integer', 'min:1', 'max:50'],
            'capacity' => ['required', 'integer', 'min:1', 'max:100'],
            'address' => ['nullable', 'string', 'max:255'],
        ]);

        $data['title'] = \App\Support\ListingRules::normalizeTitle($data['title']) ?: $property->title;
        $property->update($data);

        return back()->with('ok', 'Informations de la résidence mises à jour.');
    }
}
