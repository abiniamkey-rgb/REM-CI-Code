<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\BookingResource;
use App\Models\Booking;
use App\Models\Property;
use App\Models\UserNotification;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BookingController extends Controller
{
    /** GET /api/bookings — réservations de l'utilisateur connecté */
    public function index(Request $request)
    {
        Booking::expireStale();

        $bookings = $request->user()
            ->bookings()
            ->with('user', 'property.city', 'property.owner', 'property.photos')
            ->latest()
            ->limit(100)
            ->get();

        return BookingResource::collection($bookings);
    }

    /** GET /api/bookings/{booking} */
    public function show(Request $request, Booking $booking)
    {
        Booking::expireStale();
        $booking->refresh();

        if ($booking->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Non autorisé'], 403);
        }

        return new BookingResource($booking->load('user', 'property.city', 'property.owner', 'property.photos'));
    }

    /** POST /api/bookings */
    public function store(Request $request)
    {
        $user = $request->user();
        Booking::expireStale();

        // 1) Seuls les locataires réservent (un propriétaire ou un admin ne peut pas).
        if ($user->role !== 'locataire') {
            return $this->refuse('Seuls les comptes locataires peuvent réserver une résidence.', 'not_tenant', 403);
        }

        // 2) Dossier locataire complet : identité, adresse, contact, pièce d'identité.
        if (! $user->hasTenantProfile()) {
            $message = $user->identity_status === 'rejected'
                ? 'Ton dossier a été refusé'.($user->identity_note ? " ({$user->identity_note})" : '').'. Corrige-le puis renvoie-le pour pouvoir réserver.'
                : "Pour réserver, complète d'abord ton dossier : identité, date de naissance, adresse et pièce d'identité.";

            return $this->refuse($message, 'profile_incomplete', 403);
        }

        // 3) Majorité : 18 ans minimum.
        if (($user->age() ?? 0) < TenantProfileController::MIN_AGE) {
            return $this->refuse('Tu dois avoir au moins '.TenantProfileController::MIN_AGE.' ans pour réserver une résidence.', 'underage', 403);
        }

        $data = $request->validate([
            'property_id' => ['required', 'exists:properties,id'],
            'check_in' => ['required', 'date_format:Y-m-d', 'after_or_equal:today', 'before_or_equal:'.now()->addYear()->toDateString()],
            'check_out' => ['required', 'date_format:Y-m-d', 'after:check_in'],
            'guests' => ['required', 'integer', 'min:1'],
        ], [
            'check_in.after_or_equal' => "La date d'arrivée ne peut pas être dans le passé.",
            'check_in.before_or_equal' => "Tu ne peux pas réserver à plus d'un an à l'avance.",
            'check_out.after' => "La date de départ doit être après la date d'arrivée.",
        ]);

        $property = Property::with('owner')->findOrFail($data['property_id']);

        // 4) Seules les résidences publiées se réservent ; jamais sa propre résidence.
        if ($property->status !== 'active') {
            return $this->refuse("Cette résidence n'est plus disponible à la réservation.", 'property_unavailable', 422);
        }
        // Le propriétaire a marqué sa résidence « occupée » (icône rouge dans l'application).
        if (! $property->is_available) {
            return $this->refuse(
                "Cette résidence est actuellement occupée. Le propriétaire la remettra en « disponible » dès qu'elle se libère : réessaie plus tard ou contacte-le directement.",
                'property_occupied', 422
            );
        }
        if ($property->owner_id === $user->id) {
            return $this->refuse('Tu ne peux pas réserver ta propre résidence.', 'own_property', 422);
        }

        $checkIn = Carbon::parse($data['check_in'])->startOfDay();
        $checkOut = Carbon::parse($data['check_out'])->startOfDay();
        $nights = $checkIn->diffInDays($checkOut);

        if ($nights > Booking::MAX_NIGHTS) {
            return $this->refuse('Un séjour est limité à '.Booking::MAX_NIGHTS.' nuits par demande.', 'too_long', 422);
        }
        if ($data['guests'] > max(1, (int) $property->capacity)) {
            return $this->refuse('Cette résidence accueille '.max(1, (int) $property->capacity).' voyageur(s) au maximum.', 'too_many_guests', 422);
        }

        // Plus de paiement en ligne : la réservation n'est qu'une demande enregistrée.
        // Le locataire est ensuite redirigé vers WhatsApp/l'appel direct du propriétaire
        // pour finaliser avec lui (dates, prix, modalités).
        $outcome = DB::transaction(function () use ($user, $property, $data, $checkIn, $checkOut, $nights) {
            // 5) Maximum 3 demandes par jour et par compte.
            if (Booking::sentTodayBy($user->id) >= Booking::DAILY_LIMIT) {
                return ['error' => $this->refuse(
                    'Tu as atteint la limite de '.Booking::DAILY_LIMIT.' demandes de réservation par jour. Réessaie demain.',
                    'daily_limit', 429
                )];
            }

            // 6) Pas deux demandes en cours pour la même résidence.
            $already = Booking::where('user_id', $user->id)
                ->where('property_id', $property->id)
                ->whereIn('status', ['pending', 'confirmed'])
                ->whereDate('check_out', '>=', now()->toDateString())
                ->exists();
            if ($already) {
                return ['error' => $this->refuse(
                    "Tu as déjà une demande en cours pour cette résidence. Retrouve-la dans l'onglet Réservations.",
                    'duplicate', 409
                )];
            }

            // 7) Empêche le chevauchement avec une demande en attente ou confirmée.
            $overlap = $property->bookings()
                ->whereIn('status', ['pending', 'confirmed'])
                ->where('check_in', '<', $checkOut)
                ->where('check_out', '>', $checkIn)
                ->exists();
            if ($overlap) {
                return ['error' => $this->refuse('Ces dates ne sont plus disponibles pour cette résidence.', 'dates_taken', 409)];
            }

            return ['booking' => Booking::create([
                'user_id' => $user->id,
                'property_id' => $property->id,
                'check_in' => $checkIn,
                'check_out' => $checkOut,
                'guests' => $data['guests'],
                'nights' => $nights,
                'price_per_night' => $property->price_per_night,
                'service_fee' => 0,
                'total_price' => $property->price_per_night * $nights,
                'status' => 'pending',
                'payment_status' => 'unpaid',
            ])];
        });

        if (isset($outcome['error'])) {
            return $outcome['error'];
        }
        $booking = $outcome['booking'];

        $age = $user->age();
        UserNotification::notify(
            $property->owner, 'booking_request', 'Nouvelle demande de réservation',
            $user->name.($age ? " ({$age} ans)" : '').' souhaite réserver « '.$property->title.' » du '
                .$checkIn->format('d/m/Y').' au '.$checkOut->format('d/m/Y').' ('.$nights.' nuit(s), '.$data['guests'].' voyageur(s)). '
                .'Identité fournie : '.($user->identity_status === 'verified' ? 'vérifiée par REM-CI' : 'en cours de vérification').'. Contacte-le pour finaliser.',
            ['booking_id' => $booking->id]
        );

        return new BookingResource($booking->load('user', 'property.city', 'property.owner', 'property.photos'));
    }

    /** PATCH /api/bookings/{booking}/cancel */
    public function cancel(Request $request, Booking $booking)
    {
        if ($booking->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Non autorisé'], 403);
        }

        if (! in_array($booking->status, ['pending', 'confirmed'], true)) {
            return $this->refuse('Cette demande ne peut plus être annulée.', 'not_cancellable', 422);
        }

        $booking->update(['status' => 'cancelled']);

        $booking->load('user', 'property.owner', 'property.city', 'property.photos');
        UserNotification::notify(
            $booking->property?->owner, 'booking_update', 'Demande annulée',
            $request->user()->name.' a annulé sa demande pour « '.$booking->property?->title.' ».',
            ['booking_id' => $booking->id]
        );

        return new BookingResource($booking);
    }

    /**
     * GET /api/properties/{property}/availability — périodes déjà prises (demandes en attente
     * ou confirmées, à venir). Permet à l'app d'avertir avant l'envoi de la demande.
     */
    public function availability(Property $property)
    {
        if ($property->status !== 'active') {
            return response()->json(['data' => []]);
        }

        Booking::expireStale();

        $ranges = $property->bookings()
            ->whereIn('status', ['pending', 'confirmed'])
            ->whereDate('check_out', '>=', now()->toDateString())
            ->orderBy('check_in')
            ->get(['check_in', 'check_out'])
            ->map(fn ($b) => [
                'check_in' => $b->check_in->toDateString(),
                'check_out' => $b->check_out->toDateString(),
            ]);

        return response()->json(['data' => $ranges]);
    }

    /** Réponse d'erreur avec un `code` lisible par l'app (en plus du message). */
    private function refuse(string $message, string $code, int $status)
    {
        return response()->json(['message' => $message, 'code' => $code], $status);
    }
}
