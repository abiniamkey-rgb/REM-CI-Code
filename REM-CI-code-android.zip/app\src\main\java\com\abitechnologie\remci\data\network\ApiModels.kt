package com.abitechnologie.remci.data.network

import com.google.gson.annotations.SerializedName

/* ---- Enveloppes génériques (Laravel ApiResource renvoie {"data": ...}) ---- */
data class DataWrapper<T>(val data: T)
data class ListWrapper<T>(val data: List<T>)

/* ---- Auth ---- */
data class RegisterRequest(
    val name: String,
    val phone: String,
    val email: String? = null,
    val password: String,
    val role: String // "locataire" ou "proprietaire"
)

// `role` = mode choisi avec le bouton Locataire / Propriétaire de l'écran de connexion
data class LoginRequest(val phone: String, val password: String, val role: String? = null)

/** Connexion avec Google : jeton d'identité fourni par Google + rôle choisi dans l'app */
data class GoogleLoginRequest(@SerializedName("id_token") val idToken: String, val role: String)

/* ---- Mot de passe oublié (code à 6 chiffres envoyé par e-mail) ---- */
data class ForgotPasswordRequest(val identifier: String)

data class ForgotPasswordResponse(
    val message: String,
    // Adresse masquée (ex. a*****@gmail.com) pour que l'utilisateur sache où regarder
    @SerializedName("email_hint") val emailHint: String? = null
)

data class ResetPasswordRequest(
    val identifier: String,
    val code: String,
    val password: String,
    @SerializedName("password_confirmation") val passwordConfirmation: String
)

data class AuthResponse(
    val message: String,
    val user: UserDto,
    val token: String
)

data class UserDto(
    val id: Int,
    val name: String,
    val email: String?,
    val phone: String?,
    val role: String,
    val avatar: String?,
    @SerializedName("is_verified") val isVerified: Boolean,
    val address: String? = null,
    @SerializedName("owner_verification_status") val ownerVerificationStatus: String? = null,
    // true pour un propriétaire qui n'a encore jamais soumis son dossier d'identité —
    // sert à le rediriger automatiquement vers l'écran de vérification après connexion.
    @SerializedName("needs_owner_verification") val needsOwnerVerification: Boolean = false,
    @SerializedName("detected_name") val detectedName: String? = null,
    @SerializedName("detected_id_number") val detectedIdNumber: String? = null,
    // --- Dossier locataire (renseignés uniquement pour un compte locataire) ---
    @SerializedName("birth_date") val birthDate: String? = null,
    val age: Int? = null,
    @SerializedName("identity_type") val identityType: String? = null,
    @SerializedName("identity_number") val identityNumber: String? = null,
    // not_submitted | submitted | verified | rejected
    @SerializedName("identity_status") val identityStatus: String? = null,
    @SerializedName("identity_note") val identityNote: String? = null,
    @SerializedName("tenant_profile_complete") val tenantProfileComplete: Boolean = false,
    @SerializedName("bookings_today") val bookingsToday: Int = 0,
    @SerializedName("daily_booking_limit") val dailyBookingLimit: Int = 3
)

/* ---- Villes ---- */
data class CityDto(
    val id: Int,
    val name: String,
    val slug: String,
    @SerializedName("tone_color") val toneColor: String,
    @SerializedName("photo_url") val photoUrl: String?,
    @SerializedName("properties_count") val propertiesCount: Int?
)

/* ---- Publicités (carrousel accueil) ---- */
data class AdDto(
    val id: Int,
    val title: String,
    val subtitle: String?,
    @SerializedName("image_url") val imageUrl: String? = null,
    val badge: String? = null,
    @SerializedName("color_a") val colorA: String,
    @SerializedName("color_b") val colorB: String,
    @SerializedName("property_id") val propertyId: Int?
)

/* ---- Résidences ---- */
data class PropertyDto(
    val id: Int,
    val title: String,
    val slug: String,
    val description: String?,
    @SerializedName("price_per_night") val pricePerNight: Int,
    val beds: Int,
    val bathrooms: Int,
    val capacity: Int,
    val address: String?,
    val latitude: Double?,
    val longitude: Double?,
    val status: String,
    val tag: String?,
    @SerializedName("is_featured") val isFeatured: Boolean,
    val rating: Double,
    @SerializedName("reviews_count") val reviewsCount: Int,
    val city: CityDto?,
    val owner: UserDto?,
    val photos: List<String>?,
    val amenities: List<AmenityDto>?,
    @SerializedName("is_favorite") val isFavorite: Boolean?,
    // Disponibilité déclarée par le propriétaire (null = ancienne réponse du serveur → disponible)
    @SerializedName("is_available") val isAvailable: Boolean? = null
)

/** Requête pour créer une résidence (propriétaire) */
data class CreatePropertyRequest(
    val title: String,
    @SerializedName("city_id") val cityId: Int,
    val description: String?,
    @SerializedName("price_per_night") val pricePerNight: Int,
    val beds: Int,
    val bathrooms: Int,
    val capacity: Int,
    val address: String?,
    val latitude: Double? = null,
    val longitude: Double? = null,
    @SerializedName("amenity_ids") val amenityIds: List<Int>? = null
)

/**
 * Modification d'une résidence. Les champs à null ne sont pas envoyés : pour une résidence
 * publiée, seuls la description et les commodités sont transmis (le reste est verrouillé).
 */
data class UpdatePropertyRequest(
    val title: String? = null,
    val description: String? = null,
    @SerializedName("price_per_night") val pricePerNight: Int? = null,
    val beds: Int? = null,
    val bathrooms: Int? = null,
    val capacity: Int? = null,
    val address: String? = null,
    @SerializedName("amenity_ids") val amenityIds: List<Int>? = null
)

/* ---- Notifications de l'app ---- */
data class NotificationDto(
    val id: Int,
    val type: String,
    val title: String,
    val body: String,
    val read: Boolean,
    @SerializedName("created_at") val createdAt: String?
)

data class NotificationsResponse(
    val data: List<NotificationDto>,
    @SerializedName("unread_count") val unreadCount: Int
)

data class ChangePasswordRequest(
    @SerializedName("current_password") val currentPassword: String,
    val password: String,
    @SerializedName("password_confirmation") val passwordConfirmation: String
)

data class DeleteAccountRequest(
    val confirmation: String,
    val password: String? = null
)

data class AmenityDto(val id: Int, val name: String, val icon: String?)

/* ---- Réservations ---- */
data class BookingRequest(
    @SerializedName("property_id") val propertyId: Int,
    @SerializedName("check_in") val checkIn: String,   // format "yyyy-MM-dd"
    @SerializedName("check_out") val checkOut: String,
    val guests: Int
)

data class BookingDto(
    val id: Int,
    @SerializedName("check_in") val checkIn: String,
    @SerializedName("check_out") val checkOut: String,
    val guests: Int,
    val nights: Int,
    @SerializedName("price_per_night") val pricePerNight: Int,
    @SerializedName("service_fee") val serviceFee: Int,
    @SerializedName("total_price") val totalPrice: Int,
    val status: String,
    val property: PropertyDto?,
    // Renseigné côté propriétaire : le locataire qui a fait la demande
    val tenant: TenantDto? = null,
    // Numéro de réservation (ex. REMCI-K7Q3PX9M), repris sur le reçu et dans le code QR
    val reference: String? = null,
    @SerializedName("confirmed_at") val confirmedAt: String? = null,
    // Lien de vérification encodé dans le code QR (uniquement pour une réservation confirmée)
    @SerializedName("receipt_url") val receiptUrl: String? = null
)

data class TenantDto(
    val name: String?,
    val phone: String?,
    val address: String? = null,
    val age: Int? = null,
    @SerializedName("identity_provided") val identityProvided: Boolean = false,
    @SerializedName("identity_verified") val identityVerified: Boolean = false
)

/** Période déjà réservée d'une résidence (dates "yyyy-MM-dd", départ exclu). */
data class BookedRangeDto(
    @SerializedName("check_in") val checkIn: String,
    @SerializedName("check_out") val checkOut: String
)

data class FavoriteToggleResponse(val favorite: Boolean)

data class MessageResponse(val message: String)

/* ---- Vérification d'identité du propriétaire (POST/GET /owner/verification, multipart) ----
 * La requête est envoyée en multipart/form-data (nom, téléphone, adresse + photo de la
 * pièce d'identité) directement depuis ApiService, donc pas de data class de requête ici. */
