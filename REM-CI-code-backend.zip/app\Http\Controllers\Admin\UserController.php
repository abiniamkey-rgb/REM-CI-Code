<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    public const IDENTITY = [
        'submitted' => 'À examiner',
        'verified' => 'Vérifiés',
        'rejected' => 'Refusés',
        'not_submitted' => 'Sans dossier',
    ];

    public function index(Request $request)
    {
        $role = $request->query('role', 'all');
        $identity = $request->query('identite');
        $search = trim((string) $request->query('q', ''));

        $users = User::query()
            ->withCount(['properties', 'bookings'])
            ->when(in_array($role, ['locataire', 'proprietaire', 'admin'], true), fn ($q) => $q->where('role', $role))
            ->when(array_key_exists((string) $identity, self::IDENTITY), fn ($q) => $q->where('role', 'locataire')->where('identity_status', $identity))
            ->when($search !== '', fn ($q) => $q->where(fn ($w) => $w
                ->where('name', 'like', "%{$search}%")
                ->orWhere('phone', 'like', "%{$search}%")
                ->orWhere('email', 'like', "%{$search}%")))
            ->latest()
            ->paginate(20)
            ->withQueryString();

        $counts = User::selectRaw('role as r, count(*) as c')->groupBy('role')->pluck('c', 'r');
        $toReview = User::where('role', 'locataire')->where('identity_status', 'submitted')->count();

        return view('admin.users.index', [
            'users' => $users, 'role' => $role, 'search' => $search, 'counts' => $counts,
            'identity' => $identity, 'identityLabels' => self::IDENTITY, 'toReview' => $toReview,
        ]);
    }

    /** Fiche d'un locataire : dossier d'identité, réservations. */
    public function show(User $user)
    {
        abort_unless($user->role === 'locataire', 404);

        $user->load(['bookings' => fn ($q) => $q->latest()->limit(10), 'bookings.property']);

        return view('admin.users.show', [
            'tenant' => $user,
            'hasRecto' => (bool) $this->locateDocument($user->id_document_url),
            'hasVerso' => (bool) $this->locateDocument($user->id_document_verso_url),
        ]);
    }

    /** Sert la photo de la pièce d'identité (jamais d'URL publique : admin connecté uniquement). */
    public function document(User $user, string $side)
    {
        abort_unless($user->role === 'locataire', 404);

        $path = $side === 'verso' ? $user->id_document_verso_url : $user->id_document_url;
        $disk = $this->locateDocument($path);
        abort_unless($disk, 404);

        return Storage::disk($disk)->response($path, null, ['Cache-Control' => 'private, no-store']);
    }

    public function verifyIdentity(User $user)
    {
        abort_unless($user->role === 'locataire', 404);

        if ($user->identity_status === 'not_submitted') {
            return back()->with('erreur', "Ce locataire n'a pas encore envoyé son dossier.");
        }

        $user->update(['identity_status' => 'verified', 'identity_note' => null, 'identity_verified_at' => now()]);

        return back()->with('ok', "L'identité de {$user->name} est vérifiée. Il a reçu une notification.");
    }

    public function rejectIdentity(Request $request, User $user)
    {
        abort_unless($user->role === 'locataire', 404);

        $data = $request->validate(['motif' => ['nullable', 'string', 'max:300']]);

        if ($user->identity_status === 'not_submitted') {
            return back()->with('erreur', "Ce locataire n'a pas encore envoyé son dossier.");
        }

        $user->update([
            'identity_status' => 'rejected',
            'identity_note' => trim((string) ($data['motif'] ?? '')) ?: null,
            'identity_verified_at' => null,
        ]);

        return back()->with('ok', "Le dossier de {$user->name} est refusé. Il a reçu une notification et doit le corriger.");
    }

    private function locateDocument(?string $path): ?string
    {
        if (! $path) {
            return null;
        }
        foreach (['local', 'public'] as $disk) {
            if (Storage::disk($disk)->exists($path)) {
                return $disk;
            }
        }

        return null;
    }
}
