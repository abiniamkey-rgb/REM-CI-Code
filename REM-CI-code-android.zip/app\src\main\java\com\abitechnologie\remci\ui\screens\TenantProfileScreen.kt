package com.abitechnologie.remci.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.abitechnologie.remci.data.network.UserDto
import com.abitechnologie.remci.data.repository.ApiResult
import com.abitechnologie.remci.data.repository.TenantProfileRepository
import com.abitechnologie.remci.ui.components.TopBar
import com.abitechnologie.remci.ui.components.formatMillisDate
import com.abitechnologie.remci.ui.components.rememberDocumentScan
import com.abitechnologie.remci.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/** Âge minimal pour réserver. */
const val TENANT_MIN_AGE = 18

private val ID_TYPES = listOf(
    "cni" to "CNI",
    "passeport" to "Passeport",
    "attestation" to "Attestation d'identité",
    "permis" to "Permis de conduire"
)

/** Dernière date de naissance acceptée (aujourd'hui − 18 ans), en millisecondes UTC. */
private fun latestBirthMillis(): Long {
    val local = Calendar.getInstance()
    return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        clear()
        set(local.get(Calendar.YEAR) - TENANT_MIN_AGE, local.get(Calendar.MONTH), local.get(Calendar.DAY_OF_MONTH))
    }.timeInMillis
}

private fun isoOf(utcMillis: Long): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(java.util.Date(utcMillis))

private fun millisOfIso(iso: String?): Long? = try {
    iso?.take(10)?.let { SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(it)?.time }
} catch (_: Exception) {
    null
}

/**
 * Dossier du locataire — demandé avant la première réservation : identité complète,
 * date de naissance (18 ans minimum), adresse, contact et pièce d'identité (CNI,
 * passeport, attestation d'identité ou permis), photographiée avec l'appareil photo.
 * Les propriétaires savent ainsi à qui ils louent ; l'équipe REM-CI peut vérifier la pièce.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TenantProfileScreen(
    user: UserDto?,
    /** true quand le locataire arrive ici en voulant réserver : le bouton dit « continuer ». */
    forBooking: Boolean,
    onBack: () -> Unit,
    onSaved: (UserDto) -> Unit
) {
    val repository = remember { TenantProfileRepository() }
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf(user?.name.orEmpty()) }
    var phone by remember { mutableStateOf(user?.phone.orEmpty()) }
    var address by remember { mutableStateOf(user?.address.orEmpty()) }
    var birthMillis by remember { mutableStateOf(millisOfIso(user?.birthDate)) }
    var idType by remember { mutableStateOf(user?.identityType ?: "cni") }
    var idNumber by remember { mutableStateOf(user?.identityNumber.orEmpty()) }
    var rectoFile by remember { mutableStateOf<File?>(null) }
    var versoFile by remember { mutableStateOf<File?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val status = user?.identityStatus ?: "not_submitted"
    // Photos déjà envoyées et acceptées : inutile de les reprendre (sauf si le dossier a été refusé)
    val keepsStoredDocs = status == "submitted" || status == "verified"
    val needsVerso = idType == "cni"

    val takeRecto = rememberDocumentScan { rectoFile = it }
    val takeVerso = rememberDocumentScan { versoFile = it }

    fun validate(): Boolean {
        val digits = phone.count { it.isDigit() }
        val msg = when {
            name.trim().length < 3 -> "Indique ton nom complet."
            digits < 10 -> "Numéro de téléphone invalide : 10 chiffres (ex. 07 07 98 28 02)."
            address.trim().length < 5 -> "Indique ton adresse (quartier, commune, ville)."
            birthMillis == null -> "Indique ta date de naissance."
            birthMillis!! > latestBirthMillis() -> "Tu dois avoir au moins $TENANT_MIN_AGE ans pour réserver une résidence."
            idNumber.trim().length < 4 -> "Indique le numéro de ta pièce d'identité."
            rectoFile == null && !keepsStoredDocs -> "Prends en photo ta pièce d'identité (recto)."
            needsVerso && versoFile == null && !(keepsStoredDocs && user?.identityType == "cni") ->
                "La CNI se photographie des deux côtés : prends aussi le verso."
            else -> null
        }
        error = msg
        return msg == null
    }

    fun submit() {
        if (!validate()) return
        loading = true
        scope.launch {
            val result = repository.submit(
                name = name.trim(),
                phone = phone.trim(),
                address = address.trim(),
                birthDate = isoOf(birthMillis!!),
                identityType = idType,
                identityNumber = idNumber.trim(),
                recto = rectoFile,
                verso = if (needsVerso) versoFile else null
            )
            loading = false
            when (result) {
                is ApiResult.Success -> onSaved(result.data)
                is ApiResult.Error -> error = result.message
            }
        }
    }

    if (showDatePicker) {
        val latest = latestBirthMillis()
        val latestYear = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = latest }.get(Calendar.YEAR)
        val state = rememberDatePickerState(
            initialSelectedDateMillis = birthMillis,
            initialDisplayedMonthMillis = birthMillis ?: latest,
            yearRange = 1900..latestYear,
            selectableDates = object : SelectableDates {
                // Impossible de choisir une date qui rendrait le locataire mineur
                override fun isSelectableDate(utcTimeMillis: Long) = utcTimeMillis <= latest
            }
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { birthMillis = it; error = null }
                    showDatePicker = false
                }) { Text("Valider", color = Green, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Annuler", color = Sub) } }
        ) { DatePicker(state = state) }
    }

    Column(modifier = Modifier.fillMaxSize().background(Bg).statusBarsPadding().imePadding()) {
        TopBar("Mon dossier locataire", onBack)

        Column(
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            StatusBanner(status, user?.identityNote, forBooking)

            TCard("1", "Qui es-tu ?") {
                TLabel("Nom complet (comme sur la pièce d'identité)")
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    placeholder = { Text("Ex. Aya Kouadio") },
                    singleLine = true, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                TLabel("Date de naissance (18 ans minimum)")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardBg, RoundedCornerShape(12.dp))
                        .border(1.dp, Divider, RoundedCornerShape(12.dp))
                        .clickable { showDatePicker = true }
                        .padding(horizontal = 14.dp, vertical = 15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Cake, contentDescription = null, tint = Green, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        birthMillis?.let { formatMillisDate(it, "d MMMM yyyy") } ?: "Choisir la date",
                        fontSize = 14.sp, color = if (birthMillis != null) Ink else Sub
                    )
                }
                Spacer(Modifier.height(12.dp))
                TLabel("Téléphone")
                OutlinedTextField(
                    value = phone, onValueChange = { phone = it },
                    placeholder = { Text("07 00 00 00 00") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                TLabel("Adresse (quartier, commune, ville)")
                OutlinedTextField(
                    value = address, onValueChange = { address = it },
                    placeholder = { Text("Ex. Cocody Riviera 3, Abidjan") },
                    singleLine = true, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
            }

            TCard("2", "Pièce d'identité") {
                TLabel("Type de pièce")
                ID_TYPES.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        pair.forEach { (key, label) ->
                            val selected = idType == key
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(if (selected) Green else CardBg, RoundedCornerShape(12.dp))
                                    .border(1.dp, if (selected) Green else Divider, RoundedCornerShape(12.dp))
                                    .clickable { idType = key; error = null }
                                    .padding(vertical = 11.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    label, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold,
                                    color = if (selected) Color.White else Ink, textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                TLabel("Numéro de la pièce")
                OutlinedTextField(
                    value = idNumber, onValueChange = { idNumber = it },
                    placeholder = { Text("Ex. CI0123456789") },
                    singleLine = true, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    PhotoTile(
                        "Recto", rectoFile,
                        stored = keepsStoredDocs && rectoFile == null,
                        modifier = Modifier.weight(1f), onClick = takeRecto
                    )
                    if (needsVerso) {
                        PhotoTile(
                            "Verso", versoFile,
                            stored = keepsStoredDocs && versoFile == null && user?.identityType == "cni",
                            modifier = Modifier.weight(1f), onClick = takeVerso
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }

            if (error != null) {
                Text(error!!, color = OrangeDeep, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(4.dp))
        }

        Column(modifier = Modifier.fillMaxWidth().background(CardBg).navigationBarsPadding().padding(18.dp)) {
            Button(
                onClick = { error = null; submit() },
                enabled = !loading,
                colors = ButtonDefaults.buttonColors(containerColor = Orange),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                } else {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (forBooking) "Enregistrer et continuer" else "Enregistrer mon dossier",
                        fontWeight = FontWeight.Bold, fontSize = 14.5.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusBanner(status: String, note: String?, forBooking: Boolean) {
    val (color, icon, title, text) = when (status) {
        "verified" -> BannerContent(Green, Icons.Default.VerifiedUser, "Identité vérifiée ✓", "Ton dossier est validé.")
        "submitted" -> BannerContent(Blue, Icons.Default.HourglassTop, "Dossier reçu", "En cours de vérification. Tu peux déjà réserver.")
        "rejected" -> BannerContent(
            OrangeDeep, Icons.Default.ErrorOutline, "Dossier à corriger",
            (note?.let { "Motif : $it. " } ?: "") + "Corrige et reprends la photo de ta pièce."
        )
        else -> BannerContent(
            Orange, Icons.Default.Info, "Dossier requis pour réserver",
            "À remplir une seule fois."
        )
    }
    Row(
        modifier = Modifier.fillMaxWidth().background(color.copy(alpha = 0.10f), RoundedCornerShape(14.dp)).padding(14.dp)
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text(text, fontSize = 11.5.sp, color = Ink, lineHeight = 16.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

private data class BannerContent(
    val color: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val title: String,
    val text: String
)

@Composable
private fun TCard(step: String, title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(18.dp))
            .border(1.dp, Divider, RoundedCornerShape(18.dp))
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(24.dp).clip(RoundedCornerShape(8.dp)).background(Green),
                contentAlignment = Alignment.Center
            ) { Text(step, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(10.dp))
            Text(title, fontSize = 14.5.sp, fontWeight = FontWeight.Bold, color = Ink)
        }
        Spacer(Modifier.height(14.dp))
        content()
    }
}

@Composable
private fun TLabel(text: String) {
    Text(text, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = Sub, modifier = Modifier.padding(bottom = 4.dp))
}

@Composable
private fun PhotoTile(label: String, file: File?, stored: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(118.dp)
                .background(Bg, RoundedCornerShape(14.dp))
                .border(1.5.dp, if (file != null || stored) Green else Divider, RoundedCornerShape(14.dp))
                .clip(RoundedCornerShape(14.dp))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            when {
                file != null -> {
                    AsyncImage(model = file, contentDescription = label, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    Box(
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).background(Green, RoundedCornerShape(11.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp)) }
                }
                stored -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Green, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(4.dp))
                    Text("Déjà envoyée", fontSize = 10.5.sp, color = Ink, fontWeight = FontWeight.SemiBold)
                    Text("Touche pour remplacer", fontSize = 9.5.sp, color = Sub)
                }
                else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Orange, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.height(4.dp))
                    Text("Scanner la pièce", fontSize = 10.5.sp, color = Sub, textAlign = TextAlign.Center)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}
