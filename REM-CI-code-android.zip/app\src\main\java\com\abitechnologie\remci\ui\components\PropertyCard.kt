package com.abitechnologie.remci.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.abitechnologie.remci.data.Property
import com.abitechnologie.remci.ui.theme.*

/** Photo de couverture réelle (prise par le propriétaire) ; dégradé de marque en attendant/à défaut. */
@Composable
fun PropertyCover(photoUrl: String?, modifier: Modifier = Modifier) {
    Box(modifier = modifier.background(Brush.linearGradient(listOf(Green, GreenDeep)))) {
        Icon(
            Icons.Default.Apartment, contentDescription = null,
            tint = Color.White.copy(alpha = 0.18f),
            modifier = Modifier.size(54.dp).align(Alignment.Center)
        )
        if (!photoUrl.isNullOrBlank()) {
            AsyncImage(
                model = photoUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun PropertyCard(
    property: Property,
    isFavorite: Boolean,
    onOpen: (Property) -> Unit,
    onToggleFavorite: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(CardBg)
            .border(1.dp, Divider, RoundedCornerShape(18.dp))
            .clickableNoRipple { onOpen(property) }
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(138.dp)) {
            PropertyCover(property.photos.firstOrNull(), Modifier.fillMaxSize())

            // Résidence occupée : photo assombrie, pour qu'on voie tout de suite qu'elle n'est pas libre
            if (!property.available) {
                Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.28f)))
            }

            // Léger voile en bas pour que le badge reste lisible sur n'importe quelle photo
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.45f))))
            )
            if (property.tag.isNotBlank()) {
                Badge(property.tag, property.tagColor, modifier = Modifier.align(Alignment.BottomStart).padding(10.dp))
            }

            AvailabilityPill(property.available, modifier = Modifier.align(Alignment.TopStart).padding(10.dp))

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .size(32.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(Color.White.copy(alpha = 0.92f))
                    .clickableNoRipple { onToggleFavorite(property.id) },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favori",
                    tint = if (isFavorite) Orange else Sub,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 11.dp)) {
            Text(
                "RÉSIDENCE MEUBLÉE", fontSize = 8.5.sp, fontWeight = FontWeight.ExtraBold, color = Green,
                letterSpacing = 0.6.sp, maxLines = 1
            )
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(
                    ListingTitle.nameOf(property.title).ifBlank { property.title }, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Ink,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(6.dp))
                RatingLabel(property)
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 3.dp)) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Sub, modifier = Modifier.size(11.dp))
                Text(
                    " ${property.city}", fontSize = 11.sp, color = Sub, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(top = 5.dp)
            ) {
                MiniStat(Icons.Default.MeetingRoom, "${property.beds}")
                MiniStat(Icons.Default.People, "${property.capacity}")
                MiniStat(Icons.Default.Bathtub, "${property.bathrooms}")
            }
            Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 8.dp)) {
                Text(
                    text = "${"%,d".format(property.price).replace(',', ' ')} FCFA",
                    color = Green, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp
                )
                Text(" / nuit", fontSize = 10.5.sp, color = Sub, modifier = Modifier.padding(bottom = 1.dp))
            }
        }
    }
}

/**
 * Disponibilité déclarée par le propriétaire : icône bleue « Disponible » ou rouge « Occupée ».
 * [large] : version un peu plus grande pour la fiche détail.
 */
@Composable
fun AvailabilityPill(available: Boolean, modifier: Modifier = Modifier, large: Boolean = false) {
    val color = if (available) Blue else Danger
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.95f))
            .padding(start = 4.dp, end = if (large) 12.dp else 9.dp, top = 3.dp, bottom = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(if (large) 22.dp else 16.dp).clip(CircleShape).background(color),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (available) Icons.Default.Check else Icons.Default.Close,
                contentDescription = null, tint = Color.White,
                modifier = Modifier.size(if (large) 14.dp else 11.dp)
            )
        }
        Spacer(Modifier.width(if (large) 7.dp else 5.dp))
        Text(
            if (available) "Disponible" else "Occupée",
            fontSize = if (large) 12.5.sp else 10.sp, fontWeight = FontWeight.Bold, color = color
        )
    }
}

/** Une résidence sans avis affiche "Nouveau" plutôt qu'une fausse note de 0.0 */
@Composable
fun RatingLabel(property: Property) {
    if (property.reviews > 0) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Star, contentDescription = null, tint = Gold, modifier = Modifier.size(12.dp))
            Text(" ${property.rating}", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        }
    } else {
        Text("Nouveau", fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, color = Green)
    }
}

@Composable
private fun MiniStat(icon: androidx.compose.ui.graphics.vector.ImageVector, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = Sub, modifier = Modifier.size(12.dp))
        Text(" $value", fontSize = 11.sp, color = Sub, fontWeight = FontWeight.Medium)
    }
}
