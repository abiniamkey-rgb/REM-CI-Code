<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title>@yield('title', 'Administration') · REM-CI</title>
  @include('admin._styles')
</head>
<body>
@php
  $navOwners = \App\Models\User::where('role', 'proprietaire')->where('owner_verification_status', 'pending')->count();
  $navIdentities = \App\Models\User::where('role', 'locataire')->where('identity_status', 'submitted')->count();
  $navProps = \App\Models\Property::where('status', 'pending')->count();
@endphp
<div class="layout">
  <aside class="side">
    <div class="brand">REM<b>-</b>CI <span style="font-weight:500;font-size:12px;opacity:.7">admin</span></div>
    <a class="nav {{ request()->routeIs('admin.dashboard') ? 'on' : '' }}" href="{{ route('admin.dashboard') }}">Tableau de bord</a>
    <a class="nav {{ request()->routeIs('admin.owners.*') ? 'on' : '' }}" href="{{ route('admin.owners.index') }}">Propriétaires @if($navOwners)<span class="pill">{{ $navOwners }}</span>@endif</a>
    <a class="nav {{ request()->routeIs('admin.properties.*') ? 'on' : '' }}" href="{{ route('admin.properties.index') }}">Résidences @if($navProps)<span class="pill">{{ $navProps }}</span>@endif</a>
    <a class="nav {{ request()->routeIs('admin.bookings.*') ? 'on' : '' }}" href="{{ route('admin.bookings.index') }}">Réservations</a>
    <a class="nav {{ request()->routeIs('admin.users.*', 'admin.tenants.*') ? 'on' : '' }}" href="{{ route('admin.users.index') }}">Utilisateurs @if($navIdentities)<span class="pill">{{ $navIdentities }}</span>@endif</a>
    <div class="who">
      Connecté : {{ auth()->user()->name }}
      <form method="POST" action="{{ route('admin.logout') }}">@csrf<button type="submit">Se déconnecter</button></form>
    </div>
  </aside>
  <main class="main">
    @if(session('ok'))<div class="flash ok">{{ session('ok') }}</div>@endif
    @if(session('erreur'))<div class="flash err">{{ session('erreur') }}</div>@endif
    @if($errors->any())<div class="flash err">{{ $errors->first() }}</div>@endif
    @yield('content')
  </main>
</div>
</body>
</html>
