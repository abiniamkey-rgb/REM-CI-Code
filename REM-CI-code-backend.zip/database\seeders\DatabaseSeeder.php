<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            CitySeeder::class,
            AmenitySeeder::class,
            PropertySeeder::class, // dépend des villes + amenities
            AdSeeder::class,       // dépend des résidences
        ]);

        // Compte locataire de démo pour tester l'app tout de suite
        User::firstOrCreate(
            ['phone' => '+2250700000000'],
            [
                'name' => 'Aya Kouadio',
                'email' => 'aya@remci.ci',
                'password' => Hash::make('password'),
                'role' => 'locataire',
                'is_verified' => true,
            ]
        );
    }
}
