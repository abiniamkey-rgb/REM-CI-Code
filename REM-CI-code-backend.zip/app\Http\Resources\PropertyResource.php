<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PropertyResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        // Visiteur sans compte (invité) : pas d'adresse exacte, de position GPS ni de
        // coordonnées du propriétaire — il faut s'inscrire pour y accéder.
        $member = (bool) $request->user('sanctum');

        return [
            'id' => $this->id,
            'title' => $this->title,
            'slug' => $this->slug,
            'description' => $this->when($this->description !== null, $this->description),
            'price_per_night' => $this->price_per_night,
            'beds' => $this->beds,
            'bathrooms' => $this->bathrooms,
            'capacity' => $this->capacity,
            'address' => $member ? $this->address : null,
            'latitude' => $member ? $this->latitude : null,
            'longitude' => $member ? $this->longitude : null,
            'status' => $this->status,
            // Disponibilité déclarée par le propriétaire : true = bleu (disponible), false = rouge (occupée)
            'is_available' => (bool) ($this->is_available ?? true),
            'availability_updated_at' => $this->availability_updated_at,
            'tag' => $this->tag,
            'is_featured' => $this->is_featured,
            'rating' => $this->rating,
            'reviews_count' => $this->reviews_count,
            'city' => new CityResource($this->whenLoaded('city')),
            // Données publiques uniquement : jamais l'adresse, le statut de vérification ni
            // les infos de la pièce d'identité du propriétaire.
            'owner' => $this->whenLoaded('owner', fn () => ! $member ? null : [
                'id' => $this->owner->id,
                'name' => $this->owner->name,
                'phone' => $this->owner->phone,
                'is_verified' => $this->owner->owner_verification_status === 'verified',
            ]),
            // URL absolue (le fichier est stocké en local via `storage:link`) pour que
            // l'app Android puisse charger l'image directement avec Coil.
            'photos' => $this->whenLoaded('photos', fn () => $this->photos->map(
                fn ($p) => \App\Support\PublicUrl::file($request, $p->url)
            )),
            'amenities' => $this->whenLoaded('amenities', fn () => $this->amenities->map(fn ($a) => [
                'id' => $a->id, 'name' => $a->name, 'icon' => $a->icon,
            ])),
            'is_favorite' => $this->when(isset($this->is_favorite), (bool) ($this->is_favorite ?? false)),
        ];
    }
}
