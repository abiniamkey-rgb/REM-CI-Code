<style>
  :root{--green:#0A6C3B;--green-deep:#063D22;--orange:#F77F00;--orange-deep:#E0630A;--gold:#D4AF37;--bg:#FAF7F0;--card:#fff;--ink:#1B231F;--sub:#6B756E;--line:#EAE5D6;--blue:#0091D8;--red:#C62828}
  *{box-sizing:border-box}
  body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:var(--bg);color:var(--ink);font-size:14px;line-height:1.45}
  a{color:var(--green);text-decoration:none} a:hover{text-decoration:underline}
  h1{font-size:22px;margin:0 0 4px;font-weight:800} h2{font-size:16px;margin:0 0 12px;font-weight:800}
  .sub{color:var(--sub);font-size:13px}
  .layout{display:flex;min-height:100vh}
  .side{width:230px;background:linear-gradient(180deg,var(--green-deep),#0B1B14);color:#fff;padding:20px 14px;position:sticky;top:0;height:100vh;display:flex;flex-direction:column}
  .brand{font-size:20px;font-weight:800;letter-spacing:.5px;padding:0 10px 18px}
  .brand b{color:var(--orange)}
  .side a.nav{display:flex;align-items:center;justify-content:space-between;color:#D5E2D9;padding:10px 12px;border-radius:12px;margin-bottom:4px;font-weight:600}
  .side a.nav:hover{background:rgba(255,255,255,.08);text-decoration:none}
  .side a.nav.on{background:rgba(255,255,255,.16);color:#fff}
  .pill{background:var(--orange);color:#fff;border-radius:20px;font-size:11px;font-weight:800;padding:1px 8px}
  .side .who{margin-top:auto;font-size:12px;color:#B9CBBF;padding:10px}
  .side form button{background:none;border:1px solid rgba(255,255,255,.3);color:#fff;border-radius:10px;padding:7px 12px;width:100%;cursor:pointer;margin-top:8px}
  .main{flex:1;padding:26px 30px;min-width:0}
  .grid{display:grid;gap:14px}
  .stats{grid-template-columns:repeat(auto-fit,minmax(190px,1fr));margin:18px 0}
  .card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px}
  .stat .n{font-size:30px;font-weight:800;line-height:1.1} .stat .l{color:var(--sub);font-size:12.5px}
  .stat.warn{border-color:var(--orange);background:#FFF6EA}
  table{width:100%;border-collapse:collapse}
  th{text-align:left;color:var(--sub);font-size:11.5px;text-transform:uppercase;letter-spacing:.4px;padding:8px 10px;border-bottom:1px solid var(--line)}
  td{padding:11px 10px;border-bottom:1px solid #F3EFE3;vertical-align:middle}
  tr:last-child td{border-bottom:0}
  .tablewrap{overflow-x:auto}
  .badge{display:inline-block;border-radius:20px;padding:2px 10px;font-size:11.5px;font-weight:700;color:#fff;background:var(--sub);white-space:nowrap}
  .b-pending,.b-submitted{background:var(--orange)} .b-verified,.b-active,.b-confirmed{background:var(--green)}
  .b-rejected,.b-cancelled,.b-inactive{background:var(--red)} .b-completed{background:var(--blue)} .b-not_submitted{background:#9AA39D}
  .tabs{display:flex;flex-wrap:wrap;gap:8px;margin:14px 0}
  .tabs a{padding:7px 14px;border-radius:20px;background:#fff;border:1px solid var(--line);color:var(--ink);font-weight:600;font-size:13px}
  .tabs a.on{background:var(--green);color:#fff;border-color:var(--green)} .tabs a:hover{text-decoration:none}
  .tabs small{opacity:.75;margin-left:4px}
  .search{display:flex;gap:8px;margin:6px 0 4px}
  input[type=text],input[type=password],textarea,select{width:100%;padding:10px 12px;border:1px solid #DDD6C3;border-radius:12px;font:inherit;background:#fff}
  input:focus,textarea:focus{outline:2px solid rgba(10,108,59,.25);border-color:var(--green)}
  .search input{max-width:340px}
  .btn{display:inline-block;border:0;border-radius:12px;padding:10px 18px;font-weight:700;font:inherit;font-weight:700;cursor:pointer;color:#fff;background:var(--green)}
  .btn:hover{opacity:.92;text-decoration:none} .btn.orange{background:var(--orange)} .btn.red{background:var(--red)} .btn.ghost{background:#fff;color:var(--ink);border:1px solid #DDD6C3}
  .flash{border-radius:12px;padding:12px 14px;margin:14px 0;font-weight:600}
  .flash.ok{background:#E4F4EA;color:var(--green-deep);border:1px solid #BFE2CC} .flash.err{background:#FDECEC;color:#8E1B1B;border:1px solid #F3C2C2}
  .two{grid-template-columns:repeat(auto-fit,minmax(320px,1fr))}
  dl{margin:0;display:grid;grid-template-columns:150px 1fr;gap:8px 12px} dt{color:var(--sub)} dd{margin:0;font-weight:600;word-break:break-word}
  .docs{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}
  .docs img,.photos img{width:100%;border-radius:12px;border:1px solid var(--line);background:#EEE;display:block}
  .docs a{display:block}
  .photos{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
  .photos img{aspect-ratio:4/3;object-fit:cover}
  .actions{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-start}
  .empty{text-align:center;color:var(--sub);padding:28px}
  .pager{display:flex;justify-content:space-between;align-items:center;margin-top:14px;color:var(--sub);font-size:13px}
  .login{max-width:390px;margin:9vh auto;padding:0 16px}
  .login .card{padding:26px} .login label{display:block;font-weight:700;margin:12px 0 6px;font-size:13px}
  .err-text{color:var(--red);font-size:12.5px;margin-top:6px}
  @@media(max-width:820px){.layout{flex-direction:column}.side{width:auto;height:auto;position:static;flex-direction:row;flex-wrap:wrap;align-items:center;gap:4px;padding:10px}.brand{padding:0 8px;font-size:17px}.side .who,.side form{margin:0 0 0 auto}.main{padding:16px}dl{grid-template-columns:110px 1fr}}
</style>
