@extends('admin.layout')
@section('title', 'Réservations')
@section('content')
  <h1>Réservations</h1>
  <div class="sub">Demandes envoyées par les locataires (le paiement se règle directement avec le propriétaire).</div>

  <div class="tabs">
    <a class="{{ $status === 'all' ? 'on' : '' }}" href="{{ route('admin.bookings.index') }}">Toutes</a>
    @foreach($statuses as $key => $label)
      <a class="{{ $status === $key ? 'on' : '' }}" href="{{ route('admin.bookings.index', ['statut' => $key]) }}">{{ $label }}<small>{{ $counts[$key] ?? 0 }}</small></a>
    @endforeach
  </div>

  <div class="card tablewrap">
    <table>
      <thead><tr><th>Résidence</th><th>Locataire</th><th>Propriétaire</th><th>Séjour</th><th>Total</th><th>Statut</th></tr></thead>
      <tbody>
      @forelse($bookings as $b)
        <tr>
          <td><strong>{{ $b->property?->title }}</strong><div class="sub">{{ $b->reference }}</div></td>
          <td>{{ $b->user?->name }}<div class="sub">{{ $b->user?->phone }}</div></td>
          <td>{{ $b->property?->owner?->name }}<div class="sub">{{ $b->property?->owner?->phone }}</div></td>
          <td>{{ $b->check_in?->format('d/m/Y') }} → {{ $b->check_out?->format('d/m/Y') }}<div class="sub">{{ $b->nights }} nuit(s) · {{ $b->guests }} voyageur(s)</div></td>
          <td>{{ number_format($b->total_price, 0, ',', ' ') }} FCFA</td>
          <td>@include('admin._badge', ['status' => $b->display_status])</td>
        </tr>
      @empty
        <tr><td colspan="6" class="empty">Aucune réservation.</td></tr>
      @endforelse
      </tbody>
    </table>
  </div>
  @include('admin._pager', ['items' => $bookings])
@endsection
